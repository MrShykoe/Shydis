package com.example.iosbanners

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat

class MainActivity : ComponentActivity() {

    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IosScreen(refresh) }
    }

    // Обновляем статусы разрешений, когда пользователь возвращается из настроек
    override fun onResume() {
        super.onResume()
        refresh++
    }
}

@Composable
private fun IosScreen(refresh: Int) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()

    val bg = if (dark) Color.Black else Color(0xFFF2F2F7)
    val card = if (dark) Color(0xFF1C1C1E) else Color.White
    val label = if (dark) Color.White else Color.Black
    val label2 = if (dark) Color(0xFF98989F) else Color(0xFF6C6C70)
    val sep = if (dark) Color(0x33FFFFFF) else Color(0x1F000000)
    val blue = Color(0xFF0066CC)
    val green = Color(0xFF34C759)

    var enabled by remember { mutableStateOf(Prefs.enabled(ctx)) }
    var hide by remember { mutableStateOf(Prefs.hideOriginal(ctx)) }
    val listenerOn = remember(refresh) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val overlayOn = remember(refresh) { Settings.canDrawOverlays(ctx) }

    val switchColors = SwitchDefaults.colors(
        checkedTrackColor = green,
        checkedThumbColor = Color.White,
        checkedBorderColor = Color.Transparent,
        uncheckedTrackColor = if (dark) Color(0xFF39393D) else Color(0xFFE9E9EA),
        uncheckedThumbColor = Color.White,
        uncheckedBorderColor = Color.Transparent
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Text(
            "Баннеры",
            color = label,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 28.dp, bottom = 4.dp)
        )
        Text(
            "Уведомления Android в стиле iOS.",
            color = label2,
            fontSize = 17.sp
        )

        SectionLabel("ДОСТУПЫ", label2)
        Group(card) {
            SettingRow(
                icon = R.drawable.ic_bell,
                iconBg = Color(0xFF007AFF),
                title = "Доступ к уведомлениям",
                subtitle = if (listenerOn) "Включено" else "Нужно включить",
                label = label,
                label2 = label2,
                onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            ) { Chevron(label2) }
            Divider(sep)
            SettingRow(
                icon = R.drawable.ic_layers,
                iconBg = Color(0xFF5856D6),
                title = "Поверх других окон",
                subtitle = if (overlayOn) "Включено" else "Нужно включить",
                label = label,
                label2 = label2,
                onClick = {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + ctx.packageName)
                        )
                    )
                }
            ) { Chevron(label2) }
        }

        SectionLabel("ПАРАМЕТРЫ", label2)
        Group(card) {
            SettingRow(
                icon = R.drawable.ic_check,
                iconBg = green,
                title = "Показывать баннеры",
                subtitle = null,
                label = label,
                label2 = label2,
                onClick = null
            ) {
                Switch(
                    checked = enabled,
                    onCheckedChange = {
                        enabled = it
                        Prefs.setEnabled(ctx, it)
                    },
                    colors = switchColors
                )
            }
            Divider(sep)
            SettingRow(
                icon = R.drawable.ic_bell,
                iconBg = Color(0xFFFF9500),
                title = "Скрывать оригинал",
                subtitle = "Убирает уведомление из шторки",
                label = label,
                label2 = label2,
                onClick = null
            ) {
                Switch(
                    checked = hide,
                    onCheckedChange = {
                        hide = it
                        Prefs.setHideOriginal(ctx, it)
                    },
                    colors = switchColors
                )
            }
        }

        Spacer(Modifier.height(28.dp))
        Button(
            onClick = {
                if (!Settings.canDrawOverlays(ctx)) {
                    Toast.makeText(ctx, "Сначала включите «Поверх других окон»", Toast.LENGTH_SHORT).show()
                } else {
                    BannerOverlay.show(
                        ctx = ctx.applicationContext,
                        appName = "Баннеры",
                        title = "Так выглядит уведомление",
                        text = "Свайпните вверх, чтобы закрыть, или нажмите на баннер.",
                        icon = null
                    )
                }
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = blue, contentColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Показать пример", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        Text(
            "Независимое приложение. Не связано с Apple Inc.",
            color = label2,
            fontSize = 13.sp,
            modifier = Modifier.padding(vertical = 24.dp)
        )
    }
}

@Composable
private fun SectionLabel(text: String, color: Color) {
    Text(
        text,
        color = color,
        fontSize = 13.sp,
        modifier = Modifier.padding(start = 16.dp, top = 28.dp, bottom = 8.dp)
    )
}

@Composable
private fun Group(card: Color, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(card)
    ) { content() }
}

@Composable
private fun Divider(color: Color) {
    Box(
        Modifier
            .padding(start = 62.dp)
            .fillMaxWidth()
            .height(0.5.dp)
            .background(color)
    )
}

@Composable
private fun Chevron(color: Color) {
    Icon(
        painter = painterResource(R.drawable.ic_chevron),
        contentDescription = null,
        tint = color,
        modifier = Modifier.size(16.dp)
    )
}

@Composable
private fun SettingRow(
    icon: Int,
    iconBg: Color,
    title: String,
    subtitle: String?,
    label: Color,
    label2: Color,
    onClick: (() -> Unit)?,
    trailing: @Composable () -> Unit
) {
    val base = Modifier
        .fillMaxWidth()
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }
        .padding(horizontal = 14.dp, vertical = 10.dp)
    Row(modifier = base, verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(icon),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(title, color = label, fontSize = 17.sp)
            if (subtitle != null) Text(subtitle, color = label2, fontSize = 13.sp)
        }
        trailing()
    }
}
