package com.example.iosbanners

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BannerListenerService : NotificationListenerService() {

    private val main = Handler(Looper.getMainLooper())

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.enabled(this)) return
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return
        if (!Settings.canDrawOverlays(this)) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isEmpty() && text.isEmpty()) return

        val pm = packageManager
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val icon = try {
            pm.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
            null
        }
        val tap = n.contentIntent

        main.post {
            BannerOverlay.show(
                ctx = applicationContext,
                appName = appName,
                title = title,
                text = text,
                icon = icon,
                onTap = {
                    try {
                        tap?.send()
                    } catch (_: Exception) {
                    }
                }
            )
        }

        if (Prefs.hideOriginal(this) && sbn.isClearable) {
            cancelNotification(sbn.key)
        }
    }
}
