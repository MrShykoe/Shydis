package com.example.iosbanners

import android.content.Context

object Prefs {
    private const val FILE = "ios_banners"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_HIDE_ORIGINAL = "hide_original"

    const val SHOW_MS = 4500L

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean(KEY_ENABLED, true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_ENABLED, v).apply()

    // По умолчанию выключено: скрытый оригинал пропадает из системной шторки.
    fun hideOriginal(c: Context) = sp(c).getBoolean(KEY_HIDE_ORIGINAL, false)
    fun setHideOriginal(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_HIDE_ORIGINAL, v).apply()
}
