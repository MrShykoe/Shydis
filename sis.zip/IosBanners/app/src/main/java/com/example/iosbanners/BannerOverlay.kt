package com.example.iosbanners

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Баннер уведомления в стиле iOS, рисуется поверх экрана. */
object BannerOverlay {

    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var root: View? = null
    private var card: View? = null
    private var hideTask: Runnable? = null

    private fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("ClickableViewAccessibility")
    fun show(
        ctx: Context,
        appName: String,
        title: String,
        text: String,
        icon: Drawable?,
        onTap: (() -> Unit)? = null
    ) {
        remove()
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val bgColor = if (night) 0xEB2C2C2E.toInt() else 0xEBFFFFFF.toInt()
        val primary = if (night) Color.WHITE else Color.BLACK
        val secondary = if (night) 0xFFAEAEB2.toInt() else 0xFF6C6C70.toInt()

        // Иконка приложения со скруглением
        val iconView = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageDrawable(icon ?: ctx.getDrawable(R.drawable.ic_bell))
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, ctx.dp(9).toFloat())
                }
            }
        }

        fun label(sp: Float, color: Int, bold: Boolean = false, lines: Int = 1) = TextView(ctx).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            maxLines = lines
            ellipsize = TextUtils.TruncateAt.END
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(label(13f, secondary).apply { this.text = appName }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(label(13f, secondary).apply { this.text = "сейчас" })
        }

        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(header)
            if (title.isNotEmpty()) addView(label(15f, primary, bold = true).apply { this.text = title })
            if (text.isNotEmpty()) addView(label(15f, primary, lines = 2).apply { this.text = text })
        }

        val cardView = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
            background = GradientDrawable().apply {
                setColor(bgColor)
                cornerRadius = ctx.dp(22).toFloat()
            }
            elevation = ctx.dp(12).toFloat()
            addView(iconView, LinearLayout.LayoutParams(ctx.dp(38), ctx.dp(38)))
            addView(column, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = ctx.dp(12)
            })
        }
        card = cardView

        val statusBarId = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusBar = if (statusBarId > 0) ctx.resources.getDimensionPixelSize(statusBarId) else ctx.dp(24)

        val wrapper = FrameLayout(ctx).apply {
            clipChildren = false
            clipToPadding = false
            setPadding(ctx.dp(8), statusBar + ctx.dp(4), ctx.dp(8), ctx.dp(12))
            addView(cardView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root = wrapper

        // Жесты: свайп вверх закрывает, тап открывает уведомление
        var downY = 0f
        cardView.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    cancelHide()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - downY
                    if (dy < 0) v.translationY = dy
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dy = e.rawY - downY
                    when {
                        dy < -ctx.dp(40) -> dismiss(ctx)
                        abs(dy) < ctx.dp(8) -> {
                            onTap?.invoke()
                            dismiss(ctx)
                        }
                        else -> {
                            v.animate().translationY(0f).setDuration(200).start()
                            scheduleHide(ctx)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.animate().translationY(0f).setDuration(200).start()
                    scheduleHide(ctx)
                    true
                }
                else -> false
            }
        }

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }

        try {
            wm.addView(wrapper, lp)
        } catch (e: Exception) {
            root = null
            card = null
            return
        }

        // Появление сверху, как в iOS
        cardView.translationY = -ctx.dp(160).toFloat()
        cardView.alpha = 0f
        cardView.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(350)
            .setInterpolator(DecelerateInterpolator())
            .start()

        scheduleHide(ctx)
    }

    private fun scheduleHide(ctx: Context) {
        cancelHide()
        val task = Runnable { dismiss(ctx) }
        hideTask = task
        handler.postDelayed(task, Prefs.SHOW_MS)
    }

    private fun cancelHide() {
        hideTask?.let { handler.removeCallbacks(it) }
        hideTask = null
    }

    private fun dismiss(ctx: Context) {
        cancelHide()
        val c = card ?: return remove()
        c.animate()
            .translationY(-ctx.dp(160).toFloat())
            .alpha(0f)
            .setDuration(250)
            .withEndAction { remove() }
            .start()
    }

    private fun remove() {
        cancelHide()
        root?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        card = null
    }
}
