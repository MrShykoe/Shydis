package com.island.dynamic

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.media.AudioManager
import android.os.BatteryManager
import android.os.SystemClock
import com.island.dynamic.acts.BluetoothActivity
import com.island.dynamic.acts.CallActivity
import com.island.dynamic.acts.ChargingActivity
import com.island.dynamic.acts.MediaActivity
import com.island.dynamic.acts.MediaControls
import com.island.dynamic.acts.NotificationActivity
import com.island.dynamic.acts.ProgressActivity
import com.island.dynamic.acts.SilentActivity
import com.island.dynamic.acts.TimerActivity
import com.island.dynamic.acts.UnlockActivity
import com.island.dynamic.gfx.G

/** Кнопки "Проверка" — гоняют все состояния острова без реальных событий. */
object Demo {
    private class Track(val title: String, val artist: String, val c1: Int, val c2: Int, val len: Long)

    private val tracks = listOf(
        Track("Ночной город", "ShyFlow", 0xFFFF6A3D.toInt(), 0xFF5B2A86.toInt(), 194_000),
        Track("Неон", "Island Band", 0xFF00C2FF.toInt(), 0xFF0A1A5C.toInt(), 172_000),
        Track("Тишина", "Lo-fi Club", 0xFF7CFFB2.toInt(), 0xFF0F4D3A.toInt(), 228_000),
    )
    private var idx = 0
    private var notifN = 0L
    private var silentFlip = false

    private fun art(c1: Int, c2: Int): Bitmap {
        val s = 192
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, s.toFloat(), s.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        p.shader = RadialGradient(s * 0.7f, s * 0.3f, s * 0.45f, G.alpha(Color.WHITE, 0.55f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(s * 0.7f, s * 0.3f, s * 0.45f, p)
        p.shader = null
        p.color = G.alpha(Color.BLACK, 0.35f)
        c.drawCircle(s * 0.3f, s * 0.78f, s * 0.22f, p)
        return b
    }

    private fun load(m: MediaActivity, i: Int) {
        val t = tracks[((i % tracks.size) + tracks.size) % tracks.size]
        m.title = t.title
        m.artist = t.artist
        m.setArt(art(t.c1, t.c2))
        m.duration = t.len
        m.setState(true, 0, SystemClock.elapsedRealtime(), 1f)
    }

    fun media() {
        val m = (IslandHub.get("demo-media") as? MediaActivity) ?: MediaActivity("demo-media")
        load(m, idx)
        m.controls = object : MediaControls {
            override fun toggle() {
                m.setState(!m.playing, m.position(), SystemClock.elapsedRealtime(), 1f)
                IslandHub.put(m, bump = false)
            }

            override fun next() {
                idx++; load(m, idx); IslandHub.put(m, bump = false)
            }

            override fun prev() {
                if (m.position() > 3000) m.setState(m.playing, 0, SystemClock.elapsedRealtime(), 1f)
                else { idx--; load(m, idx) }
                IslandHub.put(m, bump = false)
            }

            override fun seek(ms: Long) {
                m.setState(m.playing, ms, SystemClock.elapsedRealtime(), 1f)
                IslandHub.put(m, bump = false)
            }
        }
        IslandHub.put(m)
    }

    fun notification() {
        notifN++
        val msgs = listOf(
            "Аня" to "Ты где? Мы уже на месте, занимаем столик у окна",
            "Дима" to "Скинь трек, который вчера играл, очень зашёл",
            "Мама" to "Позвони, как освободишься ❤️"
        )
        val (who, text) = msgs[(notifN % msgs.size).toInt()]
        IslandHub.put(
            NotificationActivity(
                null, "Сообщения", who, text,
                G.letterIcon("✉", 0xFF30D158.toInt(), 96),
                G.letterIcon(who.take(1), 0xFF5E5CE6.toInt(), 128),
                null, notifN
            ),
            durationMs = 5500
        )
        Haptics.tick(App.instance)
    }

    fun call() {
        IslandHub.put(
            CallActivity(
                "call:demo", null, "Мама", "мобильный",
                G.letterIcon("М", 0xFFFF375F.toInt(), 128), true,
                System.currentTimeMillis(), null, null, null, demo = true
            )
        )
        Haptics.heavy(App.instance)
    }

    fun charging() {
        val bm = App.instance.getSystemService(BatteryManager::class.java)
        val lvl = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 78
        IslandHub.put(ChargingActivity(lvl.coerceIn(1, 100)), 3500)
    }

    fun silent() {
        silentFlip = !silentFlip
        IslandHub.put(SilentActivity(if (silentFlip) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL), 2600)
        Haptics.click(App.instance)
    }

    fun unlock() = IslandHub.put(UnlockActivity(), 1500)

    fun bluetooth() = IslandHub.put(BluetoothActivity("Наушники"), 3500)

    fun timer(ms: Long) = TimerActivity.start(ms)

    fun download() {
        val key = "prog:demo"
        val icon = G.letterIcon("↓", 0xFF0A84FF.toInt(), 96)
        var p = 0f
        val r = object : Runnable {
            override fun run() {
                p += 0.012f
                if (p >= 1f) {
                    IslandHub.remove(key); return
                }
                IslandHub.put(ProgressActivity(key, null, icon, "Загрузка файла", p, null), bump = p < 0.02f)
                IslandHub.handler.postDelayed(this, 100)
            }
        }
        r.run()
    }
}
