package com.island.dynamic

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import com.island.dynamic.acts.Dims
import com.island.dynamic.acts.FrameMode
import com.island.dynamic.acts.Hits
import com.island.dynamic.acts.IslandActivity
import com.island.dynamic.gfx.G
import com.island.dynamic.gfx.Metaball
import com.island.dynamic.gfx.Spring
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Сам остров. Всё — один View, рисующий на Canvas:
 *  - форма морфится пружинами (ширина, высота, радиус, центр)
 *  - контент перетекает между compact / expanded через fade+scale
 *  - вторая активность отделяется "каплей" (metaball) в кружок справа
 *
 * Координаты рисования — экранные; originX/Y — где на экране лежит окно.
 */
class IslandView(context: Context, private val preview: Boolean) : View(context), IslandHub.Listener {

    interface Host {
        fun onBounds(r: RectF, touchable: Boolean)
    }

    var host: Host? = null
    var originX = 0f
    var originY = 0f

    private var screenW = 0f
    private val cam = RectF()
    private var hasCam = false
    private var landscape = false

    private val density = resources.displayMetrics.density
    private var dims = Dims(density, density * 30f)
    private val main = Handler(Looper.getMainLooper())

    // ---- пружины ----
    private val sW = Spring(0f, 300f, 0.72f, 0.3f)
    private val sH = Spring(0f, 300f, 0.72f, 0.3f)
    private val sR = Spring(0f, 300f, 0.8f, 0.3f)
    private val sCx = Spring(0f, 300f, 0.85f, 0.3f)
    private val sExp = Spring(0f, 210f, 1f, 0.002f)
    private val sBub = Spring(0f, 240f, 0.62f, 0.002f)
    private val sPres = Spring(0f, 220f, 1f, 0.002f)
    private val sPress = Spring(1f, 650f, 0.5f, 0.0005f)
    private val sSwap = Spring(1f, 240f, 1f, 0.002f)
    private val sRing = Spring(0f, 200f, 1f, 0.002f)
    private val springs = arrayOf(sW, sH, sR, sCx, sExp, sBub, sPres, sPress, sSwap, sRing)
    private var initialized = false

    // ---- состояние ----
    private var primary: IslandActivity? = null
    private var prev: IslandActivity? = null
    private var secondary: IslandActivity? = null
    private var bubbleAct: IslandActivity? = null
    private var expAct: IslandActivity? = null
    private var expanded = false
    private var ringColor = 0
    private val autoSeen = HashSet<String>()
    private val hits = Hits()

    // геометрия текущего кадра/цели
    private var top = 0f
    private var camW = 0f
    private var camCx = 0f
    private var tW = 0f
    private var tH = 0f
    private var tCx = 0f
    private var expW = 0f
    private var settleDirty = false

    private val curRect = RectF()
    private val bubbleRect = RectF()
    private val tmp = RectF()
    private val tmp2 = RectF()
    private val islandPath = Path()
    private val ballPath = Path()

    // =================================================================
    //  Геометрия
    // =================================================================

    /** @param camRect положение фронтальной камеры на экране (null — камеры нет / не нашли) */
    fun setGeometry(sw: Float, camRect: RectF?, isLandscape: Boolean) {
        screenW = sw
        landscape = isLandscape
        if (camRect != null && !camRect.isEmpty) {
            cam.set(camRect); hasCam = true
        } else {
            hasCam = false
            val sb = statusBarHeight()
            cam.set(sw / 2f, sb / 2f, sw / 2f, sb / 2f)
        }
        reconcile()
    }

    private fun statusBarHeight(): Float {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimension(id) else 24f * density
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (preview && w > 0) {
            val r = 9.5f * density
            val cy = 22f * density
            setGeometry(w.toFloat(), RectF(w / 2f - r, cy - r, w / 2f + r, cy + r), false)
        }
    }

    private fun computeDims(): Dims {
        val k = Prefs.scale / 100f
        val dp = density * k
        val camH = if (hasCam) cam.height() else 0f
        val baseH = max(camH + 2f * 4.5f * dp, 28f * dp).coerceAtMost(46f * dp)
        return Dims(dp, baseH)
    }

    // =================================================================
    //  Подписка
    // =================================================================

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        IslandHub.addListener(this)
        reconcile()
    }

    override fun onDetachedFromWindow() {
        IslandHub.removeListener(this)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        frameOn = false
        main.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    override fun onIslandChanged() = reconcile()

    private val suppressed: Boolean get() = landscape && Prefs.hideLandscape && !preview

    /** Сверяет, что показывать, с тем, что сейчас в хабе. */
    fun reconcile() {
        if (screenW <= 0f) return
        val list = if (suppressed) emptyList() else IslandHub.visible()
        val np = list.getOrNull(0)
        val ns = list.getOrNull(1)
        val op = primary

        if (np !== op && (np?.key != op?.key || np?.javaClass != op?.javaClass)) {
            prev = op
            sSwap.snap(0f); sSwap.target = 1f
        }
        if (np?.key != op?.key) expanded = false
        if (np != null && np.autoExpand) {
            if (autoSeen.size > 300) autoSeen.clear()
            if (autoSeen.add(np.key + "#" + np.expandToken)) expanded = true
        }
        primary = np
        secondary = ns
        if (ns != null) bubbleAct = ns
        if (np == null || !np.hasExpanded) expanded = false
        retarget()
    }

    fun expand() {
        val p = primary ?: return
        if (!p.hasExpanded || expanded) return
        expanded = true
        retarget()
    }

    fun collapse() {
        if (!expanded) return
        expanded = false
        retarget()
    }

    private fun retarget() {
        if (screenW <= 0f) return
        val d = computeDims()
        dims = d
        val xo = if (preview) 0f else Prefs.xOff * density
        val yo = if (preview) 0f else Prefs.yOff * density
        camW = if (hasCam) cam.width() else 0f
        camCx = cam.centerX() + xo
        top = if (hasCam) cam.centerY() + yo - d.baseH / 2f else d.d(6f) + yo
        top = max(top, d.d(1f))

        val p = primary
        val visible = !suppressed && (p != null || Prefs.showIdle)
        val gap = d.d(8f)
        val padX = d.d(9f)
        var w: Float
        var h: Float
        var r: Float
        var cx = camCx

        when {
            !visible -> {           // растворяемся в камеру
                w = max(camW * 0.9f, d.d(8f)); h = min(d.baseH, max(cam.height(), d.d(8f))) * 0.9f; r = h / 2f
            }
            p == null -> {          // спокойная "пилюля"
                w = if (hasCam) camW + d.baseH * 1.7f else d.d(90f); h = d.baseH; r = h / 2f
            }
            expanded -> {
                w = min(screenW - d.d(22f), d.d(440f))
                h = d.baseH + d.d(6f) + p.expandedH(d, w - d.d(40f)) + d.d(18f)
                r = min(d.d(44f), h / 2f)
                cx = screenW / 2f
                expAct = p
                expW = w
            }
            else -> {
                val m = max(p.leftW(d), p.rightW(d))
                w = camW + 2f * (gap + m + padX)
                h = d.baseH; r = h / 2f
            }
        }
        // не вылезать за края экрана
        val margin = d.d(6f)
        if (cx - w / 2f < margin) cx = margin + w / 2f
        if (cx + w / 2f > screenW - margin) cx = screenW - margin - w / 2f
        tW = w; tH = h; tCx = cx

        if (!initialized) {
            sW.snap(w); sH.snap(h); sR.snap(r); sCx.snap(cx)
            sPres.snap(if (visible) 1f else 0f)
            initialized = true
        }
        sW.target = w; sH.target = h; sR.target = r; sCx.target = cx
        sExp.target = if (expanded) 1f else 0f
        sBub.target = if (secondary != null && !expanded && visible) 1f else 0f
        sPres.target = if (visible) 1f else 0f
        val rc = p?.ringColor ?: 0
        if (rc != 0 && Prefs.ring && visible) {
            ringColor = rc; sRing.target = 1f
        } else sRing.target = 0f

        settleDirty = true
        pushBounds(grow = true)
        kick()
        invalidate()
    }

    /** Подгоняем окно оверлея под остров, чтобы не перекрывать касания вокруг. */
    private fun pushBounds(grow: Boolean) {
        val h = host ?: return
        val d = dims
        tmp.set(tCx - tW / 2f, top, tCx + tW / 2f, top + tH)
        if (grow) {
            tmp2.set(sCx.value - sW.value / 2f, top, sCx.value + sW.value / 2f, top + sH.value)
            tmp.union(tmp2)
        }
        if (secondary != null || sBub.value > 0.01f) tmp.right += d.d(8f) + d.baseH
        val m = d.d(12f) + tmp.width() * 0.04f
        tmp.inset(-m, -m)
        val touchable = primary != null && !suppressed
        h.onBounds(RectF(tmp), touchable)
    }

    // =================================================================
    //  Анимационный цикл
    // =================================================================

    private var frameOn = false
    private var lastNs = 0L
    private val frameCb = Choreographer.FrameCallback { ns -> onFrame(ns) }
    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            when (activeFrameMode()) {
                FrameMode.TICK -> main.postDelayed(this, 500)
                FrameMode.CONTINUOUS -> kick()
                FrameMode.NONE -> {}
            }
        }
    }

    private fun kick() {
        if (frameOn) return
        frameOn = true
        lastNs = 0L
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun activeFrameMode(): FrameMode {
        var m = FrameMode.NONE
        fun upd(a: IslandActivity?) {
            if (a == null) return
            val f = a.frameMode
            if (f.ordinal > m.ordinal) m = f
        }
        if (sPres.value > 0.01f) {
            if (sExp.value < 0.99f) upd(primary)
            if (sBub.value > 0.01f) upd(bubbleAct)
            if (sExp.value > 0.01f) upd(expAct)
        }
        return m
    }

    private fun onFrame(ns: Long) {
        val dt = if (lastNs == 0L) 1f / 60f else ((ns - lastNs) / 1e9f).coerceIn(0.001f, 1f / 24f)
        lastNs = ns
        var moving = false
        for (s in springs) if (s.step(dt)) moving = true
        invalidate()
        if (!moving && settleDirty) {
            settleDirty = false
            if (sSwap.value >= 1f) prev = null
            if (sBub.value <= 0f && secondary == null) bubbleAct = null
            if (sExp.value <= 0f) expAct = null
            pushBounds(grow = false)
        }
        val mode = activeFrameMode()
        if (moving || mode == FrameMode.CONTINUOUS) {
            Choreographer.getInstance().postFrameCallback(frameCb)
        } else {
            frameOn = false
            main.removeCallbacks(tick)
            if (mode == FrameMode.TICK) main.postDelayed(tick, 500)
        }
    }

    // =================================================================
    //  Рисование
    // =================================================================

    override fun onDraw(c: Canvas) {
        if (screenW <= 0f || !initialized) return
        val d = dims
        val pres = sPres.value
        c.save()
        c.translate(-originX, -originY)

        val cx = sCx.value
        val w = max(sW.value, 1f)
        val h = max(sH.value, 1f)
        val r = min(sR.value, h / 2f).coerceAtLeast(0f)
        curRect.set(cx - w / 2f, top, cx + w / 2f, top + h)

        if (pres > 0.01f) {
            val ps = sPress.value
            c.save()
            if (ps != 1f) c.scale(ps, ps, cx, top + h / 2f)

            // обводка
            val ra = sRing.value
            if (ra > 0.01f) {
                val rw = d.d(3f)
                G.fill.color = G.alpha(ringColor, ra * pres)
                tmp.set(curRect.left - rw, curRect.top - rw, curRect.right + rw, curRect.bottom + rw)
                c.drawRoundRect(tmp, r + rw, r + rw, G.fill)
            }

            // кружок второй активности + "капля"
            val b = sBub.value
            val ba = bubbleAct
            if (b > 0.005f && ba != null) drawBubble(c, b, pres, d, ba)
            else bubbleRect.setEmpty()

            // сам остров
            G.fill.color = G.alpha(Color.BLACK, pres)
            c.drawRoundRect(curRect, r, r, G.fill)

            // контент
            islandPath.reset()
            islandPath.addRoundRect(curRect, r, r, Path.Direction.CW)
            c.save()
            c.clipPath(islandPath)
            val e = sExp.value
            val ca = (1f - G.smooth(e, 0f, 0.4f)) * pres
            if (ca > 0.01f) {
                val sw = sSwap.value
                val pv = prev
                if (pv != null && sw < 0.99f) drawCompact(c, pv, d, ca * (1f - sw))
                primary?.let { drawCompact(c, it, d, ca * sw) }
            }
            hits.clear()
            val ea = G.smooth(e, 0.45f, 1f) * pres
            val xa = expAct
            if (ea > 0.01f && xa != null) drawExpandedContent(c, xa, d, ea)
            c.restore()
            c.restore()
        }

        if (preview) drawFakeCamera(c)
        c.restore()
    }

    private fun drawCompact(c: Canvas, a: IslandActivity, d: Dims, alpha: Float) {
        if (alpha <= 0.01f) return
        val gap = d.d(8f)
        val padX = d.d(9f)
        val icx = curRect.centerX()
        val ty = curRect.top
        val l = RectF(curRect.left + padX, ty, icx - camW / 2f - gap, ty + d.baseH)
        val rr = RectF(icx + camW / 2f + gap, ty, curRect.right - padX, ty + d.baseH)
        c.saveLayerAlpha(curRect, (alpha * 255).toInt())
        a.drawLeft(c, l, d)
        a.drawRight(c, rr, d)
        c.restore()
    }

    private fun drawExpandedContent(c: Canvas, a: IslandActivity, d: Dims, alpha: Float) {
        val w = expW
        var cx = screenW / 2f
        val margin = d.d(6f)
        if (cx - w / 2f < margin) cx = margin + w / 2f
        val left = cx - w / 2f + d.d(20f)
        val right = cx + w / 2f - d.d(20f)
        val ct = top + d.baseH + d.d(6f)
        val ch = a.expandedH(d, right - left)
        val content = RectF(left, ct, right, ct + ch)
        val k = 0.92f + 0.08f * alpha
        c.saveLayerAlpha(curRect, (alpha * 255).toInt())
        c.scale(k, k, content.centerX(), top)
        a.drawExpanded(c, content, d, hits)
        c.restore()
    }

    private fun drawBubble(c: Canvas, b: Float, pres: Float, d: Dims, a: IslandActivity) {
        val rad = d.baseH / 2f
        val cy = top + d.baseH / 2f
        val start = curRect.right - rad
        val fin = curRect.right + d.d(7f) + rad
        val bx = G.lerp(start, fin, b)
        val br = rad * G.lerp(0.5f, 1f, b.coerceIn(0f, 1.2f))
        G.fill.color = G.alpha(Color.BLACK, pres)
        c.drawCircle(bx, cy, br, G.fill)
        if (Metaball.build(ballPath, curRect.right - rad, cy, rad, bx, cy, br)) c.drawPath(ballPath, G.fill)
        bubbleRect.set(bx - br, cy - br, bx + br, cy + br)
        val ca = G.smooth(b, 0.55f, 1f) * pres
        if (ca > 0.01f) {
            c.saveLayerAlpha(bubbleRect, (ca * 255).toInt())
            ballPath.reset()
            ballPath.addCircle(bx, cy, br, Path.Direction.CW)
            c.clipPath(ballPath)
            a.drawMinimal(c, bx, cy, br, d)
            c.restore()
        }
    }

    private fun drawFakeCamera(c: Canvas) {
        val cx = cam.centerX()
        val cy = cam.centerY()
        val rr = cam.width() / 2f
        G.circle(c, cx, cy, rr, 0xFF0B0B0D.toInt())
        G.circle(c, cx, cy, rr * 0.62f, 0xFF151B26.toInt())
        G.circle(c, cx - rr * 0.22f, cy - rr * 0.22f, rr * 0.16f, 0x553A5A8A)
    }

    // =================================================================
    //  Касания
    // =================================================================

    private var downX = 0f
    private var downY = 0f
    private var downIn = false
    private var downBubble = false
    private var moved = false
    private var longFired = false
    private var swiped = false

    private val longPress = Runnable {
        longFired = true
        sPress.target = 1f
        kick()
        if (downBubble) {
            val ba = bubbleAct ?: return@Runnable
            IslandHub.focus(ba.key)
            expand()
            Haptics.heavy(context)
        } else if (!expanded && primary?.hasExpanded == true) {
            expand()
            Haptics.heavy(context)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x + originX
        val y = e.y + originY
        val d = dims
        when (e.actionMasked) {
            MotionEvent.ACTION_OUTSIDE -> {
                collapse(); return false
            }
            MotionEvent.ACTION_DOWN -> {
                downIn = curRect.contains(x, y)
                tmp.set(bubbleRect); tmp.inset(-d.d(4f), -d.d(4f))
                downBubble = !downIn && sBub.value > 0.5f && tmp.contains(x, y)
                if (!downIn && !downBubble) {
                    collapse(); return false
                }
                downX = x; downY = y
                moved = false; longFired = false; swiped = false
                if (!expanded) {
                    sPress.target = 1.05f; kick()
                }
                main.postDelayed(longPress, 350L)
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = x - downX
                val dy = y - downY
                if (!moved && (abs(dx) > d.d(10f) || abs(dy) > d.d(10f))) {
                    moved = true
                    main.removeCallbacks(longPress)
                    sPress.target = 1f; kick()
                }
                if (moved && !swiped && !longFired) {
                    val th = d.d(30f)
                    if (dy < -th) {
                        swiped = true
                        collapse()
                    } else if (dy > th && !expanded && downIn) {
                        swiped = true
                        if (primary?.hasExpanded == true) {
                            expand(); Haptics.tick(context)
                        }
                    } else if (abs(dx) > d.d(44f) && !expanded && downIn) {
                        swiped = true
                        hSwipe()
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                main.removeCallbacks(longPress)
                sPress.target = 1f; kick()
                if (!moved && !longFired) tap(x, y)
            }
            MotionEvent.ACTION_CANCEL -> {
                main.removeCallbacks(longPress)
                sPress.target = 1f; kick()
            }
        }
        return true
    }

    /** Свайп вбок: две активности — поменять местами, одна — спрятать (как в iOS). */
    private fun hSwipe() {
        val s = secondary
        val p = primary ?: return
        if (s != null) IslandHub.focus(s.key) else IslandHub.dismiss(p.key)
        Haptics.tick(context)
    }

    private fun tap(x: Float, y: Float) {
        val ctx = context
        if (downBubble) {
            val ba = bubbleAct ?: return
            if (!ba.onTap(ctx)) {
                IslandHub.focus(ba.key); expand()
            }
            Haptics.tick(ctx)
            return
        }
        val p = primary ?: return
        if (expanded) {
            val h = hits.find(x, y)
            if (h != null) {
                Haptics.tick(ctx)
                h(x, y)
                return
            }
            if (p.onTap(ctx)) collapse()
            return
        }
        if (Prefs.tapExpands && p.hasExpanded) {
            expand(); Haptics.tick(ctx); return
        }
        if (!p.onTap(ctx) && p.hasExpanded) {
            expand(); Haptics.tick(ctx)
        }
    }
}
