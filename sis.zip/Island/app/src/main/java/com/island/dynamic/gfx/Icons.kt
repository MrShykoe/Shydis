package com.island.dynamic.gfx

import android.graphics.Path

/** Мини-парсер SVG path (M L H V C S Z, абсолютные и относительные). */
object SvgPath {
    fun parse(d: String): Path {
        val p = Path()
        var i = 0
        val n = d.length
        var cx = 0f; var cy = 0f
        var sx = 0f; var sy = 0f
        var lcx = 0f; var lcy = 0f
        var cmd = ' '
        var prevCubic = false

        fun skip() {
            while (i < n && (d[i] == ' ' || d[i] == ',' || d[i] == '\n' || d[i] == '\t')) i++
        }

        fun num(): Float {
            skip()
            val st = i
            if (i < n && (d[i] == '-' || d[i] == '+')) i++
            var dot = false
            while (i < n) {
                val ch = d[i]
                if (ch.isDigit()) i++
                else if (ch == '.' && !dot) { dot = true; i++ }
                else if (ch == 'e' || ch == 'E') {
                    i++
                    if (i < n && (d[i] == '-' || d[i] == '+')) i++
                } else break
            }
            return d.substring(st, i).toFloat()
        }

        while (true) try {
            skip()
            if (i >= n) break
            val ch = d[i]
            if (ch.isLetter()) {
                cmd = ch
                i++
            } else if (cmd == 'Z' || cmd == 'z' || cmd == ' ') {
                i++
                continue
            }
            var isCubic = false
            when (cmd) {
                'M' -> { cx = num(); cy = num(); p.moveTo(cx, cy); sx = cx; sy = cy; cmd = 'L' }
                'm' -> { cx += num(); cy += num(); p.moveTo(cx, cy); sx = cx; sy = cy; cmd = 'l' }
                'L' -> { cx = num(); cy = num(); p.lineTo(cx, cy) }
                'l' -> { cx += num(); cy += num(); p.lineTo(cx, cy) }
                'H' -> { cx = num(); p.lineTo(cx, cy) }
                'h' -> { cx += num(); p.lineTo(cx, cy) }
                'V' -> { cy = num(); p.lineTo(cx, cy) }
                'v' -> { cy += num(); p.lineTo(cx, cy) }
                'C' -> {
                    val x1 = num(); val y1 = num(); val x2 = num(); val y2 = num(); val x = num(); val y = num()
                    p.cubicTo(x1, y1, x2, y2, x, y)
                    lcx = x2; lcy = y2; cx = x; cy = y; isCubic = true
                }
                'c' -> {
                    val x1 = cx + num(); val y1 = cy + num(); val x2 = cx + num(); val y2 = cy + num()
                    val x = cx + num(); val y = cy + num()
                    p.cubicTo(x1, y1, x2, y2, x, y)
                    lcx = x2; lcy = y2; cx = x; cy = y; isCubic = true
                }
                'S' -> {
                    val x1 = if (prevCubic) 2 * cx - lcx else cx
                    val y1 = if (prevCubic) 2 * cy - lcy else cy
                    val x2 = num(); val y2 = num(); val x = num(); val y = num()
                    p.cubicTo(x1, y1, x2, y2, x, y)
                    lcx = x2; lcy = y2; cx = x; cy = y; isCubic = true
                }
                's' -> {
                    val x1 = if (prevCubic) 2 * cx - lcx else cx
                    val y1 = if (prevCubic) 2 * cy - lcy else cy
                    val x2 = cx + num(); val y2 = cy + num(); val x = cx + num(); val y = cy + num()
                    p.cubicTo(x1, y1, x2, y2, x, y)
                    lcx = x2; lcy = y2; cx = x; cy = y; isCubic = true
                }
                'Z', 'z' -> { p.close(); cx = sx; cy = sy }
                else -> i++
            }
            prevCubic = isCubic
        } catch (e: Exception) {
            break
        }
        return p
    }
}

/** Иконки 24x24 (часть — Material Icons, Apache 2.0). */
object Icons {
    val play = SvgPath.parse("M7 4.5v15l12.5-7.5z")
    val pause = SvgPath.parse("M6 4.5h4v15H6zM14 4.5h4v15h-4z")
    val next = SvgPath.parse("M2.5 6l8.5 6l-8.5 6zM11.5 6l8.5 6l-8.5 6z")
    val prev = SvgPath.parse("M21.5 6l-8.5 6l8.5 6zM12.5 6L4 12l8.5 6z")
    val note = SvgPath.parse("M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z")
    val bell = SvgPath.parse("M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z")
    val bellOff = SvgPath.parse("M20 18.69L7.84 6.14 5.27 3.49 4 4.76l2.8 2.8v.01c-.52.99-.8 2.16-.8 3.42v5l-2 2v1h13.73l2 2L21 19.72l-1-1.03zM12 22c1.11 0 2-.89 2-2h-4c0 1.11.89 2 2 2zm6-7.32V11c0-3.08-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68c-.15.03-.29.08-.42.12-.1.03-.2.07-.3.11h-.01c-.01 0-.01 0-.02.01-.23.09-.46.2-.68.31 0 0-.01 0-.01.01L18 14.68z")
    val phone = SvgPath.parse("M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z")
    val callEnd = SvgPath.parse("M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.49-1.87 1.12-2.66 1.85-.18.18-.43.28-.7.28-.28 0-.53-.11-.71-.29L.29 13.08c-.18-.17-.29-.42-.29-.7 0-.28.11-.53.29-.71C3.34 8.78 7.46 7 12 7s8.66 1.78 11.71 4.67c.18.18.29.43.29.71 0 .28-.11.53-.29.71l-2.48 2.48c-.18.18-.43.29-.71.29-.27 0-.52-.11-.7-.28-.79-.74-1.69-1.36-2.67-1.85-.33-.16-.56-.5-.56-.9v-3.1C15.15 9.25 13.6 9 12 9z")
    val timer = SvgPath.parse("M15 1H9v2h6V1zm-4 13h2V8h-2v6zm8.03-6.61l1.42-1.42c-.43-.51-.9-.99-1.41-1.41l-1.42 1.42C16.07 4.74 14.12 4 12 4c-4.97 0-9 4.03-9 9s4.02 9 9 9 9-4.03 9-9c0-2.12-.74-4.07-1.97-5.61zM12 20c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z")
    val close = SvgPath.parse("M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z")
    val headset = SvgPath.parse("M12 1c-4.97 0-9 4.03-9 9v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h3c1.66 0 3-1.34 3-3v-7c0-4.97-4.03-9-9-9z")
    val bolt = SvgPath.parse("M7 2v11h3v9l7-12h-4l4-8z")
    val download = SvgPath.parse("M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z")
}
