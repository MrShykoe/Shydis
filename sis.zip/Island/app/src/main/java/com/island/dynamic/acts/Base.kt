package com.island.dynamic.acts

import android.app.PendingIntent
import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import android.os.SystemClock
import com.island.dynamic.Launcher

enum class FrameMode { NONE, TICK, CONTINUOUS }

/** Размеры текущего кадра: dp с учётом масштаба и высота "пилюли" (baseH). */
class Dims(val dp: Float, val baseH: Float) {
    fun d(v: Float) = v * dp
}

/** Кликабельные зоны развёрнутого острова. */
class Hits {
    private val rects = ArrayList<RectF>()
    private val actions = ArrayList<(Float, Float) -> Unit>()

    fun clear() {
        rects.clear(); actions.clear()
    }

    fun add(l: Float, t: Float, r: Float, b: Float, a: (Float, Float) -> Unit) {
        rects.add(RectF(l, t, r, b)); actions.add(a)
    }

    fun find(x: Float, y: Float): ((Float, Float) -> Unit)? {
        for (i in rects.indices.reversed()) if (rects[i].contains(x, y)) return actions[i]
        return null
    }
}

/**
 * Одна "живая активность" острова. Умеет рисовать себя в трёх видах, как в iOS:
 *  - compact  — слева и справа от камеры
 *  - minimal  — в отделившемся кружке (когда активностей две)
 *  - expanded — большой развёрнутый остров
 */
abstract class IslandActivity(val key: String) {
    open val priority: Int = 0
    open val pkg: String? = null
    open val hideInOwnApp: Boolean = true
    /** Разворачиваться сама при появлении (звонок, уведомление, таймер сработал) */
    open val autoExpand: Boolean = false
    /** Смена токена = новое событие, снова авто-развернуть */
    open val expandToken: String = ""
    /** Цвет обводки острова, 0 — без обводки */
    open val ringColor: Int = 0
    open val hasExpanded: Boolean = true
    open val frameMode: FrameMode = FrameMode.NONE
    open val contentIntent: PendingIntent? = null
    var updatedAt: Long = SystemClock.uptimeMillis()

    abstract fun leftW(d: Dims): Float
    abstract fun rightW(d: Dims): Float
    abstract fun drawLeft(c: Canvas, r: RectF, d: Dims)
    abstract fun drawRight(c: Canvas, r: RectF, d: Dims)

    open fun drawMinimal(c: Canvas, cx: Float, cy: Float, rad: Float, d: Dims) {
        val lw = leftW(d)
        if (lw <= 0f) return
        val k = rad * 2f / d.baseH
        c.save()
        c.scale(k, k, cx, cy)
        drawLeft(c, RectF(cx - lw / 2f, cy - d.baseH / 2f, cx + lw / 2f, cy + d.baseH / 2f), d)
        c.restore()
    }

    /** Высота содержимого развёрнутого вида (без полосы камеры и отступов). */
    open fun expandedH(d: Dims, w: Float): Float = 0f
    open fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {}

    /** Тап: по умолчанию открыть приложение. false — нечего открывать (тогда остров развернётся). */
    open fun onTap(ctx: Context): Boolean {
        if (contentIntent == null && pkg == null) return false
        return Launcher.open(ctx, contentIntent, pkg)
    }

    protected val now: Long get() = SystemClock.uptimeMillis()
    protected val wall: Long get() = System.currentTimeMillis()
}
