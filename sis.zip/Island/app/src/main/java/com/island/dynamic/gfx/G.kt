package com.island.dynamic.gfx

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.text.TextPaint
import android.text.TextUtils
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Цвета в стиле iOS (dark). */
object C {
    val ORANGE = 0xFFFF9F0A.toInt()
    val GREEN = 0xFF30D158.toInt()
    val RED = 0xFFFF453A.toInt()
    val BLUE = 0xFF0A84FF.toInt()
    val GRAY = 0xFF8E8E93.toInt()
    val GRAY2 = 0xFF3A3A3C.toInt()
    val GRAY3 = 0xFF2C2C2E.toInt()
    val CARD = 0xFF1C1C1E.toInt()
    val SUB = 0x99EBEBF5.toInt()
    const val WHITE = Color.WHITE
}

/** Общие кисти и хелперы рисования. Всё рисуется руками на Canvas — без View-иерархии. */
object G {
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    val light: Typeface = Typeface.create(Typeface.DEFAULT, 300, false)
    val regular: Typeface = Typeface.create(Typeface.DEFAULT, 400, false)
    val medium: Typeface = Typeface.create(Typeface.DEFAULT, 500, false)
    val semibold: Typeface = Typeface.create(Typeface.DEFAULT, 600, false)
    val bold: Typeface = Typeface.create(Typeface.DEFAULT, 700, false)

    private val r = RectF()
    private val p = Path()

    private fun setup(size: Float, color: Int, tf: Typeface, tnum: Boolean) {
        text.textSize = size
        text.color = color
        text.typeface = tf
        text.textAlign = Paint.Align.LEFT
        val f = if (tnum) "tnum" else null
        if (text.fontFeatureSettings != f) text.fontFeatureSettings = f
    }

    fun measure(s: CharSequence, size: Float, tf: Typeface = semibold, tnum: Boolean = false): Float {
        setup(size, Color.WHITE, tf, tnum)
        return text.measureText(s, 0, s.length)
    }

    /** Однострочный текст, центрированный по вертикали относительно cy. align: -1 влево, 0 центр, 1 вправо. */
    fun text(
        c: Canvas, s: CharSequence, x: Float, cy: Float, size: Float, color: Int,
        tf: Typeface = semibold, align: Int = -1, maxW: Float = 0f, tnum: Boolean = false
    ) {
        if (s.isEmpty()) return
        setup(size, color, tf, tnum)
        val str: CharSequence =
            if (maxW > 0f && text.measureText(s, 0, s.length) > maxW)
                TextUtils.ellipsize(s, text, maxW, TextUtils.TruncateAt.END)
            else s
        if (str.isEmpty()) return
        val w = text.measureText(str, 0, str.length)
        val x0 = when (align) {
            0 -> x - w / 2f
            1 -> x - w
            else -> x
        }
        val fm = text.fontMetrics
        val base = cy - (fm.ascent + fm.descent) / 2f
        c.drawText(str, 0, str.length, x0, base, text)
    }

    fun rrect(c: Canvas, l: Float, t: Float, rr: Float, b: Float, rad: Float, color: Int) {
        fill.color = color
        r.set(l, t, rr, b)
        c.drawRoundRect(r, rad, rad, fill)
    }

    fun rrectStroke(c: Canvas, l: Float, t: Float, rr: Float, b: Float, rad: Float, w: Float, color: Int) {
        stroke.strokeWidth = w
        stroke.color = color
        r.set(l, t, rr, b)
        c.drawRoundRect(r, rad, rad, stroke)
    }

    fun circle(c: Canvas, cx: Float, cy: Float, rad: Float, color: Int) {
        fill.color = color
        c.drawCircle(cx, cy, rad, fill)
    }

    /** Иконка из пути в координатах 24x24. */
    fun icon(c: Canvas, path: Path, cx: Float, cy: Float, size: Float, color: Int) {
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        val k = size / 24f
        c.scale(k, k)
        fill.color = color
        c.drawPath(path, fill)
        c.restore()
    }

    fun bitmap(c: Canvas, b: Bitmap, l: Float, t: Float, size: Float, rad: Float) {
        c.save()
        r.set(l, t, l + size, t + size)
        p.reset()
        p.addRoundRect(r, rad, rad, Path.Direction.CW)
        c.clipPath(p)
        c.drawBitmap(b, null, r, bmpPaint)
        c.restore()
    }

    fun ring(c: Canvas, cx: Float, cy: Float, rad: Float, w: Float, prog: Float, color: Int, track: Int, startDeg: Float = -90f) {
        stroke.strokeWidth = w
        stroke.color = track
        c.drawCircle(cx, cy, rad, stroke)
        if (prog > 0f) {
            stroke.color = color
            r.set(cx - rad, cy - rad, cx + rad, cy + rad)
            c.drawArc(r, startDeg, 360f * prog.coerceIn(0f, 1f), false, stroke)
        }
    }

    fun alpha(color: Int, a: Float): Int {
        val na = (Color.alpha(color) * a).toInt().coerceIn(0, 255)
        return (color and 0x00FFFFFF) or (na shl 24)
    }

    // ---- эквалайзер ----
    private val PH = floatArrayOf(0f, 1.7f, 3.1f, 4.4f, 0.9f)
    private val FR = floatArrayOf(7.3f, 9.1f, 6.2f, 8.4f, 10.2f)

    fun waveWidth(dp: Float) = dp * (5 * 2.6f + 4 * 2f)

    fun waveform(c: Canvas, right: Float, cy: Float, h: Float, dp: Float, color: Int, amp: Float, t: Float) {
        val bw = dp * 2.6f
        val gap = dp * 2f
        var x = right - waveWidth(dp)
        fill.color = color
        for (i in 0 until 5) {
            val v = abs(sin(t * FR[i] + PH[i]) * 0.6f + sin(t * FR[i] * 0.53f + PH[i] * 1.9f) * 0.4f)
            val hh = max(bw, h * (0.22f + 0.78f * v) * amp)
            r.set(x, cy - hh / 2f, x + bw, cy + hh / 2f)
            c.drawRoundRect(r, bw / 2f, bw / 2f, fill)
            x += bw + gap
        }
    }

    // ---- утилиты ----
    fun fmt(ms: Long): String {
        val s = max(0L, ms) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    /** Строка с цифрами, заменёнными на 0 — для стабильной ширины. */
    fun digitsMask(s: String) = s.replace(Regex("\\d"), "0")

    fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    fun smooth(x: Float, e0: Float, e1: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    fun bmpOf(d: Drawable, size: Int): Bitmap {
        if (d is BitmapDrawable) {
            val src = d.bitmap
            if (src != null) return Bitmap.createScaledBitmap(src, size, size, true)
        }
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return b
    }

    /** Квадратная обрезка по центру + масштаб. */
    fun squareCrop(src: Bitmap, size: Int): Bitmap {
        var b = src
        if (b.config == Bitmap.Config.HARDWARE) b = b.copy(Bitmap.Config.ARGB_8888, false)
        val s = min(b.width, b.height)
        val x = (b.width - s) / 2
        val y = (b.height - s) / 2
        val sq = if (s == b.width && s == b.height) b else Bitmap.createBitmap(b, x, y, s, s)
        return if (s == size) sq else Bitmap.createScaledBitmap(sq, size, size, true)
    }

    /** Круглая иконка с буквой (для демо и звонков без аватара). */
    fun letterIcon(letter: String, color: Int, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.shader = LinearGradient(0f, 0f, 0f, size.toFloat(), lighten(color, 0.25f), color, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), pp)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.color = Color.WHITE
        tp.textSize = size * 0.46f
        tp.typeface = semibold
        tp.textAlign = Paint.Align.CENTER
        val fm = tp.fontMetrics
        c.drawText(letter, size / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, tp)
        return b
    }

    fun lighten(color: Int, k: Float): Int {
        val r = Color.red(color) + ((255 - Color.red(color)) * k).toInt()
        val g = Color.green(color) + ((255 - Color.green(color)) * k).toInt()
        val bl = Color.blue(color) + ((255 - Color.blue(color)) * k).toInt()
        return Color.argb(Color.alpha(color), r, g, bl)
    }

    /** Яркий акцентный цвет из обложки (как iOS подкрашивает эквалайзер). */
    fun accentOf(src: Bitmap): Int {
        return try {
            var b = src
            if (b.config == Bitmap.Config.HARDWARE) b = b.copy(Bitmap.Config.ARGB_8888, false)
            val s = Bitmap.createScaledBitmap(b, 24, 24, true)
            val hsv = FloatArray(3)
            var sr = 0f; var sg = 0f; var sb = 0f; var sw = 0f
            for (y in 0 until 24) for (x in 0 until 24) {
                val px = s.getPixel(x, y)
                Color.colorToHSV(px, hsv)
                val w = hsv[1] * hsv[1] * hsv[2] + 0.002f
                sr += Color.red(px) * w; sg += Color.green(px) * w; sb += Color.blue(px) * w; sw += w
            }
            val col = Color.rgb((sr / sw).toInt(), (sg / sw).toInt(), (sb / sw).toInt())
            Color.colorToHSV(col, hsv)
            hsv[1] = min(hsv[1] * 1.15f, 0.85f)
            hsv[2] = max(hsv[2], 0.88f)
            Color.HSVToColor(hsv)
        } catch (e: Exception) {
            Color.WHITE
        }
    }
}
