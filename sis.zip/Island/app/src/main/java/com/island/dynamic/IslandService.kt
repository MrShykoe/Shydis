package com.island.dynamic

import android.Manifest
import android.annotation.SuppressLint
import android.accessibilityservice.AccessibilityService
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import com.island.dynamic.acts.BluetoothActivity
import com.island.dynamic.acts.ChargingActivity
import com.island.dynamic.acts.SilentActivity
import com.island.dynamic.acts.UnlockActivity
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/**
 * Сервис спец. возможностей — единственный честный способ на Android нарисовать окно
 * поверх статус-бара и выреза камеры (TYPE_ACCESSIBILITY_OVERLAY).
 * Ещё он узнаёт, какое приложение открыто, и слушает системные события.
 */
class IslandService : AccessibilityService(), IslandView.Host {

    companion object {
        var instance: IslandService? = null
            private set
    }

    private var wm: WindowManager? = null
    private var view: IslandView? = null
    private val lp = WindowManager.LayoutParams()
    private var rxOn = false
    private var btOn = false
    private val imePkgs = HashSet<String>()

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED -> if (Prefs.charging) showCharging()
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    if (isInitialStickyBroadcast || !Prefs.silent) return
                    val mode = i.getIntExtra(AudioManager.EXTRA_RINGER_MODE, AudioManager.RINGER_MODE_NORMAL)
                    IslandHub.put(SilentActivity(mode), 2600)
                    Haptics.click(c)
                }
                Intent.ACTION_USER_PRESENT -> if (Prefs.unlock) IslandHub.put(UnlockActivity(), 1500)
                Intent.ACTION_SCREEN_OFF -> view?.collapse()
            }
        }
    }

    private val btRx = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(c: Context, i: Intent) {
            if (!Prefs.bluetooth) return
            val dev: BluetoothDevice? =
                if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            try {
                val major = dev?.bluetoothClass?.majorDeviceClass
                if (major != null && major != BluetoothClass.Device.Major.AUDIO_VIDEO &&
                    major != BluetoothClass.Device.Major.WEARABLE) return
                val name = dev?.name ?: "Наушники"
                IslandHub.put(BluetoothActivity(name), 3500)
            } catch (_: SecurityException) {
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val w = getSystemService(WindowManager::class.java)
        wm = w
        val v = IslandView(this, false)
        v.host = this
        view = v

        lp.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        lp.format = PixelFormat.TRANSLUCENT
        lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode =
            if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        lp.width = 1
        lp.height = 1
        lp.x = 0
        lp.y = 0
        lp.title = "Island"
        try {
            w.addView(v, lp)
        } catch (e: Exception) {
            view = null
            return
        }

        try {
            getSystemService(InputMethodManager::class.java)?.enabledInputMethodList?.forEach { imePkgs.add(it.packageName) }
        } catch (_: Exception) {
        }

        updateGeometry()
        registerReceivers()
        registerBluetooth()
    }

    private fun registerReceivers() {
        if (rxOn) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(rx, f)
        rxOn = true
    }

    fun registerBluetooth() {
        if (btOn) return
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return
        val f = IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(btRx, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(btRx, f)
        btOn = true
    }

    private fun showCharging() {
        val bm = getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 0
        IslandHub.put(ChargingActivity(level.coerceIn(0, 100)), 3500)
        Haptics.click(this)
    }

    // ------------------------------------------------------------------
    //  Где камера
    // ------------------------------------------------------------------

    private fun updateGeometry() {
        val v = view ?: return
        val dm = getSystemService(DisplayManager::class.java) ?: return
        val disp = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return
        val size = Point()
        @Suppress("DEPRECATION")
        disp.getRealSize(size)
        val sw = size.x.toFloat()
        val sh = size.y.toFloat()
        v.setGeometry(sw, findCamera(disp, sw, sh), sw > sh)
    }

    private fun findCamera(disp: Display, sw: Float, sh: Float): RectF? {
        val co = disp.cutout ?: return null
        // Android 12+: точная форма выреза
        if (Build.VERSION.SDK_INT >= 31) {
            val p = co.cutoutPath
            if (p != null) {
                val b = RectF()
                @Suppress("DEPRECATION")
                p.computeBounds(b, true)
                if (!b.isEmpty && b.bottom < sh * 0.15f && b.width() < sw * 0.5f) return b
            }
        }
        val r = co.boundingRectTop
        if (r.isEmpty) return null
        return RectF(r)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateGeometry()
    }

    // ------------------------------------------------------------------
    //  Окно подстраивается под остров
    // ------------------------------------------------------------------

    override fun onBounds(r: RectF, touchable: Boolean) {
        val v = view ?: return
        val w = wm ?: return
        val x = floor(r.left).toInt()
        val y = max(0, floor(r.top).toInt())
        val wd = max(1, ceil(r.right).toInt() - x)
        val ht = max(1, ceil(r.bottom).toInt() - y)
        val flags = if (touchable) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        if (x == lp.x && y == lp.y && wd == lp.width && ht == lp.height && flags == lp.flags) return
        lp.x = x; lp.y = y; lp.width = wd; lp.height = ht; lp.flags = flags
        v.originX = x.toFloat()
        v.originY = y.toFloat()
        try {
            w.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
        v.invalidate()
    }

    // ------------------------------------------------------------------

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        if (p == "com.android.systemui" || p == "android" || p in imePkgs) return
        IslandHub.foregroundPkg = p
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        if (rxOn) try { unregisterReceiver(rx) } catch (_: Exception) {}
        if (btOn) try { unregisterReceiver(btRx) } catch (_: Exception) {}
        rxOn = false; btOn = false
        view?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        view = null
        super.onDestroy()
    }
}
