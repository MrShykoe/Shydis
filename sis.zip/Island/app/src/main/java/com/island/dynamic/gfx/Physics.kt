package com.island.dynamic.gfx

import android.graphics.Path
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Пружина как у Apple (stiffness + damping ratio). damping < 1 — с перелётом ("резиновый" остров).
 */
class Spring(initial: Float, var stiffness: Float, var damping: Float, private val eps: Float) {
    var value = initial
    var target = initial
    var velocity = 0f

    val moving: Boolean get() = value != target || velocity != 0f

    fun snap(v: Float) {
        value = v; target = v; velocity = 0f
    }

    /** @return true — ещё движется */
    fun step(dt: Float): Boolean {
        if (!moving) return false
        val c = 2f * damping * sqrt(stiffness)
        var t = dt
        while (t > 0f) {
            val h = min(t, 1f / 240f)
            val a = -stiffness * (value - target) - c * velocity
            velocity += a * h
            value += velocity * h
            t -= h
        }
        if (abs(value - target) < eps && abs(velocity) < eps * 8f) {
            value = target; velocity = 0f
            return false
        }
        return true
    }
}

/**
 * "Капля", которая тянется между островом и отделяющимся кружком (как в iOS при двух активностях).
 * Алгоритм metaball-коннектора Hiroyuki Sato.
 */
object Metaball {
    private val PIf = PI.toFloat()
    private val HALF_PI = (PI / 2).toFloat()

    fun build(out: Path, x1: Float, y1: Float, r1: Float, x2: Float, y2: Float, r2: Float,
              handle: Float = 2.4f, v: Float = 0.5f): Boolean {
        out.reset()
        val d = hypot(x2 - x1, y2 - y1)
        val maxD = r1 + r2 * 2.5f
        if (r1 <= 0f || r2 <= 0f || d > maxD || d <= abs(r1 - r2)) return false

        val u1: Float
        val u2: Float
        if (d < r1 + r2) {
            u1 = acos(((r1 * r1 + d * d - r2 * r2) / (2f * r1 * d)).coerceIn(-1f, 1f))
            u2 = acos(((r2 * r2 + d * d - r1 * r1) / (2f * r2 * d)).coerceIn(-1f, 1f))
        } else {
            u1 = 0f; u2 = 0f
        }
        val ab = atan2(y2 - y1, x2 - x1)
        val maxSpread = acos(((r1 - r2) / d).coerceIn(-1f, 1f))

        val a1 = ab + u1 + (maxSpread - u1) * v
        val a2 = ab - u1 - (maxSpread - u1) * v
        val a3 = ab + PIf - u2 - (PIf - u2 - maxSpread) * v
        val a4 = ab - PIf + u2 + (PIf - u2 - maxSpread) * v

        val p1x = x1 + r1 * cos(a1); val p1y = y1 + r1 * sin(a1)
        val p2x = x1 + r1 * cos(a2); val p2y = y1 + r1 * sin(a2)
        val p3x = x2 + r2 * cos(a3); val p3y = y2 + r2 * sin(a3)
        val p4x = x2 + r2 * cos(a4); val p4y = y2 + r2 * sin(a4)

        val total = r1 + r2
        val d2base = min(v * handle, hypot(p3x - p1x, p3y - p1y) / total)
        val d2 = d2base * min(1f, d * 2f / total)
        val h1 = r1 * d2
        val h2 = r2 * d2

        val h1x = p1x + h1 * cos(a1 - HALF_PI); val h1y = p1y + h1 * sin(a1 - HALF_PI)
        val h2x = p2x + h1 * cos(a2 + HALF_PI); val h2y = p2y + h1 * sin(a2 + HALF_PI)
        val h3x = p3x + h2 * cos(a3 + HALF_PI); val h3y = p3y + h2 * sin(a3 + HALF_PI)
        val h4x = p4x + h2 * cos(a4 - HALF_PI); val h4y = p4y + h2 * sin(a4 - HALF_PI)

        out.moveTo(p1x, p1y)
        out.cubicTo(h1x, h1y, h3x, h3y, p3x, p3y)
        out.lineTo(p4x, p4y)
        out.cubicTo(h4x, h4y, h2x, h2y, p2x, p2y)
        out.close()
        return true
    }
}
