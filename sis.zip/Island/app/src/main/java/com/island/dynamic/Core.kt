package com.island.dynamic

import android.app.ActivityOptions
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.LruCache
import com.island.dynamic.acts.IslandActivity
import com.island.dynamic.gfx.G

class App : Application() {
    companion object {
        lateinit var instance: App
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)
    }
}

/**
 * Центральное хранилище "живых активностей". Сервисы кладут сюда активности,
 * острова (оверлей и превью в приложении) подписываются и перерисовываются.
 */
object IslandHub {
    fun interface Listener {
        fun onIslandChanged()
    }

    val handler = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<Listener>()
    private val acts = LinkedHashMap<String, IslandActivity>()
    private val expiries = HashMap<String, Runnable>()
    private val dismissed = HashSet<String>()

    /** Активность, которую пользователь вытащил вперёд свайпом/долгим тапом по кружку. */
    var focusKey: String? = null
        private set

    /** Приложение на экране — его собственная активность прячется (как в iOS). */
    var foregroundPkg: String? = null
        set(v) {
            if (field != v) {
                field = v; changed()
            }
        }

    fun addListener(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    fun get(key: String): IslandActivity? = acts[key]

    /**
     * @param durationMs >0 — временная активность, сама исчезнет
     * @param bump — "новое событие": снимает скрытие свайпом и поднимает в очереди
     */
    fun put(a: IslandActivity, durationMs: Long = 0L, bump: Boolean = true) {
        acts[a.key] = a
        if (bump) {
            dismissed.remove(a.key)
            a.updatedAt = SystemClock.uptimeMillis()
        }
        expiries.remove(a.key)?.let { handler.removeCallbacks(it) }
        if (durationMs > 0) {
            val key = a.key
            val r = Runnable {
                expiries.remove(key)
                if (acts[key] === a) remove(key)
            }
            expiries[key] = r
            handler.postDelayed(r, durationMs)
        }
        changed()
    }

    fun remove(key: String) {
        expiries.remove(key)?.let { handler.removeCallbacks(it) }
        if (acts.remove(key) != null) {
            dismissed.remove(key)
            if (focusKey == key) focusKey = null
            changed()
        }
    }

    fun dismiss(key: String) {
        dismissed.add(key)
        if (focusKey == key) focusKey = null
        changed()
    }

    fun focus(key: String) {
        focusKey = key
        dismissed.remove(key)
        changed()
    }

    fun clearAll() {
        expiries.values.forEach { handler.removeCallbacks(it) }
        expiries.clear()
        acts.clear()
        dismissed.clear()
        focusKey = null
        changed()
    }

    fun visible(): List<IslandActivity> =
        acts.values
            .filter { it.key !in dismissed && !(it.hideInOwnApp && it.pkg != null && it.pkg == foregroundPkg) }
            .sortedWith(
                compareByDescending<IslandActivity> { it.priority + if (it.key == focusKey) 30 else 0 }
                    .thenByDescending { it.updatedAt }
            )

    fun changed() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { changed() }
            return
        }
        for (l in listeners.toList()) l.onIslandChanged()
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        sp = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    }

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun setB(k: String, v: Boolean) {
        sp.edit().putBoolean(k, v).apply(); IslandHub.changed()
    }

    private fun setI(k: String, v: Int) {
        sp.edit().putInt(k, v).apply(); IslandHub.changed()
    }

    /** Показывать чёрную "пилюлю" вокруг камеры, когда ничего не происходит */
    var showIdle: Boolean get() = b("idle", true); set(v) = setB("idle", v)
    /** Цветная обводка (таймер — оранжевая, звонок — зелёная) */
    var ring: Boolean get() = b("ring", true); set(v) = setB("ring", v)
    /** Короткий тап разворачивает (по умолчанию как в iOS: тап — открыть, удержание — развернуть) */
    var tapExpands: Boolean get() = b("tapexp", false); set(v) = setB("tapexp", v)
    var hideLandscape: Boolean get() = b("land", true); set(v) = setB("land", v)
    var haptics: Boolean get() = b("haptic", true); set(v) = setB("haptic", v)

    var media: Boolean get() = b("media", true); set(v) = setB("media", v)
    var notifs: Boolean get() = b("notifs", true); set(v) = setB("notifs", v)
    var live: Boolean get() = b("live", true); set(v) = setB("live", v)
    var charging: Boolean get() = b("charge", true); set(v) = setB("charge", v)
    var silent: Boolean get() = b("silent", true); set(v) = setB("silent", v)
    var unlock: Boolean get() = b("unlock", true); set(v) = setB("unlock", v)
    var bluetooth: Boolean get() = b("bt", true); set(v) = setB("bt", v)

    /** Размер, % */
    var scale: Int get() = sp.getInt("scale", 100); set(v) = setI("scale", v)
    /** Сдвиг, dp */
    var yOff: Int get() = sp.getInt("yoff", 0); set(v) = setI("yoff", v)
    var xOff: Int get() = sp.getInt("xoff", 0); set(v) = setI("xoff", v)
}

object Haptics {
    private fun vib(ctx: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
        else ctx.getSystemService(Vibrator::class.java)

    private fun play(ctx: Context, e: Int) {
        if (!Prefs.haptics) return
        try {
            vib(ctx)?.vibrate(VibrationEffect.createPredefined(e))
        } catch (_: Exception) {
        }
    }

    fun tick(ctx: Context) = play(ctx, VibrationEffect.EFFECT_TICK)
    fun click(ctx: Context) = play(ctx, VibrationEffect.EFFECT_CLICK)
    fun heavy(ctx: Context) = play(ctx, VibrationEffect.EFFECT_HEAVY_CLICK)

    fun alarm(ctx: Context) {
        try {
            vib(ctx)?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 350, 200, 350, 200, 350, 600, 350, 200, 350), -1))
        } catch (_: Exception) {
        }
    }

    fun stop(ctx: Context) {
        try {
            vib(ctx)?.cancel()
        } catch (_: Exception) {
        }
    }
}

object Launcher {
    private fun opts() =
        if (Build.VERSION.SDK_INT >= 34)
            ActivityOptions.makeBasic()
                .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                .toBundle()
        else null

    /** Выполнить действие уведомления (ответить, сбросить...) */
    fun send(ctx: Context, pi: PendingIntent?): Boolean {
        if (pi == null) return false
        return try {
            pi.send(ctx, 0, null, null, null, null, opts()); true
        } catch (e: Exception) {
            false
        }
    }

    /** Открыть приложение: сначала contentIntent уведомления, иначе лаунчер пакета. */
    fun open(ctx: Context, pi: PendingIntent?, pkg: String?): Boolean {
        if (send(ctx, pi)) return true
        if (pkg == null) return false
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            ctx.startActivity(i); true
        } catch (e: Exception) {
            false
        }
    }
}

object AppIcons {
    private val cache = LruCache<String, Bitmap>(48)

    fun get(ctx: Context, pkg: String?): Bitmap? {
        if (pkg == null) return null
        cache.get(pkg)?.let { return it }
        return try {
            val dr = ctx.packageManager.getApplicationIcon(pkg)
            G.bmpOf(dr, 128).also { cache.put(pkg, it) }
        } catch (e: Exception) {
            null
        }
    }

    fun label(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
