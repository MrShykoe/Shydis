package com.island.dynamic.acts

import android.app.PendingIntent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import com.island.dynamic.App
import com.island.dynamic.Haptics
import com.island.dynamic.IslandHub
import com.island.dynamic.Launcher
import com.island.dynamic.gfx.C
import com.island.dynamic.gfx.G
import com.island.dynamic.gfx.Icons
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// =====================================================================
//  Уведомление
// =====================================================================
class NotificationActivity(
    override val pkg: String?,
    private val appName: String,
    private val title: String,
    private val text: String,
    private val appIcon: Bitmap?,
    private val largeIcon: Bitmap?,
    override val contentIntent: PendingIntent?,
    token: Long
) : IslandActivity("notif") {
    override val priority = 90
    override val autoExpand = true
    override val expandToken = token.toString()
    override val hideInOwnApp = false

    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private var layout: StaticLayout? = null
    private var layoutW = -1
    private var layoutSize = -1f

    private fun body(w: Int, d: Dims): StaticLayout {
        val size = d.d(14.5f)
        val l = layout
        if (l != null && layoutW == w && layoutSize == size) return l
        tp.textSize = size
        tp.color = C.SUB
        tp.typeface = G.regular
        val nl = StaticLayout.Builder.obtain(text, 0, text.length, tp, max(1, w))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setMaxLines(3)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setLineSpacing(0f, 1.04f)
            .build()
        layout = nl; layoutW = w; layoutSize = size
        return nl
    }

    private val icon: Bitmap? get() = largeIcon ?: appIcon

    override fun leftW(d: Dims) = d.baseH * 0.64f
    override fun rightW(d: Dims) = min(G.measure(title.ifEmpty { appName }, d.d(13.5f)), d.d(96f))

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.64f
        val b = icon
        if (b != null) G.bitmap(c, b, r.left, r.centerY() - s / 2f, s, if (largeIcon != null) s / 2f else s * 0.24f)
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.text(c, title.ifEmpty { appName }, r.right, r.centerY(), d.d(13.5f), C.WHITE, align = 1, maxW = d.d(96f))
    }

    override fun expandedH(d: Dims, w: Float): Float {
        val iconS = d.d(42f)
        val tw = (w - iconS - d.d(12f)).toInt()
        val bh = if (text.isEmpty()) 0f else body(tw, d).height.toFloat()
        return max(iconS, d.d(21f) + bh)
    }

    override fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {
        val s = d.d(42f)
        val li = largeIcon
        val ai = appIcon
        if (li != null) {
            G.bitmap(c, li, r.left, r.top, s, s / 2f)
            if (ai != null) {
                val bs = d.d(17f)
                val bx = r.left + s - bs + d.d(3f)
                val by = r.top + s - bs + d.d(3f)
                G.circle(c, bx + bs / 2f, by + bs / 2f, bs / 2f + d.d(2f), Color.BLACK)
                G.bitmap(c, ai, bx, by, bs, bs / 2f)
            }
        } else if (ai != null) {
            G.bitmap(c, ai, r.left, r.top, s, d.d(10f))
        }
        val tx = r.left + s + d.d(12f)
        val w = r.right - tx
        val ts = d.d(12.5f)
        val nowW = G.measure("сейчас", ts, G.medium)
        G.text(c, title.ifEmpty { appName }, tx, r.top + d.d(9f), d.d(15.5f), C.WHITE, G.semibold, maxW = w - nowW - d.d(8f))
        G.text(c, "сейчас", r.right, r.top + d.d(9f), ts, C.GRAY, G.medium, align = 1)
        if (text.isNotEmpty()) {
            val l = body(w.toInt(), d)
            c.save()
            c.translate(tx, r.top + d.d(20f))
            l.draw(c)
            c.restore()
        }
    }

    override fun onTap(ctx: Context): Boolean {
        val ok = Launcher.open(ctx, contentIntent, pkg)
        IslandHub.remove(key)
        return ok
    }
}

// =====================================================================
//  Звонок (входящий / идёт разговор)
// =====================================================================
class CallActivity(
    key: String,
    override val pkg: String?,
    val name: String,
    val sub: String,
    private val avatar: Bitmap?,
    val incoming: Boolean,
    val startWall: Long,
    private val answer: PendingIntent?,
    private val decline: PendingIntent?,
    override val contentIntent: PendingIntent?,
    private val demo: Boolean = false
) : IslandActivity(key) {
    override val priority = if (incoming) 95 else 80
    override val autoExpand = incoming
    override val hideInOwnApp = !incoming
    override val ringColor = if (incoming) 0 else C.GREEN
    override val frameMode = if (incoming) FrameMode.CONTINUOUS else FrameMode.TICK

    private fun duration() = G.fmt(wall - startWall)
    private fun rightText() = if (incoming) "Вызов" else duration()

    private fun pulse() = if (incoming) 0.55f + 0.45f * ((sin(now / 160.0) + 1.0) / 2.0).toFloat() else 1f

    override fun leftW(d: Dims) = d.baseH * 0.58f
    override fun rightW(d: Dims) = G.measure(G.digitsMask(rightText()), d.d(14f), tnum = true)

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.58f
        G.icon(c, Icons.phone, r.left + s / 2f, r.centerY(), s, G.alpha(C.GREEN, pulse()))
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.text(c, rightText(), r.right, r.centerY(), d.d(14f), C.GREEN, align = 1, tnum = true)
    }

    override fun expandedH(d: Dims, w: Float) = d.d(50f)

    override fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {
        val a = d.d(48f)
        val cy = r.top + a / 2f
        val av = avatar
        if (av != null) G.bitmap(c, av, r.left, r.top, a, a / 2f)
        else {
            G.circle(c, r.left + a / 2f, cy, a / 2f, C.GRAY2)
            G.text(c, name.take(1).uppercase(), r.left + a / 2f, cy, d.d(20f), C.WHITE, G.semibold, align = 0)
        }
        val b = d.d(48f)
        val gap = d.d(14f)
        val showAccept = incoming
        val btnLeft = if (showAccept) r.right - 2 * b - gap else r.right - b
        val tx = r.left + a + d.d(12f)
        val maxW = btnLeft - tx - d.d(10f)
        G.text(c, if (incoming) sub.ifEmpty { "Входящий вызов" } else duration(), tx, cy - d.d(10f), d.d(13f), C.SUB, G.medium, maxW = maxW, tnum = !incoming)
        G.text(c, name, tx, cy + d.d(9f), d.d(18f), C.WHITE, G.semibold, maxW = maxW)

        // сбросить
        val dx = btnLeft + b / 2f
        G.circle(c, dx, cy, b / 2f, C.RED)
        G.icon(c, Icons.callEnd, dx, cy, b * 0.52f, C.WHITE)
        hits.add(dx - b / 2f, cy - b / 2f, dx + b / 2f, cy + b / 2f) { _, _ -> onDecline() }
        if (showAccept) {
            val ax = r.right - b / 2f
            G.circle(c, ax, cy, b / 2f, C.GREEN)
            G.icon(c, Icons.phone, ax, cy, b * 0.46f, C.WHITE)
            hits.add(ax - b / 2f, cy - b / 2f, ax + b / 2f, cy + b / 2f) { _, _ -> onAccept() }
        }
    }

    private fun onAccept() {
        val ctx = App.instance
        if (demo || answer == null) {
            if (demo) IslandHub.put(
                CallActivity(key, pkg, name, sub, avatar, false, System.currentTimeMillis(), null, null, null, true)
            ) else Launcher.open(ctx, contentIntent, pkg)
            return
        }
        Launcher.send(ctx, answer)
    }

    private fun onDecline() {
        if (demo) {
            IslandHub.remove(key); return
        }
        if (!Launcher.send(App.instance, decline)) Launcher.open(App.instance, contentIntent, pkg)
    }
}

// =====================================================================
//  Любое уведомление с хронометром: таймер/секундомер часов, запись экрана, навигация...
// =====================================================================
class ChronoActivity(
    key: String,
    override val pkg: String?,
    private val icon: Bitmap?,
    private val title: String,
    private val text: String,
    private val baseWall: Long,
    private val countDown: Boolean,
    override val contentIntent: PendingIntent?
) : IslandActivity(key) {
    override val priority = 60
    override val frameMode = FrameMode.TICK
    override val ringColor = if (countDown) C.ORANGE else 0
    private val color = if (countDown) C.ORANGE else C.WHITE

    private fun time() = if (countDown) G.fmt(max(0L, baseWall - wall) + 999) else G.fmt(wall - baseWall)

    override fun leftW(d: Dims) = d.baseH * 0.6f
    override fun rightW(d: Dims) = G.measure(G.digitsMask(time()), d.d(14f), tnum = true)

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.6f
        val b = icon
        if (b != null) G.bitmap(c, b, r.left, r.centerY() - s / 2f, s, s / 2f)
        else G.icon(c, Icons.timer, r.left + s / 2f, r.centerY(), s, color)
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.text(c, time(), r.right, r.centerY(), d.d(14f), color, align = 1, tnum = true)
    }

    override fun expandedH(d: Dims, w: Float) = d.d(46f)

    override fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {
        val s = d.d(40f)
        val cy = r.top + d.d(23f)
        icon?.let { G.bitmap(c, it, r.left, cy - s / 2f, s, s / 2f) }
        val big = d.d(34f)
        val tw = G.measure(time(), big, G.light, true)
        val tx = r.left + s + d.d(12f)
        val maxW = r.right - tw - d.d(12f) - tx
        G.text(c, title, tx, cy - d.d(9f), d.d(15f), C.WHITE, G.semibold, maxW = maxW)
        G.text(c, text, tx, cy + d.d(10f), d.d(13f), C.SUB, G.regular, maxW = maxW)
        G.text(c, time(), r.right, cy, big, color, G.light, align = 1, tnum = true)
    }
}

// =====================================================================
//  Прогресс (загрузки, отправка файлов, обновления)
// =====================================================================
class ProgressActivity(
    key: String,
    override val pkg: String?,
    private val icon: Bitmap?,
    private val title: String,
    /** 0..1, или <0 — неопределённый */
    private val progress: Float,
    override val contentIntent: PendingIntent?
) : IslandActivity(key) {
    override val priority = 40
    override val frameMode = if (progress < 0f) FrameMode.CONTINUOUS else FrameMode.NONE

    override fun leftW(d: Dims) = d.baseH * 0.6f
    override fun rightW(d: Dims) = d.d(19f)

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.6f
        val b = icon
        if (b != null) G.bitmap(c, b, r.left, r.centerY() - s / 2f, s, s * 0.26f)
        else G.icon(c, Icons.download, r.left + s / 2f, r.centerY(), s, C.BLUE)
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, rad: Float, w: Float) {
        if (progress < 0f) {
            G.ring(c, cx, cy, rad, w, 0.28f, C.BLUE, G.alpha(C.BLUE, 0.25f), startDeg = (now % 1000L) * 0.36f)
        } else {
            G.ring(c, cx, cy, rad, w, progress, C.BLUE, G.alpha(C.BLUE, 0.25f))
        }
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        drawRing(c, r.right - d.d(9f), r.centerY(), d.d(7.5f), d.d(2.6f))
    }

    override fun drawMinimal(c: Canvas, cx: Float, cy: Float, rad: Float, d: Dims) {
        drawRing(c, cx, cy, rad * 0.62f, d.d(2.6f))
    }

    override fun expandedH(d: Dims, w: Float) = d.d(36f + 20f)

    override fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {
        val s = d.d(36f)
        val b = icon
        if (b != null) G.bitmap(c, b, r.left, r.top, s, d.d(9f))
        else G.icon(c, Icons.download, r.left + s / 2f, r.top + s / 2f, s, C.BLUE)
        val tx = r.left + s + d.d(12f)
        val pct = if (progress < 0f) "" else "${(progress * 100).toInt()}%"
        val pw = G.measure(pct, d.d(15f), tnum = true)
        G.text(c, title, tx, r.top + s / 2f, d.d(15f), C.WHITE, G.semibold, maxW = r.right - tx - pw - d.d(10f))
        G.text(c, pct, r.right, r.top + s / 2f, d.d(15f), C.BLUE, align = 1, tnum = true)
        val y = r.top + s + d.d(14f)
        val bh = d.d(6f)
        G.rrect(c, r.left, y - bh / 2f, r.right, y + bh / 2f, bh / 2f, G.alpha(C.WHITE, 0.15f))
        if (progress >= 0f) {
            G.rrect(c, r.left, y - bh / 2f, r.left + (r.right - r.left) * progress.coerceIn(0f, 1f), y + bh / 2f, bh / 2f, C.BLUE)
        } else {
            val w = (r.right - r.left) * 0.3f
            val x = r.left + ((now % 1400L) / 1400f) * (r.right - r.left + w) - w
            c.save(); c.clipRect(r.left, y - bh, r.right, y + bh)
            G.rrect(c, x, y - bh / 2f, x + w, y + bh / 2f, bh / 2f, C.BLUE)
            c.restore()
        }
    }
}

// =====================================================================
//  Свой таймер (запускается из приложения)
// =====================================================================
class TimerActivity private constructor(private val total: Long) : IslandActivity("timer") {
    companion object {
        var current: TimerActivity? = null
            private set

        fun start(ms: Long) {
            current?.cancel()
            val t = TimerActivity(ms)
            t.endAt = SystemClock.elapsedRealtime() + ms
            t.running = true
            current = t
            t.schedule()
            IslandHub.put(t)
        }
    }

    override val priority = 70
    override val ringColor = C.ORANGE
    override val frameMode = FrameMode.TICK
    override val hideInOwnApp = false

    private var endAt = 0L
    private var pausedLeft = 0L
    var running = false
        private set
    private val finish = Runnable { done() }

    fun remaining(): Long = if (running) max(0L, endAt - SystemClock.elapsedRealtime()) else pausedLeft
    private fun timeStr() = G.fmt(remaining() + 999)

    private fun schedule() {
        IslandHub.handler.removeCallbacks(finish)
        IslandHub.handler.postDelayed(finish, remaining())
    }

    fun toggle() {
        if (running) {
            pausedLeft = remaining()
            running = false
            IslandHub.handler.removeCallbacks(finish)
        } else {
            endAt = SystemClock.elapsedRealtime() + pausedLeft
            running = true
            schedule()
        }
        IslandHub.changed()
    }

    fun cancel() {
        IslandHub.handler.removeCallbacks(finish)
        if (current === this) current = null
        IslandHub.remove(key)
    }

    private fun done() {
        if (current === this) current = null
        IslandHub.remove(key)
        IslandHub.put(TimerDoneActivity(), 12_000)
        Haptics.alarm(App.instance)
    }

    private fun progress() = if (total > 0) remaining().toFloat() / total else 0f

    override fun leftW(d: Dims) = d.baseH * 0.6f
    override fun rightW(d: Dims) = G.measure(G.digitsMask(timeStr()), d.d(14f), tnum = true)

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.6f
        G.icon(c, Icons.timer, r.left + s / 2f, r.centerY(), s, C.ORANGE)
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.text(c, timeStr(), r.right, r.centerY(), d.d(14f), C.ORANGE, align = 1, tnum = true)
    }

    override fun drawMinimal(c: Canvas, cx: Float, cy: Float, rad: Float, d: Dims) {
        G.ring(c, cx, cy, rad * 0.6f, d.d(2.6f), progress(), C.ORANGE, G.alpha(C.ORANGE, 0.25f))
    }

    override fun expandedH(d: Dims, w: Float) = d.d(50f)

    override fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {
        val b = d.d(48f)
        val cy = r.top + b / 2f
        // пауза / продолжить
        val px = r.left + b / 2f
        G.circle(c, px, cy, b / 2f, G.alpha(C.ORANGE, 0.28f))
        G.icon(c, if (running) Icons.pause else Icons.play, px, cy, b * 0.46f, C.ORANGE)
        hits.add(px - b / 2f, cy - b / 2f, px + b / 2f, cy + b / 2f) { _, _ -> toggle() }
        // отмена
        val cx = px + b + d.d(12f)
        G.circle(c, cx, cy, b / 2f, C.GRAY2)
        G.icon(c, Icons.close, cx, cy, b * 0.44f, C.WHITE)
        hits.add(cx - b / 2f, cy - b / 2f, cx + b / 2f, cy + b / 2f) { _, _ -> cancel() }
        // время
        val big = d.d(38f)
        val ts = timeStr()
        val tw = G.measure(ts, big, G.light, true)
        G.text(c, ts, r.right, cy + d.d(2f), big, C.ORANGE, G.light, align = 1, tnum = true)
        G.text(c, "Таймер", r.right - tw - d.d(10f), cy + d.d(8f), d.d(13f), C.ORANGE, G.medium, align = 1)
    }

    override fun onTap(ctx: Context) = false
}

class TimerDoneActivity : IslandActivity("timerdone") {
    override val priority = 100
    override val autoExpand = true
    override val ringColor = C.ORANGE
    override val frameMode = FrameMode.CONTINUOUS
    override val hideInOwnApp = false
    private val start = SystemClock.uptimeMillis()

    private fun pulse() = 0.6f + 0.4f * ((sin((now - start) / 180.0) + 1.0) / 2.0).toFloat()

    override fun leftW(d: Dims) = d.baseH * 0.6f
    override fun rightW(d: Dims) = G.measure("Готово", d.d(14f))

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.6f
        G.icon(c, Icons.timer, r.left + s / 2f, r.centerY(), s, G.alpha(C.ORANGE, pulse()))
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.text(c, "Готово", r.right, r.centerY(), d.d(14f), C.ORANGE, align = 1)
    }

    override fun expandedH(d: Dims, w: Float) = d.d(48f)

    override fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {
        val s = d.d(46f)
        val cy = r.top + s / 2f
        G.circle(c, r.left + s / 2f, cy, s / 2f, G.alpha(C.ORANGE, 0.28f * pulse()))
        G.icon(c, Icons.timer, r.left + s / 2f, cy, s * 0.55f, C.ORANGE)
        val tx = r.left + s + d.d(12f)
        G.text(c, "Таймер", tx, cy - d.d(9f), d.d(17f), C.WHITE, G.semibold)
        G.text(c, "Время вышло", tx, cy + d.d(11f), d.d(13.5f), C.SUB, G.regular)
        val bw = d.d(84f)
        val bh = d.d(40f)
        G.rrect(c, r.right - bw, cy - bh / 2f, r.right, cy + bh / 2f, bh / 2f, C.ORANGE)
        G.text(c, "Стоп", r.right - bw / 2f, cy, d.d(16f), Color.BLACK, G.semibold, align = 0)
        hits.add(r.right - bw, cy - bh / 2f, r.right, cy + bh / 2f) { _, _ -> stop() }
    }

    private fun stop() {
        Haptics.stop(App.instance)
        IslandHub.remove(key)
    }

    override fun onTap(ctx: Context): Boolean {
        stop(); return true
    }
}

// =====================================================================
//  Системные события (один слот "sys" — новое заменяет старое)
// =====================================================================
class ChargingActivity(private val level: Int) : IslandActivity("sys") {
    override val priority = 100
    override val hasExpanded = false
    private val start = SystemClock.uptimeMillis()
    override val frameMode get() = if (now - start < 900) FrameMode.CONTINUOUS else FrameMode.NONE
    private val label = "Зарядка"
    private val pct get() = "$level%"
    private val color = if (level <= 20) C.RED else C.GREEN

    override fun leftW(d: Dims) = G.measure(label, d.d(14f))
    override fun rightW(d: Dims) = G.measure(pct, d.d(14f), tnum = true) + d.d(6f + 27f)

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        G.text(c, label, r.left, r.centerY(), d.d(14f), C.WHITE)
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        val bw = d.d(25f)
        val bh = d.d(12.5f)
        val nub = d.d(2f)
        val bx = r.right - bw - nub
        val cy = r.centerY()
        G.text(c, pct, bx - d.d(6f), cy, d.d(14f), color, align = 1, tnum = true)
        G.rrectStroke(c, bx, cy - bh / 2f, bx + bw, cy + bh / 2f, d.d(3.8f), d.d(1.2f), G.alpha(C.WHITE, 0.4f))
        G.rrect(c, bx + bw + d.d(0.8f), cy - d.d(2.2f), bx + bw + nub, cy + d.d(2.2f), d.d(1f), G.alpha(C.WHITE, 0.4f))
        val k = G.smooth((now - start).toFloat(), 100f, 800f)
        val inset = d.d(2.2f)
        val fw = (bw - 2 * inset) * (level / 100f).coerceIn(0.05f, 1f) * k
        G.rrect(c, bx + inset, cy - bh / 2f + inset, bx + inset + fw, cy + bh / 2f - inset, d.d(2f), color)
    }
}

class SilentActivity(mode: Int) : IslandActivity("sys") {
    override val priority = 100
    override val hasExpanded = false
    private val start = SystemClock.uptimeMillis()
    override val frameMode get() = if (now - start < 1000) FrameMode.CONTINUOUS else FrameMode.NONE
    private val silent = mode != android.media.AudioManager.RINGER_MODE_NORMAL
    private val label = when (mode) {
        android.media.AudioManager.RINGER_MODE_SILENT -> "Без звука"
        android.media.AudioManager.RINGER_MODE_VIBRATE -> "Вибрация"
        else -> "Звонок"
    }
    private val color = if (silent) C.RED else C.WHITE

    override fun leftW(d: Dims) = d.baseH * 0.6f
    override fun rightW(d: Dims) = G.measure(label, d.d(14f))

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.6f
        val t = (now - start) / 1000f
        // колокольчик "звенит" и затухает
        val ang = (sin(t * 32.0) * 24.0 * kotlin.math.exp(-t * 4.5)).toFloat()
        c.save()
        c.rotate(ang, r.left + s / 2f, r.centerY() - s * 0.42f)
        G.icon(c, if (silent) Icons.bellOff else Icons.bell, r.left + s / 2f, r.centerY(), s, color)
        c.restore()
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.text(c, label, r.right, r.centerY(), d.d(14f), color, align = 1)
    }
}

class UnlockActivity : IslandActivity("sys") {
    override val priority = 100
    override val hasExpanded = false
    private val start = SystemClock.uptimeMillis()
    override val frameMode get() = if (now - start < 900) FrameMode.CONTINUOUS else FrameMode.NONE

    override fun leftW(d: Dims) = d.baseH * 0.52f
    override fun rightW(d: Dims) = 0f

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.52f
        val p = G.smooth((now - start).toFloat(), 220f, 560f)
        val bw = s * 0.8f
        val bh = s * 0.58f
        val bl = r.left + (s - bw) / 2f
        val bt = r.centerY() - bh / 2f + s * 0.2f
        G.rrect(c, bl, bt, bl + bw, bt + bh, s * 0.13f, C.WHITE)
        // дужка замка
        val lx = bl + bw * 0.22f
        val rx = bl + bw * 0.78f
        val rad = (rx - lx) / 2f
        val top = bt - s * 0.42f
        val path = android.graphics.Path()
        path.moveTo(lx, bt)
        path.lineTo(lx, top + rad)
        path.arcTo(RectF(lx, top, rx, top + 2 * rad), 180f, 180f, false)
        path.lineTo(rx, bt)
        c.save()
        c.translate(0f, -s * 0.14f * p)
        c.rotate(-32f * p, rx, bt)
        G.stroke.strokeWidth = s * 0.12f
        G.stroke.color = C.WHITE
        c.drawPath(path, G.stroke)
        c.restore()
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {}
}

class BluetoothActivity(private val name: String) : IslandActivity("sys") {
    override val priority = 100
    override val hasExpanded = false

    override fun leftW(d: Dims) = d.baseH * 0.6f
    override fun rightW(d: Dims) = min(G.measure(name, d.d(14f)), d.d(110f))

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.6f
        G.icon(c, Icons.headset, r.left + s / 2f, r.centerY(), s, C.WHITE)
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.text(c, name, r.right, r.centerY(), d.d(14f), C.WHITE, align = 1, maxW = d.d(110f))
    }
}
