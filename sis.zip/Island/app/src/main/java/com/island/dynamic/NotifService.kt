package com.island.dynamic

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.island.dynamic.acts.CallActivity
import com.island.dynamic.acts.ChronoActivity
import com.island.dynamic.acts.MediaActivity
import com.island.dynamic.acts.MediaControls
import com.island.dynamic.acts.NotificationActivity
import com.island.dynamic.acts.ProgressActivity
import com.island.dynamic.gfx.G

/**
 * Читает уведомления → звонки, таймеры/секундомеры (хронометр), загрузки, обычные уведомления.
 * Через него же (доступ к уведомлениям) получаем активные MediaSession → музыка.
 */
class NotifService : NotificationListenerService() {

    companion object {
        var instance: NotifService? = null
            private set
        private var postCounter = 0L
    }

    private var media: MediaTracker? = null
    private val alertedOnce = HashSet<String>()

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        media = MediaTracker(this, ComponentName(this, NotifService::class.java)).also { it.start() }
        try {
            activeNotifications?.forEach { handle(it, null, initial = true) }
        } catch (_: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        media?.stop()
        media = null
        instance = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification, rankingMap: RankingMap?) {
        try {
            handle(sbn, rankingMap, initial = false)
        } catch (_: Exception) {
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val k = sbn.key
        IslandHub.remove("call:$k")
        IslandHub.remove("chrono:$k")
        IslandHub.remove("prog:$k")
        alertedOnce.remove(k)
    }

    private fun pi(ex: Bundle, key: String): PendingIntent? =
        if (Build.VERSION.SDK_INT >= 33) ex.getParcelable(key, PendingIntent::class.java)
        else @Suppress("DEPRECATION") ex.getParcelable<PendingIntent>(key)

    private fun largeIcon(n: Notification): Bitmap? = try {
        n.getLargeIcon()?.loadDrawable(this)?.let { G.bmpOf(it, 128) }
    } catch (_: Exception) {
        null
    }

    private fun handle(sbn: StatusBarNotification, ranking: RankingMap?, initial: Boolean) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val ex = n.extras ?: return
        if (ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) return // музыка идёт через MediaTracker

        val pkg = sbn.packageName
        val key = sbn.key
        val template = ex.getString(Notification.EXTRA_TEMPLATE) ?: ""
        val ongoing = sbn.isOngoing || (n.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0
        val title = (ex.getCharSequence(Notification.EXTRA_TITLE_BIG) ?: ex.getCharSequence(Notification.EXTRA_TITLE))
            ?.toString()?.trim().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim().orEmpty()
        val chrono = ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)

        var kind = ""
        // ---------- звонок ----------
        if (Prefs.live && (n.category == Notification.CATEGORY_CALL || template.endsWith("\$CallStyle"))) {
            var answer = pi(ex, "android.answerIntent")
            var decline = pi(ex, "android.declineIntent") ?: pi(ex, "android.hangUpIntent")
            n.actions?.forEach { a ->
                val t = a.title?.toString()?.lowercase() ?: ""
                if (answer == null && listOf("answer", "accept", "ответ", "прин").any { t.contains(it) }) answer = a.actionIntent
                if (decline == null && listOf("decl", "reject", "hang", "end", "отклон", "сброс", "заверш", "отбой").any { t.contains(it) }) decline = a.actionIntent
            }
            val callType = ex.getInt("android.callType", 0) // 1 входящий, 2 разговор
            val incoming = callType == 1 || (callType == 0 && answer != null && !chrono)
            val start = if (chrono) n.`when` else sbn.postTime
            val k = "call:$key"
            val sub = if (incoming) (text.ifEmpty { AppIcons.label(this, pkg) }) else text
            IslandHub.put(
                CallActivity(k, pkg, title.ifEmpty { "Вызов" }, sub, largeIcon(n), incoming, start, answer, decline, n.contentIntent),
                bump = IslandHub.get(k) == null || (IslandHub.get(k) as? CallActivity)?.incoming != incoming
            )
            kind = "call"
        }
        // ---------- хронометр (таймер, секундомер, запись экрана...) ----------
        else if (Prefs.live && ongoing && chrono) {
            val down = ex.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN)
            val k = "chrono:$key"
            IslandHub.put(
                ChronoActivity(k, pkg, AppIcons.get(this, pkg), title.ifEmpty { AppIcons.label(this, pkg) }, text, n.`when`, down, n.contentIntent),
                bump = IslandHub.get(k) == null
            )
            kind = "chrono"
        }
        // ---------- прогресс ----------
        else if (Prefs.live && ongoing && (ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0 || ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE))) {
            val max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
            val cur = ex.getInt(Notification.EXTRA_PROGRESS, 0)
            val p = if (ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE) || max <= 0) -1f else cur.toFloat() / max
            val k = "prog:$key"
            IslandHub.put(
                ProgressActivity(k, pkg, AppIcons.get(this, pkg), title.ifEmpty { AppIcons.label(this, pkg) }, p, n.contentIntent),
                bump = IslandHub.get(k) == null
            )
            kind = "prog"
        }
        if (kind != "call") IslandHub.remove("call:$key")
        if (kind != "chrono") IslandHub.remove("chrono:$key")
        if (kind != "prog") IslandHub.remove("prog:$key")
        if (kind.isNotEmpty()) return

        // ---------- обычное уведомление ----------
        if (initial || ongoing || !Prefs.notifs) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and Notification.FLAG_ONLY_ALERT_ONCE) != 0 && !alertedOnce.add(key)) return
        if (ranking != null) {
            val r = Ranking()
            if (ranking.getRanking(key, r) && r.importance < NotificationManager.IMPORTANCE_DEFAULT) return
        }
        if (title.isEmpty() && text.isEmpty()) return

        postCounter++
        IslandHub.put(
            NotificationActivity(
                pkg, AppIcons.label(this, pkg), title, text,
                AppIcons.get(this, pkg), largeIcon(n), n.contentIntent, postCounter
            ),
            durationMs = 5500
        )
        Haptics.tick(this)
    }
}

/** Следит за всеми MediaSession и показывает ту, что играет. */
class MediaTracker(private val ctx: Context, private val comp: ComponentName) :
    MediaSessionManager.OnActiveSessionsChangedListener {

    private val msm = ctx.getSystemService(MediaSessionManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val sessions = HashMap<MediaSession.Token, Pair<MediaController, MediaController.Callback>>()
    private var current: MediaController? = null
    private val act = MediaActivity()
    private var lastArt: Bitmap? = null
    private var lastTitle = ""
    private var pauseScheduled = false
    private var expired = false

    /** Через 2 минуты паузы музыка уходит с острова, как в iOS. */
    private val pauseTimeout = Runnable {
        pauseScheduled = false
        expired = true
        IslandHub.remove(act.key)
    }

    fun start() {
        try {
            msm.addOnActiveSessionsChangedListener(this, comp, handler)
            onActiveSessionsChanged(msm.getActiveSessions(comp))
        } catch (_: SecurityException) {
        }
    }

    fun stop() {
        try {
            msm.removeOnActiveSessionsChangedListener(this)
        } catch (_: Exception) {
        }
        sessions.values.forEach { it.first.unregisterCallback(it.second) }
        sessions.clear()
        handler.removeCallbacks(pauseTimeout)
        IslandHub.remove(act.key)
    }

    override fun onActiveSessionsChanged(controllers: MutableList<MediaController>?) {
        val list = controllers ?: emptyList<MediaController>()
        val tokens = list.map { it.sessionToken }.toSet()
        sessions.keys.filter { it !in tokens }.forEach { t ->
            sessions.remove(t)?.let { it.first.unregisterCallback(it.second) }
        }
        for (mc in list) {
            if (sessions.containsKey(mc.sessionToken)) continue
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    refresh()
                }

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    refresh()
                }

                override fun onSessionDestroyed() {
                    handler.post {
                        try {
                            onActiveSessionsChanged(msm.getActiveSessions(comp))
                        } catch (_: SecurityException) {
                        }
                    }
                }
            }
            mc.registerCallback(cb, handler)
            sessions[mc.sessionToken] = mc to cb
        }
        refresh()
    }

    private fun isPlaying(mc: MediaController): Boolean {
        val s = mc.playbackState?.state ?: return false
        return s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    private fun refresh() {
        val ctrls = sessions.values.map { it.first }
        val cur = current
        val pick = ctrls.firstOrNull { isPlaying(it) }
            ?: cur?.takeIf { c -> ctrls.any { it.sessionToken == c.sessionToken } }
            ?: ctrls.firstOrNull()
        current = pick

        val md = pick?.metadata
        val st = pick?.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        if (!Prefs.media || pick == null || md == null || st == null || title.isNullOrBlank() ||
            st.state == PlaybackState.STATE_NONE || st.state == PlaybackState.STATE_STOPPED ||
            st.state == PlaybackState.STATE_ERROR
        ) {
            handler.removeCallbacks(pauseTimeout); pauseScheduled = false
            IslandHub.remove(act.key)
            return
        }

        val playing = isPlaying(pick)
        val wasPlaying = act.playing
        val newTrack = title != lastTitle
        lastTitle = title

        act.pkg = pick.packageName
        act.contentIntent = pick.sessionActivity
        act.title = title
        act.artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (art !== lastArt) {
            lastArt = art
            act.setArt(art)
        }
        act.duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        act.setState(playing, st.position, st.lastPositionUpdateTime, st.playbackSpeed)
        val controller = pick
        act.controls = object : MediaControls {
            override fun toggle() {
                if (isPlaying(controller)) controller.transportControls.pause() else controller.transportControls.play()
            }

            override fun next() = controller.transportControls.skipToNext()
            override fun prev() = controller.transportControls.skipToPrevious()
            override fun seek(ms: Long) = controller.transportControls.seekTo(ms)
        }

        if (playing) {
            expired = false
            handler.removeCallbacks(pauseTimeout); pauseScheduled = false
        } else {
            if (expired && !newTrack) return
            if (!pauseScheduled) {
                pauseScheduled = true
                handler.postDelayed(pauseTimeout, 120_000)
            }
        }
        val bump = (playing && !wasPlaying) || newTrack || IslandHub.get(act.key) == null
        IslandHub.put(act, bump = bump)
    }
}
