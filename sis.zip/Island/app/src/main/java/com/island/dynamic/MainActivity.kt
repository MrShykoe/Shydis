package com.island.dynamic

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.island.dynamic.gfx.C
import com.island.dynamic.gfx.G

/** Экран настроек: живое превью острова, разрешения, настройки, кнопки проверки. */
class MainActivity : Activity() {

    private lateinit var a11yState: TextView
    private lateinit var notifState: TextView
    private lateinit var btState: TextView

    private fun px(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        scroll.setOnApplyWindowInsetsListener { _, ins ->
            @Suppress("DEPRECATION")
            col.setPadding(px(16f), ins.systemWindowInsetTop + px(12f), px(16f), ins.systemWindowInsetBottom + px(28f))
            ins
        }
        setContentView(scroll)

        col.addView(label("Island", 34f, Color.WHITE, G.bold))
        col.addView(label("Динамический остров для Android", 15f, C.GRAY, G.regular))

        // ---------- превью ----------
        val frame = FrameLayout(this)
        frame.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1B2A4A.toInt(), 0xFF3B1E4A.toInt(), 0xFF5C3A2E.toInt())
        ).apply { cornerRadius = px(30f).toFloat() }
        frame.clipToOutline = true
        frame.addView(IslandView(this, true), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val hint = label("Тап — открыть · удержание — развернуть\nсвайп вбок — переключить · вверх — свернуть", 12f, 0xB3FFFFFF.toInt(), G.medium)
        hint.gravity = Gravity.CENTER
        frame.addView(hint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            bottomMargin = px(14f)
        })
        col.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(270f)).apply { topMargin = px(16f) })

        // ---------- проверка ----------
        val demo = section(col, "Проверка")
        grid(demo, listOf(
            "Музыка" to { Demo.media() },
            "Уведомление" to { Demo.notification() },
            "Звонок" to { Demo.call() },
            "Зарядка" to { Demo.charging() },
            "Без звука" to { Demo.silent() },
            "Разблокировка" to { Demo.unlock() },
            "Таймер 1 мин" to { Demo.timer(60_000) },
            "Таймер 10 сек" to { Demo.timer(10_000) },
            "Загрузка" to { Demo.download() },
            "Наушники" to { Demo.bluetooth() },
        ))
        demo.addView(button("Убрать всё", C.GRAY2) { IslandHub.clearAll() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(46f)).apply { topMargin = px(8f) })

        // ---------- разрешения ----------
        val perm = section(col, "Разрешения")
        a11yState = permRow(perm, "Спец. возможности", "Чтобы остров рисовался поверх всего, вокруг камеры") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        notifState = permRow(perm, "Доступ к уведомлениям", "Музыка, звонки, таймеры, загрузки, уведомления") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btState = permRow(perm, "Bluetooth", "Показывать подключение наушников") {
            if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        }
        val note = label(
            "Если Android пишет «Ограниченная настройка» — открой «О приложении» → ⋮ (сверху справа) → «Разрешить ограниченные настройки», потом включи снова.",
            13f, C.GRAY, G.regular
        )
        note.setPadding(0, px(10f), 0, px(8f))
        perm.addView(note)
        perm.addView(button("Открыть «О приложении»", C.GRAY2) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(46f)))

        // ---------- вид ----------
        val look = section(col, "Внешний вид")
        slider(look, "Размер", 70, 140, { Prefs.scale }, { Prefs.scale = it }) { "$it%" }
        slider(look, "Сдвиг по вертикали", -40, 40, { Prefs.yOff }, { Prefs.yOff = it }) { "$it dp" }
        slider(look, "Сдвиг по горизонтали", -40, 40, { Prefs.xOff }, { Prefs.xOff = it }) { "$it dp" }
        toggle(look, "Пилюля в покое", "Чёрный остров вокруг камеры, даже когда ничего не происходит", { Prefs.showIdle }) { Prefs.showIdle = it }
        toggle(look, "Цветная обводка", "Оранжевая у таймера, зелёная у звонка", { Prefs.ring }) { Prefs.ring = it }
        toggle(look, "Тап разворачивает", "Выкл — как в iOS: тап открывает приложение, удержание разворачивает", { Prefs.tapExpands }) { Prefs.tapExpands = it }
        toggle(look, "Прятать в горизонтали", "Игры и видео на весь экран", { Prefs.hideLandscape }) { Prefs.hideLandscape = it }
        toggle(look, "Вибрация", null, { Prefs.haptics }) { Prefs.haptics = it }

        // ---------- что показывать ----------
        val what = section(col, "Что показывать")
        toggle(what, "Музыка", "Любой плеер: YouTube Music, Spotify, VK...", { Prefs.media }) { Prefs.media = it }
        toggle(what, "Уведомления", null, { Prefs.notifs }) { Prefs.notifs = it }
        toggle(what, "Живые активности", "Звонки, таймеры, секундомер, запись экрана, загрузки", { Prefs.live }) { Prefs.live = it }
        toggle(what, "Зарядка", null, { Prefs.charging }) { Prefs.charging = it }
        toggle(what, "Режим звонка", "Звук / вибрация / без звука", { Prefs.silent }) { Prefs.silent = it }
        toggle(what, "Разблокировка", null, { Prefs.unlock }) { Prefs.unlock = it }
        toggle(what, "Наушники", null, { Prefs.bluetooth }) { Prefs.bluetooth = it }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        IslandService.instance?.registerBluetooth()
        refresh()
    }

    private fun refresh() {
        val a11y = IslandService.instance != null
        val nm = getSystemService(NotificationManager::class.java)
        val notif = nm?.isNotificationListenerAccessGranted(ComponentName(this, NotifService::class.java)) == true
        val bt = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        setState(a11yState, a11y)
        setState(notifState, notif)
        setState(btState, bt)
    }

    private fun setState(tv: TextView, ok: Boolean) {
        tv.text = if (ok) "● Включено" else "● Выключено"
        tv.setTextColor(if (ok) C.GREEN else C.ORANGE)
    }

    // =================================================================
    //  мини-UI-кит
    // =================================================================

    private fun label(text: String, size: Float, color: Int, tf: Typeface): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            typeface = tf
        }

    private fun section(parent: LinearLayout, title: String): LinearLayout {
        val h = label(title.uppercase(), 13f, C.GRAY, G.medium)
        h.letterSpacing = 0.04f
        h.setPadding(px(14f), px(26f), 0, px(8f))
        parent.addView(h)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = GradientDrawable().apply {
            setColor(C.CARD); cornerRadius = px(20f).toFloat()
        }
        card.setPadding(px(16f), px(10f), px(16f), px(14f))
        parent.addView(card)
        return card
    }

    private fun button(text: String, bg: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 15f
            typeface = G.medium
            setTextColor(Color.WHITE)
            stateListAnimator = null
            background = GradientDrawable().apply { setColor(bg); cornerRadius = px(14f).toFloat() }
            setOnClickListener { onClick() }
        }

    private fun grid(parent: LinearLayout, items: List<Pair<String, () -> Unit>>) {
        var row: LinearLayout? = null
        items.forEachIndexed { i, (name, act) ->
            if (i % 2 == 0) {
                row = LinearLayout(this).also {
                    it.orientation = LinearLayout.HORIZONTAL
                    parent.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8f) })
                }
            }
            val b = button(name, C.GRAY3, act)
            row?.addView(b, LinearLayout.LayoutParams(0, px(46f), 1f).apply {
                if (i % 2 == 0) marginEnd = px(4f) else marginStart = px(4f)
            })
        }
    }

    private fun permRow(parent: LinearLayout, title: String, desc: String, open: () -> Unit): TextView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, px(8f), 0, px(8f))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(label(title, 16f, Color.WHITE, G.medium))
        texts.addView(label(desc, 13f, C.GRAY, G.regular))
        val st = label("", 13f, C.ORANGE, G.medium)
        texts.addView(st)
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val b = button("Открыть", C.GRAY2, open)
        b.setPadding(px(14f), 0, px(14f), 0)
        row.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, px(40f)).apply { marginStart = px(10f) })
        parent.addView(row)
        return st
    }

    @Suppress("DEPRECATION")
    private fun toggle(parent: LinearLayout, title: String, desc: String?, get: () -> Boolean, set: (Boolean) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, px(9f), 0, px(9f))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(label(title, 16f, Color.WHITE, G.regular))
        if (desc != null) texts.addView(label(desc, 12.5f, C.GRAY, G.regular))
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, v -> set(v) }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        parent.addView(row)
    }

    private fun slider(parent: LinearLayout, title: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String) {
        val tv = label("$title: ${fmt(get())}", 15f, Color.WHITE, G.regular)
        tv.setPadding(0, px(10f), 0, 0)
        parent.addView(tv)
        val sb = SeekBar(this)
        sb.min = min
        sb.max = max
        sb.progress = get()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                set(p)
                tv.text = "$title: ${fmt(p)}"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}
