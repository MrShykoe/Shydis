package com.island.dynamic.acts

import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import android.os.SystemClock
import com.island.dynamic.gfx.C
import com.island.dynamic.gfx.G
import com.island.dynamic.gfx.Icons
import kotlin.math.max

interface MediaControls {
    fun toggle()
    fun next()
    fun prev()
    fun seek(ms: Long)
}

/** Музыка: обложка + эквалайзер в компактном виде, полноценный плеер в развёрнутом. */
class MediaActivity(key: String = "media") : IslandActivity(key) {
    override val priority = 50
    override var pkg: String? = null
    override var contentIntent: PendingIntent? = null

    var title = ""
    var artist = ""
    var art: Bitmap? = null
        private set
    var accent = Color.WHITE
        private set
    var controls: MediaControls? = null

    var playing = false
        private set
    var duration = 0L
    private var posBase = 0L
    private var posAt = 0L
    private var speed = 1f
    private var stateAt = 0L

    fun setArt(b: Bitmap?) {
        if (b == null) {
            art = null; accent = Color.WHITE; return
        }
        art = try { G.squareCrop(b, 192) } catch (e: Exception) { null }
        accent = G.accentOf(b)
    }

    /** pos/at — как в PlaybackState (at в elapsedRealtime). */
    fun setState(play: Boolean, pos: Long, at: Long, sp: Float) {
        if (play != playing) stateAt = SystemClock.uptimeMillis()
        playing = play
        posBase = pos
        posAt = at
        speed = if (sp == 0f) 1f else sp
    }

    fun position(): Long {
        var p = posBase
        if (playing && posAt > 0) p += ((SystemClock.elapsedRealtime() - posAt) * speed).toLong()
        p = max(0L, p)
        return if (duration > 0) p.coerceAtMost(duration) else p
    }

    override val frameMode: FrameMode
        get() = if (playing || now - stateAt < 450) FrameMode.CONTINUOUS else FrameMode.NONE

    /** Высота столбиков эквалайзера: плавно поднимаются/опускаются при play/pause. */
    private fun amp(): Float {
        val t = ((now - stateAt) / 350f).coerceIn(0f, 1f)
        return if (playing) t else 1f - t
    }

    private fun t() = now / 1000f

    private fun drawArt(c: Canvas, l: Float, t: Float, s: Float, rad: Float) {
        val b = art
        if (b != null) G.bitmap(c, b, l, t, s, rad)
        else {
            G.rrect(c, l, t, l + s, t + s, rad, C.GRAY2)
            G.icon(c, Icons.note, l + s / 2f, t + s / 2f, s * 0.58f, C.GRAY)
        }
    }

    // ---------- compact ----------
    override fun leftW(d: Dims) = d.baseH * 0.66f
    override fun rightW(d: Dims) = G.waveWidth(d.dp)

    override fun drawLeft(c: Canvas, r: RectF, d: Dims) {
        val s = d.baseH * 0.66f
        drawArt(c, r.left, r.centerY() - s / 2f, s, s * 0.26f)
    }

    override fun drawRight(c: Canvas, r: RectF, d: Dims) {
        G.waveform(c, r.right, r.centerY(), d.baseH * 0.5f, d.dp, accent, amp(), t())
    }

    override fun drawMinimal(c: Canvas, cx: Float, cy: Float, rad: Float, d: Dims) {
        val b = art
        if (b != null) {
            val s = rad * 1.36f
            G.bitmap(c, b, cx - s / 2f, cy - s / 2f, s, s / 2f)
        } else {
            G.waveform(c, cx + G.waveWidth(d.dp) / 2f, cy, rad, d.dp, accent, amp(), t())
        }
    }

    // ---------- expanded ----------
    override fun expandedH(d: Dims, w: Float) = d.d(56f + 18f + 7f + 64f)

    override fun drawExpanded(c: Canvas, r: RectF, d: Dims, hits: Hits) {
        val a = d.d(56f)
        drawArt(c, r.left, r.top, a, d.d(13f))
        val tx = r.left + a + d.d(13f)
        val ww = G.waveWidth(d.dp)
        val maxW = r.right - ww - d.d(14f) - tx
        G.text(c, title, tx, r.top + a / 2f - d.d(10f), d.d(16f), C.WHITE, G.semibold, maxW = maxW)
        G.text(c, artist, tx, r.top + a / 2f + d.d(10.5f), d.d(14.5f), C.SUB, G.medium, maxW = maxW)
        G.waveform(c, r.right, r.top + a / 2f, d.d(20f), d.dp, accent, amp(), t())

        // прогресс
        val y0 = r.top + a + d.d(18f) + d.d(7f)
        val pos = position()
        val dur = duration
        val ts = d.d(11.5f)
        val tw = G.measure("-00:00", ts, G.medium, true)
        G.text(c, G.fmt(pos), r.left, y0, ts, C.SUB, G.medium, tnum = true)
        G.text(c, if (dur > 0) "-" + G.fmt(dur - pos) else "--:--", r.right, y0, ts, C.SUB, G.medium, align = 1, tnum = true)
        val bl = r.left + tw + d.d(8f)
        val br = r.right - tw - d.d(8f)
        val bh = d.d(6f)
        G.rrect(c, bl, y0 - bh / 2f, br, y0 + bh / 2f, bh / 2f, G.alpha(C.WHITE, 0.2f))
        val frac = if (dur > 0) pos.toFloat() / dur else 0f
        if (frac > 0f) G.rrect(c, bl, y0 - bh / 2f, bl + (br - bl) * frac, y0 + bh / 2f, bh / 2f, C.WHITE)

        // кнопки
        val cy = y0 + d.d(36f)
        val cx = r.centerX()
        val sp = d.d(74f)
        G.icon(c, Icons.prev, cx - sp, cy, d.d(30f), C.WHITE)
        G.icon(c, if (playing) Icons.pause else Icons.play, cx, cy, d.d(40f), C.WHITE)
        G.icon(c, Icons.next, cx + sp, cy, d.d(30f), C.WHITE)

        val ctl = controls ?: return
        if (dur > 0) hits.add(bl - d.d(6f), y0 - d.d(14f), br + d.d(6f), y0 + d.d(14f)) { x, _ ->
            ctl.seek((((x - bl) / (br - bl)).coerceIn(0f, 1f) * dur).toLong())
        }
        val hw = d.d(30f)
        hits.add(cx - sp - hw, cy - hw, cx - sp + hw, cy + hw) { _, _ -> ctl.prev() }
        hits.add(cx - hw, cy - hw, cx + hw, cy + hw) { _, _ -> ctl.toggle() }
        hits.add(cx + sp - hw, cy - hw, cx + sp + hw, cy + hw) { _, _ -> ctl.next() }
    }
}
