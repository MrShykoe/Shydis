package dev.island.dynamic.media

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class TrackInfo(
    val id: String,
    val title: String,
    val artist: String,
    val cover: ImageBitmap?,
)

data class MediaUiState(
    val hasSession: Boolean = false,
    val packageName: String? = null,
    val track: TrackInfo? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val appIcon: ImageBitmap? = null,
    /** +1 — Next / обычная смена трека, -1 — Previous. */
    val skipDirection: Int = 1,
)

/** Всё живёт на главном потоке (колбэки MediaController приходят через main Handler). */
object MediaRepository {
    private const val TAG = "MediaRepository"

    private lateinit var app: Context
    private val handler = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow(MediaUiState())
    val state: StateFlow<MediaUiState> = _state.asStateFlow()

    private var manager: MediaSessionManager? = null
    private var listenerRegistered = false
    private var controllers: List<MediaController> = emptyList()
    private val callbacks = mutableListOf<Pair<MediaController, MediaController.Callback>>()
    private var current: MediaController? = null
    private var playback: PlaybackState? = null
    private var duration = 0L

    private var lastBitmap: Bitmap? = null
    private var lastImage: ImageBitmap? = null
    private var lastUri: String? = null
    private var lastUriImage: ImageBitmap? = null
    private var lastIconPkg: String? = null
    private var lastIcon: ImageBitmap? = null

    private var pendingDir = 1
    private var pendingDirUntil = 0L
    private var lastTrackId: String? = null

    private var optimisticPos = -1L
    private var optimisticAt = 0L

    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        onSessions(list.orEmpty())
    }

    private val listenerComponent: ComponentName
        get() = ComponentName(app, MediaListenerService::class.java)

    fun start(context: Context) {
        if (!::app.isInitialized) app = context.applicationContext
        if (manager == null) manager = app.getSystemService(MediaSessionManager::class.java)
        refresh()
    }

    fun refresh() {
        val m = manager ?: return
        try {
            if (!listenerRegistered) {
                m.addOnActiveSessionsChangedListener(listener, listenerComponent, handler)
                listenerRegistered = true
            }
            onSessions(m.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            listenerRegistered = false
            Log.w(TAG, "Нет доступа к уведомлениям — медиа-сессии недоступны")
        }
    }

    private class Cb(val c: MediaController) : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            if (current?.sessionToken == c.sessionToken) publish()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            repick()
        }

        override fun onSessionDestroyed() {
            refresh()
        }
    }

    private fun onSessions(list: List<MediaController>) {
        callbacks.forEach { (c, cb) -> runCatching { c.unregisterCallback(cb) } }
        callbacks.clear()
        controllers = list
        for (c in list) {
            val cb = Cb(c)
            c.registerCallback(cb, handler)
            callbacks += c to cb
        }
        repick()
    }

    private fun repick() {
        val all = controllers
        val cur = current?.let { c -> all.firstOrNull { it.sessionToken == c.sessionToken } }
        val playing = all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        current = when {
            cur != null && cur.playbackState?.state == PlaybackState.STATE_PLAYING -> cur
            playing != null -> playing
            cur != null -> cur
            else -> all.firstOrNull()
        }
        publish()
    }

    private fun publish() {
        val c = current
        if (c == null) {
            playback = null
            lastTrackId = null
            _state.value = MediaUiState()
            return
        }
        val md = c.metadata
        val pb = c.playbackState
        playback = pb

        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        duration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        val id = "${c.packageName}|$title|$artist"
        val st = pb?.state ?: PlaybackState.STATE_NONE
        val active = md != null && title.isNotBlank() &&
            st != PlaybackState.STATE_NONE && st != PlaybackState.STATE_STOPPED && st != PlaybackState.STATE_ERROR

        var dir = _state.value.skipDirection
        if (id != lastTrackId) {
            dir = if (SystemClock.elapsedRealtime() < pendingDirUntil) pendingDir else 1
            pendingDir = 1
            pendingDirUntil = 0L
            lastTrackId = id
        }

        _state.value = MediaUiState(
            hasSession = active,
            packageName = c.packageName,
            track = TrackInfo(id, title, artist, loadCover(md)),
            isPlaying = st == PlaybackState.STATE_PLAYING,
            durationMs = duration,
            appIcon = iconFor(c.packageName),
            skipDirection = dir,
        )
    }

    private fun loadCover(md: MediaMetadata?): ImageBitmap? {
        md ?: return null
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) {
            if (bmp !== lastBitmap) {
                lastBitmap = bmp
                lastImage = bmp.asImageBitmap()
            }
            return lastImage
        }
        val uri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
        if (uri != null) {
            if (uri == lastUri) return lastUriImage
            lastUri = uri
            lastUriImage = runCatching {
                val u = Uri.parse(uri)
                if (u.scheme == "content" || u.scheme == "file" || u.scheme == "android.resource") {
                    app.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }?.asImageBitmap()
                } else null // http(s)-обложки: см. README (нужен Coil/свой загрузчик)
            }.getOrNull()
            return lastUriImage
        }
        return null
    }

    private fun iconFor(pkg: String): ImageBitmap? {
        if (pkg == lastIconPkg) return lastIcon
        lastIconPkg = pkg
        lastIcon = runCatching {
            app.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        }.getOrNull()
        return lastIcon
    }

    // ---------- позиция ----------

    fun positionMs(): Long {
        val now = SystemClock.elapsedRealtime()
        val pb = playback
        if (optimisticPos >= 0 && now - optimisticAt < 1500 &&
            (pb == null || pb.lastPositionUpdateTime < optimisticAt)
        ) {
            val adv = if (pb?.state == PlaybackState.STATE_PLAYING) now - optimisticAt else 0L
            return (optimisticPos + adv).coerceAtLeast(0L)
        }
        pb ?: return 0L
        var p = pb.position.coerceAtLeast(0L)
        if (pb.state == PlaybackState.STATE_PLAYING) {
            p += ((now - pb.lastPositionUpdateTime) * pb.playbackSpeed).toLong()
        }
        return if (duration > 0) p.coerceIn(0L, duration) else p
    }

    fun positionFraction(): Float {
        val d = duration
        if (d <= 0L) return 0f
        return (positionMs().toFloat() / d).coerceIn(0f, 1f)
    }

    // ---------- управление ----------

    private fun markDir(d: Int) {
        pendingDir = d
        pendingDirUntil = SystemClock.elapsedRealtime() + 2500
    }

    fun togglePlayPause() {
        val c = current ?: return
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        // Иконка меняется мгновенно, не дожидаясь ответа плеера.
        _state.update { it.copy(isPlaying = !playing) }
        if (playing) c.transportControls.pause() else c.transportControls.play()
    }

    fun next() {
        markDir(1)
        current?.transportControls?.skipToNext()
    }

    fun previous() {
        markDir(-1)
        current?.transportControls?.skipToPrevious()
    }

    fun seekToFraction(f: Float) {
        val ms = (f.coerceIn(0f, 1f) * duration).toLong()
        optimisticPos = ms
        optimisticAt = SystemClock.elapsedRealtime()
        current?.transportControls?.seekTo(ms)
    }

    fun openApp() {
        val c = current ?: return
        val pi = c.sessionActivity
        if (pi != null) {
            try {
                pi.send()
                return
            } catch (_: PendingIntent.CanceledException) {
            }
        }
        app.packageManager.getLaunchIntentForPackage(c.packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { app.startActivity(it) }
        }
    }
}
