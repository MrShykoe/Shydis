package dev.island.dynamic.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentCallbacks
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import dev.island.dynamic.IslandConfig
import dev.island.dynamic.R
import dev.island.dynamic.media.MediaRepository
import dev.island.dynamic.ui.IslandController
import dev.island.dynamic.ui.IslandRoot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Держит оверлей-окно (TYPE_APPLICATION_OVERLAY) поверх всех приложений и статус-бара.
 *
 * Два режима окна:
 *  - compact: маленькое окно ровно вокруг острова → всё остальное на экране кликается как обычно;
 *  - full: во весь экран (во время expanded) → скрим, тап вне острова сворачивает.
 */
class IslandService : Service() {

    companion object {
        private const val CHANNEL = "island"
        private const val NOTIFICATION_ID = 42

        @Volatile
        var running = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, IslandService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, IslandService::class.java))
        }
    }

    private lateinit var wctx: Context
    private lateinit var wm: WindowManager
    private lateinit var display: Display
    private val owner = OverlayLifecycleOwner()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var controller: IslandController
    private var root: ComposeView? = null
    private var topMarginPx = 0
    private val landscape = MutableStateFlow(false)

    private val configCallback = object : ComponentCallbacks {
        override fun onConfigurationChanged(newConfig: Configuration) {
            landscape.value = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
            recomputeMargin()
            applyWindowMode(controller.windowFull)
        }

        override fun onLowMemory() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        goForeground()

        display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        wctx = createDisplayContext(display)
            .createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
        wm = wctx.getSystemService(WindowManager::class.java)

        owner.start()
        controller = IslandController(scope) { full -> applyWindowMode(full) }
        landscape.value = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        recomputeMargin()

        MediaRepository.start(this)
        registerComponentCallbacks(configCallback)

        // Скрытый свайпом остров возвращается при новом треке или новом старте воспроизведения.
        scope.launch {
            var lastId: String? = null
            var lastPlaying = false
            MediaRepository.state.collect { m ->
                val id = m.track?.id
                if (id != lastId || (m.isPlaying && !lastPlaying)) controller.dismissed.value = false
                lastId = id
                lastPlaying = m.isPlaying
            }
        }
        scope.launch {
            combine(MediaRepository.state, controller.dismissed, landscape) { m, dismissed, land ->
                m.hasSession && !dismissed && !land
            }.distinctUntilChanged().collect { visible -> if (visible) show() else hide() }
        }
    }

    override fun onDestroy() {
        running = false
        runCatching { unregisterComponentCallbacks(configCallback) }
        scope.cancel()
        hide()
        owner.stop()
        super.onDestroy()
    }

    // ---------- окно ----------

    private fun show() {
        if (root != null) return
        controller.reset()
        val v = ComposeView(wctx).apply {
            owner.attachTo(this)
            setContent { IslandRoot(controller) }
        }
        runCatching { wm.addView(v, compactParams()) }.onSuccess { root = v }
    }

    private fun hide() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null
    }

    private fun applyWindowMode(full: Boolean) {
        val v = root ?: return
        runCatching { wm.updateViewLayout(v, if (full) fullParams() else compactParams()) }
    }

    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        x = 0
        y = 0
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        title = "IslandOverlay"
    }

    private fun compactParams(): WindowManager.LayoutParams {
        val d = resources.displayMetrics.density
        val w = ((IslandConfig.CompactWidth.value + 2 * IslandConfig.WindowSideMargin.value) * d).roundToInt()
        val h = topMarginPx + ((IslandConfig.CompactHeight.value + IslandConfig.WindowBottomMargin.value) * d).roundToInt()
        return baseParams(w, h)
    }

    private fun fullParams() = baseParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
    )

    /** Остров центрируется по вырезу камеры; если выреза нет — стандартный отступ сверху. */
    private fun recomputeMargin() {
        val d = resources.displayMetrics.density
        val h = IslandConfig.CompactHeight.value * d
        val rect = display.cutout?.boundingRectTop
        topMarginPx = if (rect != null && !rect.isEmpty()) {
            (rect.exactCenterY() - h / 2f).roundToInt().coerceAtLeast(0)
        } else {
            (IslandConfig.DefaultTopMargin.value * d).roundToInt()
        }
        if (::controller.isInitialized) controller.topMarginPx = topMarginPx.toFloat()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Island", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Island работает")
            .setContentText("Динамический остров активен")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }
}
