package dev.island.dynamic

import android.content.Context

object IslandPrefs {
    private fun p(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    fun enabled(c: Context): Boolean = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
}
