package dev.island.dynamic.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import dev.island.dynamic.media.TrackInfo

/**
 * ОДИН драйвер на обложку и текст — поэтому смена трека ощущается единым движением:
 * старый слой уезжает/гаснет, новый приезжает/проявляется, они перекрываются по времени.
 *
 *  - skip-режим (expanded): направленный свап по пружине `t`  0 → 1
 *  - pulse-режим (compact): обложка 1.0 → 0.82 → 1.0 + лёгкий fade, контент меняется в нижней точке
 */
@Stable
class TrackTransition(initial: TrackInfo?) {
    var animId by mutableStateOf(initial?.id)
    var base by mutableStateOf(initial)
    var old by mutableStateOf<TrackInfo?>(null)
    var dir by mutableIntStateOf(1)
    var pulsing by mutableStateOf(false)
    val t = Animatable(1f)
    val pulse = Animatable(1f)
}

@Composable
fun rememberTrackTransition(
    track: TrackInfo?,
    direction: Int,
    pulseMode: () -> Boolean,
): TrackTransition {
    val tr = remember { TrackTransition(track) }

    SideEffect {
        if (track?.id == tr.animId && !tr.pulsing) tr.base = track
    }

    LaunchedEffect(track?.id) {
        tr.pulsing = false
        tr.pulse.snapTo(1f)
        if (track?.id == tr.animId) return@LaunchedEffect

        val from = tr.base
        if (from == null || track == null) {
            tr.animId = track?.id
            tr.base = track
            tr.old = null
            return@LaunchedEffect
        }

        if (pulseMode()) {
            tr.pulsing = true
            tr.pulse.animateTo(0f, spring(1f, 1100f))
            tr.animId = track.id
            tr.base = track
            tr.pulse.animateTo(1f, spring(0.72f, 420f))
            tr.pulsing = false
        } else {
            tr.dir = direction
            tr.t.snapTo(0f)
            tr.old = from
            tr.animId = track.id
            tr.base = track
            tr.t.animateTo(1f, spring(0.8f, 420f))
            tr.old = null
        }
    }
    return tr
}

typealias SkipTransform = GraphicsLayerScope.(isOld: Boolean, t: Float, dir: Int) -> Unit

@Composable
fun TransitionLayers(
    tr: TrackTransition,
    track: TrackInfo?,
    modifier: Modifier = Modifier,
    skip: SkipTransform,
    content: @Composable (TrackInfo) -> Unit,
) {
    val pending = track?.id != tr.animId
    Box(modifier) {
        if (pending || tr.pulsing) {
            val shown = if (pending) tr.base else (track ?: tr.base)
            if (shown != null) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            val p = tr.pulse.value
                            val s = lerp(0.82f, 1f, p)
                            scaleX = s
                            scaleY = s
                            alpha = lerp(0.55f, 1f, p.coerceIn(0f, 1f))
                        },
                ) { content(shown) }
            }
        } else {
            tr.old?.let { o ->
                Box(Modifier.fillMaxSize().graphicsLayer { this.skip(true, tr.t.value, tr.dir) }) { content(o) }
            }
            track?.let { n ->
                Box(Modifier.fillMaxSize().graphicsLayer { this.skip(false, tr.t.value, tr.dir) }) { content(n) }
            }
        }
    }
}

/** Обложка: старая scale 1→0.75 + уезжает (влево при Next / вправо при Prev) + fade; новая — с противоположной стороны. */
val CoverSkip: SkipTransform = { isOld, t, dir ->
    val w = size.width
    if (isOld) {
        val c = t.coerceIn(0f, 1f)
        val s = lerp(1f, 0.75f, c)
        scaleX = s
        scaleY = s
        translationX = -dir * w * 0.42f * c
        alpha = (1f - c * 1.45f).coerceIn(0f, 1f)
    } else {
        val s = lerp(0.75f, 1f, t)
        scaleX = s
        scaleY = s
        translationX = dir * w * 0.42f * (1f - t)
        alpha = ((t - 0.06f) * 1.7f).coerceIn(0f, 1f)
    }
}

/** Текст: старый уезжает вверх + fade, новый приезжает снизу + fade, с перекрытием. */
val TextSkip: SkipTransform = { isOld, t, _ ->
    if (isOld) {
        val c = t.coerceIn(0f, 1f)
        translationY = -14.dp.toPx() * c
        alpha = (1f - c * 1.8f).coerceIn(0f, 1f)
    } else {
        translationY = 16.dp.toPx() * (1f - t)
        alpha = ((t - 0.12f) * 1.7f).coerceIn(0f, 1f)
    }
}
