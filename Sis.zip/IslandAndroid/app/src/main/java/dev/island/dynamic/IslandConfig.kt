package dev.island.dynamic

import androidx.compose.ui.unit.dp

enum class CompactTrailing { Waveform, AppIcon, ProgressArc, None }

/** Все размеры из ТЗ собраны здесь — крути под свой телефон. */
object IslandConfig {
    val CompactHeight = 37.dp
    val CompactWidth = 172.dp
    val CompactCover = 28.dp

    val ExpandedHeight = 164.dp
    val ExpandedSideMargin = 14.dp
    val ExpandedCorner = 44.dp
    val ExpandedCover = 56.dp

    /** Если у телефона нет выреза — отступ острова от верхнего края. */
    val DefaultTopMargin = 11.dp

    /** Запас окна по бокам/снизу в compact-режиме (для свайпа и пружинного "перелёта"). */
    val WindowSideMargin = 28.dp
    val WindowBottomMargin = 16.dp

    const val ScrimAlpha = 0.22f
    const val BorderAlpha = 0.20f

    /** true — тап по compact открывает приложение плеера, false — раскрывает остров. */
    const val TapOpensApp = true

    val Trailing = CompactTrailing.Waveform
}
