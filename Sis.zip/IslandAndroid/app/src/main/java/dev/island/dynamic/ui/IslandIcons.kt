package dev.island.dynamic.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class TransportIcon { Play, Pause, Previous, Next }

/** Иконки как в SF Symbols (play.fill / pause.fill / backward.fill / forward.fill) — скруглённые, без фона. */
@Composable
fun TransportGlyph(
    kind: TransportIcon,
    iconSize: Dp,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
) {
    Canvas(modifier.size(iconSize)) {
        val s = this.size.minDimension
        val r = s * 0.06f

        fun tri(x0: Float, w: Float, h: Float = 0.52f): Path = Path().apply {
            moveTo(x0 * s, (0.5f - h / 2) * s)
            lineTo(x0 * s, (0.5f + h / 2) * s)
            lineTo((x0 + w) * s, 0.5f * s)
            close()
        }

        fun DrawScope.fill(p: Path) {
            drawPath(p, color)
            drawPath(p, color, style = Stroke(width = r * 2, join = StrokeJoin.Round))
        }

        when (kind) {
            TransportIcon.Play -> fill(tri(0.31f, 0.46f, 0.54f))
            TransportIcon.Pause -> {
                val w = 0.17f * s
                val top = 0.20f * s
                val h = 0.60f * s
                drawRoundRect(color, Offset(0.25f * s, top), Size(w, h), CornerRadius(0.05f * s))
                drawRoundRect(color, Offset(0.58f * s, top), Size(w, h), CornerRadius(0.05f * s))
            }
            TransportIcon.Next -> {
                fill(tri(0.13f, 0.33f))
                fill(tri(0.50f, 0.33f))
            }
            TransportIcon.Previous -> scale(-1f, 1f, pivot = center) {
                fill(tri(0.13f, 0.33f))
                fill(tri(0.50f, 0.33f))
            }
        }
    }
}

/** Заглушка обложки — нота. */
@Composable
fun NoteGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = this.size.minDimension
        val c = Color.White.copy(alpha = 0.55f)
        drawOval(c, Offset(0.28f * s, 0.55f * s), Size(0.26f * s, 0.19f * s))
        drawRect(c, Offset(0.50f * s, 0.24f * s), Size(0.045f * s, 0.42f * s))
        val flag = Path().apply {
            moveTo(0.545f * s, 0.24f * s)
            cubicTo(0.66f * s, 0.30f * s, 0.72f * s, 0.38f * s, 0.69f * s, 0.50f * s)
            cubicTo(0.65f * s, 0.42f * s, 0.60f * s, 0.40f * s, 0.545f * s, 0.40f * s)
            close()
        }
        drawPath(flag, c)
    }
}

/** Мини-эквалайзер справа в compact. Только пружины, никаких tween. */
@Composable
fun MiniWaveform(playing: Boolean, modifier: Modifier = Modifier) {
    val bars = remember { List(4) { Animatable(0.3f) } }
    LaunchedEffect(playing) {
        coroutineScope {
            if (playing) {
                bars.forEachIndexed { i, a ->
                    launch {
                        delay(i * 70L)
                        while (true) {
                            a.animateTo(Random.nextFloat() * 0.75f + 0.25f, spring(0.45f, 380f))
                            delay(Random.nextLong(20, 90))
                        }
                    }
                }
            } else {
                bars.forEach { a -> launch { a.animateTo(0.25f, spring(0.7f, 300f)) } }
            }
        }
    }
    Canvas(modifier) {
        val bw = 3.dp.toPx()
        val gap = (this.size.width - 4 * bw) / 3f
        bars.forEachIndexed { i, a ->
            val h = this.size.height * a.value.coerceIn(0.2f, 1f)
            drawRoundRect(
                Color.White,
                Offset(i * (bw + gap), (this.size.height - h) / 2f),
                Size(bw, h),
                CornerRadius(bw / 2f),
            )
        }
    }
}

/** Тонкая дуга прогресса вместо иконки. */
@Composable
fun ProgressArc(progress: () -> Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val sw = 2.dp.toPx()
        val inset = sw / 2f
        val d = Size(this.size.width - sw, this.size.height - sw)
        drawArc(Color.White.copy(alpha = 0.28f), 0f, 360f, false, Offset(inset, inset), d, style = Stroke(sw, cap = StrokeCap.Round))
        drawArc(Color.White, -90f, 360f * progress().coerceIn(0f, 1f), false, Offset(inset, inset), d, style = Stroke(sw, cap = StrokeCap.Round))
    }
}
