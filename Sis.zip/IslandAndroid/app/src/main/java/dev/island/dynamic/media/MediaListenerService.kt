package dev.island.dynamic.media

import android.provider.Settings
import android.service.notification.NotificationListenerService
import dev.island.dynamic.IslandPrefs
import dev.island.dynamic.overlay.IslandService

/**
 * Пустой NotificationListener — нужен только ради доступа к MediaSessionManager.
 * Заодно поднимает остров после перезагрузки телефона.
 */
class MediaListenerService : NotificationListenerService() {
    override fun onListenerConnected() {
        MediaRepository.start(this)
        MediaRepository.refresh()
        if (IslandPrefs.enabled(this) && Settings.canDrawOverlays(this) && !IslandService.running) {
            runCatching { IslandService.start(this) }
        }
    }
}
