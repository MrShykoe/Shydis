package dev.island.dynamic.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * expanded   — целевое состояние (запускает морфинг в Compose)
 * windowFull — физическое окно во весь экран (нужно на время expand и пока идёт схлопывание)
 */
@Stable
class IslandController(
    private val scope: CoroutineScope,
    private val onWindowMode: (full: Boolean) -> Unit,
) {
    var expanded by mutableStateOf(false)
        private set
    var windowFull by mutableStateOf(false)
        private set
    var topMarginPx by mutableFloatStateOf(0f)

    val dismissed = MutableStateFlow(false)

    fun expand() {
        if (expanded) return
        scope.launch {
            if (!windowFull) {
                windowFull = true
                onWindowMode(true)
                delay(60) // даём WindowManager применить размер окна до старта анимации
            }
            expanded = true
        }
    }

    fun collapse() {
        expanded = false
    }

    /** Вызывается из UI, когда пружина схлопывания полностью улеглась. */
    fun onCollapsed() {
        if (!expanded && windowFull) {
            windowFull = false
            onWindowMode(false)
        }
    }

    fun dismiss() {
        expanded = false
        dismissed.value = true
    }

    fun reset() {
        expanded = false
        windowFull = false
    }
}
