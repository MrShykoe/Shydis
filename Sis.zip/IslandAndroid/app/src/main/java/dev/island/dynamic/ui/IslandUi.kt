package dev.island.dynamic.ui

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import dev.island.dynamic.CompactTrailing
import dev.island.dynamic.IslandConfig
import dev.island.dynamic.media.MediaRepository
import dev.island.dynamic.media.MediaUiState
import dev.island.dynamic.media.TrackInfo
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.tanh

@Composable
fun IslandRoot(controller: IslandController) {
    val media by MediaRepository.state.collectAsState()
    val view = LocalView.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val cfg = IslandConfig

    // ---------- геометрия (px) ----------
    val compactW = with(density) { cfg.CompactWidth.toPx() }
    val compactH = with(density) { cfg.CompactHeight.toPx() }
    val expandedH = with(density) { cfg.ExpandedHeight.toPx() }
    val expandedW = view.resources.displayMetrics.widthPixels - with(density) { (cfg.ExpandedSideMargin * 2).toPx() }
    val coverC = with(density) { cfg.CompactCover.toPx() }
    val coverE = with(density) { cfg.ExpandedCover.toPx() }
    val padC = (compactH - coverC) / 2f
    val padE = with(density) { 20.dp.toPx() }
    val topE = with(density) { 18.dp.toPx() }
    val cornerE = with(density) { cfg.ExpandedCorner.toPx() }
    val marginPx = with(density) { cfg.WindowSideMargin.toPx() }
    val trailingSize = with(density) { 20.dp.toPx() }
    val trailingEnd = with(density) { 14.dp.toPx() }
    val textX = padE + coverE + with(density) { 12.dp.toPx() }
    val textRightReserve = padE + with(density) { 34.dp.toPx() }
    val seekY = with(density) { 76.dp.toPx() }
    val seekH = with(density) { 28.dp.toPx() }
    val controlsY = with(density) { 104.dp.toPx() }
    val controlsW = with(density) { 224.dp.toPx() }
    val iconSize = with(density) { 24.dp.toPx() }

    // ---------- пружины морфинга ----------
    // Ширина и высота — две РАЗНЫЕ пружины: форма «перетекает» (сначала шире, потом ниже и наоборот).
    val pW = remember { Animatable(0f) }
    val pH = remember { Animatable(0f) }

    LaunchedEffect(controller.expanded) {
        if (controller.expanded) {
            coroutineScope {
                launch { pW.animateTo(1f, spring(dampingRatio = 0.76f, stiffness = 440f)) }
                launch { pH.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 360f)) }
            }
        } else {
            coroutineScope {
                launch { pW.animateTo(0f, spring(dampingRatio = 0.80f, stiffness = 400f)) }
                launch { pH.animateTo(0f, spring(dampingRatio = 0.78f, stiffness = 520f)) }
            }
            controller.onCollapsed()
        }
    }

    fun widthNow() = lerp(compactW, expandedW, pW.value)
    fun heightNow() = lerp(compactH, expandedH, pH.value)
    fun morph() = (pW.value + pH.value) / 2f
    fun expAlpha() = ((morph() - 0.42f) / 0.45f).coerceIn(0f, 1f)
    fun cmpAlpha() = (1f - morph() * 3.2f).coerceIn(0f, 1f)
    fun radiusPx(h: Float) = min(h / 2f, lerp(compactH / 2f, cornerE, pH.value.coerceIn(0f, 1f)))

    val showExpanded by remember { derivedStateOf { controller.expanded || morph() > 0.03f } }
    val showCompact by remember { derivedStateOf { morph() < 0.75f } }

    // ---------- смена трека ----------
    val tr = rememberTrackTransition(media.track, media.skipDirection) {
        !controller.expanded && morph() < 0.5f
    }

    // ---------- позиция воспроизведения ----------
    var posFrac by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(media.isPlaying, media.track?.id) {
        while (true) {
            posFrac = MediaRepository.positionFraction()
            if (!media.isPlaying) delay(500)
            else if (controller.expanded) withFrameMillis { }
            else delay(250)
        }
    }

    // ---------- жесты: свайп-скрытие (compact) и свайп вверх (expanded) ----------
    val dragX = remember { Animatable(0f) }
    val dragY = remember { Animatable(0f) }
    val dismissAnim = remember { Animatable(0f) }
    var dismissDir by remember { mutableIntStateOf(1) }

    val hState = rememberDraggableState { d -> scope.launch { dragX.snapTo(dragX.value + d) } }
    val vState = rememberDraggableState { d ->
        scope.launch { dragY.snapTo((dragY.value + d).coerceAtMost(with(density) { 40.dp.toPx() })) }
    }

    val topPad = with(density) { controller.topMarginPx.toDp() }

    Box(Modifier.fillMaxSize()) {
        // Скрим 20–25% только пока окно на весь экран
        if (controller.windowFull) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = morph().coerceIn(0f, 1f) }
                    .background(Color.Black.copy(alpha = cfg.ScrimAlpha))
                    .pointerInput(Unit) { detectTapGestures { if (controller.expanded) controller.collapse() } },
            )
        }

        Box(Modifier.align(Alignment.TopCenter).padding(top = topPad)) {
            Box(
                Modifier
                    // свайп/rubber-band/скрытие
                    .graphicsLayer {
                        val e = dismissAnim.value
                        val rubber = marginPx * tanh(dragX.value / marginPx)
                        translationX = rubber + dismissDir * marginPx * e
                        translationY = if (dragY.value < 0f) dragY.value * 0.55f else dragY.value * 0.2f
                        val s = 1f - 0.45f * e - 0.06f * abs(rubber) / marginPx
                        scaleX = s
                        scaleY = s
                        alpha = 1f - e
                        transformOrigin = TransformOrigin(0.5f, 0f)
                    }
                    .sized({ widthNow() }, { heightNow() })
                    // морфинг формы: стадион → скруглённый прямоугольник, радиус считается от текущей высоты
                    .graphicsLayer {
                        shape = RoundedCornerShape(radiusPx(size.height))
                        clip = true
                    }
                    .background(Color.Black)
                    .drawBehind {
                        val sw = 1.dp.toPx()
                        val r = radiusPx(size.height)
                        drawRoundRect(
                            color = Color.White.copy(alpha = cfg.BorderAlpha),
                            topLeft = Offset(sw / 2f, sw / 2f),
                            size = Size(size.width - sw, size.height - sw),
                            cornerRadius = CornerRadius((r - sw / 2f).coerceAtLeast(0f)),
                            style = Stroke(sw),
                        )
                    }
                    .pointerInput(controller.expanded) {
                        detectTapGestures(
                            onLongPress = {
                                if (!controller.expanded) {
                                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                    controller.expand()
                                }
                            },
                            onTap = {
                                if (controller.expanded) {
                                    MediaRepository.openApp()
                                    controller.collapse()
                                } else if (cfg.TapOpensApp) {
                                    MediaRepository.openApp()
                                } else {
                                    controller.expand()
                                }
                            },
                        )
                    }
                    .draggable(
                        state = hState,
                        orientation = Orientation.Horizontal,
                        enabled = !controller.expanded,
                        onDragStopped = { v ->
                            val threshold = with(density) { 56.dp.toPx() }
                            if (abs(dragX.value) > threshold || abs(v) > 1400f) {
                                dismissDir = if (dragX.value + v * 0.05f >= 0f) 1 else -1
                                dismissAnim.animateTo(1f, spring(0.85f, 380f))
                                controller.dismiss()
                            } else {
                                dragX.animateTo(0f, spring(0.55f, 380f))
                            }
                        },
                    )
                    .draggable(
                        state = vState,
                        orientation = Orientation.Vertical,
                        enabled = controller.expanded,
                        onDragStopped = { v ->
                            if (dragY.value < -with(density) { 32.dp.toPx() } || v < -900f) {
                                controller.collapse()
                                dragY.animateTo(0f, spring(0.8f, 300f))
                            } else {
                                dragY.animateTo(0f, spring(0.6f, 420f))
                            }
                        },
                    ),
            ) {
                // ----- compact: правая часть -----
                if (showCompact && cfg.Trailing != CompactTrailing.None) {
                    Box(
                        Modifier
                            .offset { IntOffset((widthNow() - trailingEnd - trailingSize).roundToInt(), ((compactH - trailingSize) / 2f).roundToInt()) }
                            .graphicsLayer { alpha = cmpAlpha() }
                            .size(20.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        when (cfg.Trailing) {
                            CompactTrailing.Waveform -> MiniWaveform(media.isPlaying, Modifier.size(width = 18.dp, height = 14.dp))
                            CompactTrailing.AppIcon -> media.appIcon?.let {
                                Image(it, null, Modifier.fillMaxSize().clip(CircleShape))
                            }
                            CompactTrailing.ProgressArc -> ProgressArc({ posFrac }, Modifier.fillMaxSize())
                            CompactTrailing.None -> {}
                        }
                    }
                }

                // ----- обложка: один и тот же элемент в compact и expanded, морфится по размеру/позиции -----
                Box(
                    Modifier
                        .offset { IntOffset(lerp(padC, padE, morph()).roundToInt(), lerp(padC, topE, morph()).roundToInt()) }
                        .sized({ lerp(coverC, coverE, morph()) }, { lerp(coverC, coverE, morph()) }),
                ) {
                    TransitionLayers(tr, media.track, Modifier.fillMaxSize(), CoverSkip) { CoverImage(it) }
                }

                if (showExpanded) {
                    // ----- название + исполнитель -----
                    Box(
                        Modifier
                            .offset { IntOffset(textX.roundToInt(), topE.roundToInt()) }
                            .sized({ widthNow() - textX - textRightReserve }, { coverE })
                            .graphicsLayer { alpha = expAlpha() },
                    ) {
                        TransitionLayers(tr, media.track, Modifier.fillMaxSize(), TextSkip) { TrackText(it) }
                    }

                    // ----- иконка приложения справа вверху -----
                    media.appIcon?.let { icon ->
                        Image(
                            bitmap = icon,
                            contentDescription = null,
                            modifier = Modifier
                                .offset { IntOffset((widthNow() - padE - iconSize).roundToInt(), topE.roundToInt()) }
                                .graphicsLayer { alpha = expAlpha() }
                                .size(24.dp)
                                .clip(RoundedCornerShape(6.dp)),
                        )
                    }

                    // ----- прогресс-бар -----
                    SeekBar(
                        progress = { posFrac },
                        onSeek = { f ->
                            MediaRepository.seekToFraction(f)
                            posFrac = f
                        },
                        modifier = Modifier
                            .offset { IntOffset(padE.roundToInt(), seekY.roundToInt()) }
                            .sized({ widthNow() - 2 * padE }, { seekH })
                            .graphicsLayer { alpha = expAlpha() },
                    )

                    // ----- кнопки: строго по центру, равные промежутки, без фона -----
                    Row(
                        Modifier
                            .offset { IntOffset(((widthNow() - controlsW) / 2f).roundToInt(), controlsY.roundToInt()) }
                            .graphicsLayer { alpha = expAlpha() },
                        horizontalArrangement = Arrangement.spacedBy(36.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PressButton(48.dp, { MediaRepository.previous() }) {
                            TransportGlyph(TransportIcon.Previous, 32.dp)
                        }
                        PressButton(56.dp, { MediaRepository.togglePlayPause() }) {
                            TransportGlyph(if (media.isPlaying) TransportIcon.Pause else TransportIcon.Play, 38.dp)
                        }
                        PressButton(48.dp, { MediaRepository.next() }) {
                            TransportGlyph(TransportIcon.Next, 32.dp)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------

/** Фиксированный размер, заданный лямбдами: читаются в фазе layout → без рекомпозиции на каждом кадре. */
private fun Modifier.sized(w: () -> Float, h: () -> Float): Modifier = layout { measurable, _ ->
    val ww = w().roundToInt().coerceAtLeast(0)
    val hh = h().roundToInt().coerceAtLeast(0)
    val p = measurable.measure(Constraints.fixed(ww, hh))
    layout(ww, hh) { p.place(0, 0) }
}

@Composable
private fun CoverImage(track: TrackInfo) {
    Box(
        Modifier
            .fillMaxSize()
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF3A3A3C), Color(0xFF1C1C1E)))),
        contentAlignment = Alignment.Center,
    ) {
        val c = track.cover
        if (c != null) {
            Image(bitmap = c, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            NoteGlyph(Modifier.fillMaxSize())
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackText(track: TrackInfo) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        BasicText(
            text = track.title.ifBlank { "—" },
            style = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold),
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.basicMarquee(initialDelayMillis = 1500, velocity = 28.dp),
        )
        BasicText(
            text = track.artist,
            style = TextStyle(color = Color(0xFF9E9EA3), fontSize = 13.sp),
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.basicMarquee(initialDelayMillis = 1500, velocity = 28.dp),
        )
    }
}

/** Кнопка без фона: на нажатие scale 0.88 → 1.0 пружиной + лёгкий haptic. */
@Composable
private fun PressButton(size: Dp, onClick: () -> Unit, content: @Composable () -> Unit) {
    val view = LocalView.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, spring(0.55f, 650f), label = "press")
    Box(
        Modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(interactionSource = interaction, indication = null) {
                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** Тонкий бар 4dp с закруглёнными концами; тап и перетаскивание; при перетаскивании пружинно толстеет до 7dp. */
@Composable
private fun SeekBar(progress: () -> Float, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    var dragging by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableFloatStateOf(0f) }
    val thick by animateFloatAsState(if (dragging) 1f else 0f, spring(0.6f, 500f), label = "seekThick")

    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o -> onSeek((o.x / size.width).coerceIn(0f, 1f)) })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragging = true
                        dragFrac = (o.x / size.width).coerceIn(0f, 1f)
                    },
                    onDragEnd = {
                        dragging = false
                        onSeek(dragFrac)
                    },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        dragFrac = (dragFrac + amount / size.width).coerceIn(0f, 1f)
                    },
                )
            },
    ) {
        val h = lerp(4.dp.toPx(), 7.dp.toPx(), thick)
        val y = (this.size.height - h) / 2f
        val frac = if (dragging) dragFrac else progress().coerceIn(0f, 1f)
        drawRoundRect(Color.White.copy(alpha = 0.26f), Offset(0f, y), Size(this.size.width, h), CornerRadius(h / 2f))
        if (frac > 0f) {
            drawRoundRect(
                Color.White.copy(alpha = 0.92f),
                Offset(0f, y),
                Size((this.size.width * frac).coerceAtLeast(h), h),
                CornerRadius(h / 2f),
            )
        }
    }
}
