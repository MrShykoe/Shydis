package dev.island.dynamic

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import dev.island.dynamic.overlay.IslandService

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                SetupScreen(tick) {
                    if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

@Composable
private fun SetupScreen(tick: Int, onAskNotifications: () -> Unit) {
    val ctx = LocalContext.current
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val listenerOk = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    var running by remember { mutableStateOf(IslandService.running) }

    Surface(Modifier.fillMaxSize(), color = Color.Black) {
        Column(
            Modifier
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Text("Island", style = MaterialTheme.typography.headlineLarge)
            Text(
                "Динамический остров поверх всех окон. Покажется, когда в любом плеере " +
                    "заиграет музыка. Долгое нажатие — раскрыть, свайп вверх — свернуть, " +
                    "свайп в сторону по компактному — скрыть.",
                color = Color(0xFFAAAAAF),
            )

            StepRow("1. Показ поверх других окон", overlayOk, "Разрешить") {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            StepRow("2. Доступ к уведомлениям (нужен, чтобы читать плеер)", listenerOk, "Открыть") {
                ctx.startActivity(
                    Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            if (Build.VERSION.SDK_INT >= 33) {
                Button(onClick = onAskNotifications, modifier = Modifier.fillMaxWidth()) {
                    Text("3. Разрешить уведомления (для службы)")
                }
            }
            Button(
                enabled = overlayOk && listenerOk,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (running) {
                        IslandPrefs.setEnabled(ctx, false)
                        IslandService.stop(ctx)
                        running = false
                    } else {
                        IslandPrefs.setEnabled(ctx, true)
                        IslandService.start(ctx)
                        running = true
                    }
                },
            ) { Text(if (running) "Остановить остров" else "Запустить остров") }
        }
    }
}

@Composable
private fun StepRow(title: String, done: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(if (done) "✓ готово" else "не выдано", color = if (done) Color(0xFF30D158) else Color(0xFFFF9F0A))
        }
        Button(onClick = onClick) { Text(action) }
    }
}
