package com.island.app

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.core.content.ContextCompat

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: IslandView? = null

    private val power = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_POWER_CONNECTED) {
                val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else 0
                IslandBus.pulse(IslandData("charge", Kind.CHARGE, "Зарядка", "Подключено", level = pct), 3200)
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Island", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Island работает")
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = IslandView(this)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        wm.addView(v, lp)
        view = v
        IslandBus.view = v
        IslandBus.onSettings = { applyCfg() }
        applyCfg()
        v.setActs(IslandBus.snapshot())

        ContextCompat.registerReceiver(
            this, power, IntentFilter(Intent.ACTION_POWER_CONNECTED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun applyCfg() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val dd = resources.displayMetrics.density
        lp.y = (p.getInt("y", 10) * dd).toInt()
        view?.let {
            it.applySettings(p.getInt("w", 126) * dd, p.getBoolean("idle", false))
            try { wm.updateViewLayout(it, lp) } catch (e: Exception) {}
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(power) } catch (e: Exception) {}
        IslandBus.view = null
        IslandBus.onSettings = null
        view?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        super.onDestroy()
    }
}
