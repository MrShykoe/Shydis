package com.island.app

import android.app.Notification
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlin.math.max

class NotifListener : NotificationListenerService() {
    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val last = HashMap<String, String>()

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { publishMedia() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { publishMedia() }
        override fun onSessionDestroyed() { publishMedia() }
    }

    private val sessListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> bind(list ?: emptyList()) }

    override fun onListenerConnected() {
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        val cn = ComponentName(this, NotifListener::class.java)
        try {
            m.addOnActiveSessionsChangedListener(sessListener, cn)
            bind(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
        }
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessListener) } catch (e: Exception) {}
    }

    private fun bind(list: List<MediaController>) {
        controllers.forEach { try { it.unregisterCallback(cb) } catch (e: Exception) {} }
        controllers = list
        list.forEach { it.registerCallback(cb) }
        publishMedia()
    }

    private fun publishMedia() {
        val c = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING && it.metadata != null
        } ?: controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PAUSED && it.metadata != null
        }
        if (c == null) { IslandBus.setMedia(null); return }
        val m = c.metadata ?: run { IslandBus.setMedia(null); return }
        val ps = c.playbackState
        val playing = ps?.state == PlaybackState.STATE_PLAYING
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val tc = c.transportControls
        val acts = listOf(
            Act("prev") { tc.skipToPrevious() },
            Act("pp") { if (playing) tc.pause() else tc.play() },
            Act("next") { tc.skipToNext() }
        )
        val pkg = c.packageName
        val open: () -> Unit = {
            packageManager.getLaunchIntentForPackage(pkg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(it) } catch (e: Exception) {}
            }
        }
        IslandBus.setMedia(
            IslandData(
                "media", Kind.MEDIA, title, artist,
                icon = art, accent = accentOf(art), playing = playing,
                pos = ps?.position ?: -1, dur = if (dur > 0) dur else -1,
                posTime = ps?.lastPositionUpdateTime ?: 0,
                speed = ps?.playbackSpeed ?: 1f,
                acts = acts, onOpen = open
            )
        )
    }

    private fun accentOf(b: Bitmap?): Int {
        if (b == null) return Color.WHITE
        return try {
            val p = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(p, hsv)
            hsv[2] = max(hsv[2], 0.85f)
            Color.HSVToColor(hsv)
        } catch (e: Exception) {
            Color.WHITE
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        val acts = n.actions
        val ongoing = n.flags and Notification.FLAG_ONGOING_EVENT != 0
        val chrono = ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
        val open: () -> Unit = { try { n.contentIntent?.send() } catch (e: Exception) {} }

        if (ongoing && chrono) {
            val sig = title + "|" + text + "|" + n.`when`
            if (last[sbn.key] == sig) return
            last[sbn.key] = sig
            val low = (title + " " + text).lowercase()
            val isCallN = n.category == Notification.CATEGORY_CALL
            val glyph = when {
                low.contains("record") || low.contains("запис") -> Glyph.REC
                isCallN -> Glyph.ICON
                else -> Glyph.TIMER
            }
            val accent = when {
                isCallN -> 0xFF30D158.toInt()
                glyph == Glyph.REC -> 0xFFFF3B30.toInt()
                else -> 0xFFFF9F0A.toInt()
            }
            IslandBus.set(
                IslandData(
                    "act:" + sbn.key, Kind.ACTIVITY, title, text,
                    icon = loadIcon(n, sbn.packageName), accent = accent, glyph = glyph,
                    chronoBase = n.`when`,
                    countDown = ex.getBoolean("android.chronometerCountDown", false),
                    onOpen = open
                )
            )
            return
        }

        val isCall = n.category == Notification.CATEGORY_CALL && acts != null && acts.size >= 2
        if (!isCall) {
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            if (ongoing) return
            if (n.category == Notification.CATEGORY_TRANSPORT) return
        }
        val sig = title + "|" + text
        if (last[sbn.key] == sig) return
        last[sbn.key] = sig

        val icon = loadIcon(n, sbn.packageName)
        if (isCall) {
            val list = acts!!.take(2).map { a ->
                Act(a.title.toString()) { try { a.actionIntent?.send() } catch (e: Exception) {} }
            }
            IslandBus.pulse(
                IslandData(sbn.key, Kind.CALL, title, "Входящий звонок", icon = icon, acts = list, onOpen = open), 0
            )
        } else {
            IslandBus.pulse(IslandData(sbn.key, Kind.NOTIF, title, text, icon = icon, onOpen = open), 4500)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        last.remove(sbn.key)
        IslandBus.remove("act:" + sbn.key)
        IslandBus.clear(sbn.key)
    }

    private fun loadIcon(n: Notification, pkg: String): Bitmap? {
        return try {
            val big = n.getLargeIcon()?.loadDrawable(this)
            toBmp(big ?: packageManager.getApplicationIcon(pkg))
        } catch (e: Exception) {
            null
        }
    }

    private fun toBmp(d: Drawable, s: Int = 128): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        d.setBounds(0, 0, s, s)
        d.draw(cv)
        return b
    }
}
