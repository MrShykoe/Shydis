package com.island.app

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper

enum class Kind { NOTIF, MEDIA, CHARGE, CALL, ACTIVITY }
enum class Glyph { ICON, TIMER, REC }

class Act(val label: String, val run: () -> Unit)

class IslandData(
    val key: String,
    val kind: Kind,
    val title: String,
    val sub: String = "",
    val icon: Bitmap? = null,
    val accent: Int = Color.WHITE,
    val playing: Boolean = false,
    val pos: Long = -1,
    val dur: Long = -1,
    val posTime: Long = 0,
    val speed: Float = 1f,
    val level: Int = 0,
    val acts: List<Act> = emptyList(),
    val onOpen: (() -> Unit)? = null,
    val glyph: Glyph = Glyph.ICON,
    val chronoBase: Long = 0,
    val countDown: Boolean = false
)

object IslandBus {
    private val main = Handler(Looper.getMainLooper())
    private val store = LinkedHashMap<String, IslandData>()
    @Volatile var view: IslandView? = null
    var onSettings: (() -> Unit)? = null

    fun snapshot(): List<IslandData> = synchronized(store) { ArrayList(store.values) }

    private fun push() {
        val s = snapshot()
        main.post { view?.setActs(s) }
    }

    fun set(d: IslandData) { synchronized(store) { store[d.key] = d }; push() }
    fun remove(key: String) { synchronized(store) { store.remove(key) }; push() }
    fun removeAll() { synchronized(store) { store.clear() }; push() }

    fun promote(key: String) {
        synchronized(store) {
            val d = store.remove(key)
            if (d != null) {
                val rest = LinkedHashMap(store)
                store.clear()
                store[key] = d
                store.putAll(rest)
            }
        }
        push()
    }

    fun setMedia(d: IslandData?) { if (d == null) remove("media") else set(d) }
    fun pulse(d: IslandData, hold: Long) { main.post { view?.showTransient(d, hold) } }
    fun clear(key: String) { main.post { view?.clearTransient(key) } }
}
