package com.island.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

class IslandView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val cw = 126 * d
    private val ch = 36 * d
    private val ew = 350 * d
    private val eh = 112 * d

    private var progress = 0f
    private var title = ""
    private var text = ""
    var expanded = false
        private set

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 17 * d; typeface = Typeface.DEFAULT_BOLD
    }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 255, 255, 255); textSize = 14 * d
    }
    private val rect = RectF()
    private val holder = FloatValueHolder(0f)
    private val spring = SpringAnimation(holder).apply {
        spring = SpringForce(0f).apply {
            stiffness = 380f
            dampingRatio = 0.62f
        }
        addUpdateListener { _, v, _ ->
            progress = v.coerceAtLeast(0f)
            requestLayout()
            invalidate()
        }
    }
    private val collapseRunnable = Runnable { setExpanded(false) }

    fun show(t: String, s: String) {
        title = t; text = s
        setExpanded(true)
        removeCallbacks(collapseRunnable)
        postDelayed(collapseRunnable, 4500)
    }

    fun setExpanded(e: Boolean) {
        expanded = e
        spring.animateToFinalPosition(if (e) 1f else 0f)
    }

    override fun onMeasure(w: Int, h: Int) {
        val p = progress
        setMeasuredDimension(
            (cw + (ew - cw) * p).toInt(),
            (ch + (eh - ch) * p).toInt()
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        val r = minOf(h / 2f, 36 * d + (h / 2f - 36 * d).coerceAtMost(0f))
        c.drawRoundRect(rect, r, r, bg)

        val a = ((progress - 0.45f) / 0.55f).coerceIn(0f, 1f)
        if (a > 0f) {
            tp.alpha = (255 * a).toInt()
            sp.alpha = (180 * a).toInt()
            val pad = 24 * d
            val maxW = w - pad * 2
            c.drawText(TextUtils.ellipsize(title, tp, maxW), pad, h * 0.42f, tp)
            c.drawText(TextUtils.ellipsize(text, sp, maxW), pad, h * 0.42f + 26 * d, sp)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            removeCallbacks(collapseRunnable)
            setExpanded(!expanded)
        }
        return true
    }
}

private object TextUtils {
    fun ellipsize(s: String, p: Paint, maxW: Float): String =
        android.text.TextUtils.ellipsize(s, android.text.TextPaint(p), maxW, android.text.TextUtils.TruncateAt.END).toString()
}
