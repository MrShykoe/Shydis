package com.island.app

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class IslandView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private class Hit(val r: RectF, val run: () -> Unit)

    // размеры по Apple HIG (pt -> dp 1:1)
    private var idleW = dp(126f)
    private var showIdle = false
    private val ch = dp(37.33f)
    private val circD = dp(37.33f)
    private val circGap = dp(8f)
    private val ew = min(dp(371f), resources.displayMetrics.widthPixels - dp(16f))

    private var acts: List<IslandData> = emptyList()
    private var trans: IslandData? = null
    private val cur: IslandData? get() = trans ?: acts.firstOrNull()
    private var rData: IslandData? = null
    private var lData: IslandData? = null
    private var expanded = false
    private var holdMs = 0L
    private var glowStart = 0L
    private var touching = false

    private var curW = idleW
    private var curH = ch
    private var ex = 0f
    private var vis = 0f
    private var rT = 0f
    private var lT = 0f

    private fun sp(init: Float, k: Float, z: Float, mv: Float, up: (Float) -> Unit) =
        SpringAnimation(FloatValueHolder(init)).apply {
            spring = SpringForce(init).apply { stiffness = k; dampingRatio = z }
            setMinimumVisibleChange(mv)
            addUpdateListener { _, v, _ -> up(v); requestLayout(); invalidate() }
        }

    private val spW = sp(curW, 520f, 0.66f, 1f) { curW = it }
    private val spH = sp(curH, 460f, 0.70f, 1f) { curH = it }
    private val spE = sp(0f, 380f, 0.85f, 1f / 256f) { ex = it }
    private val spV = sp(0f, 700f, 1.0f, 1f / 256f) { vis = it }
    private val spR = sp(0f, 330f, 0.55f, 1f / 256f) { rT = it }
    private val spL = sp(0f, 330f, 0.55f, 1f / 256f) { lT = it }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowColors = intArrayOf(
        0xFF5AC8FA.toInt(), 0xFFAF52DE.toInt(), 0xFFFF2D55.toInt(), 0xFFFF9F0A.toInt(), 0xFF5AC8FA.toInt()
    )
    private val bmpP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tTitle = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = dp(15.5f)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val tSub = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = dp(14f) }
    private val tSmall = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = dp(12f)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val tTime = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(13f); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val tBig = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(22f); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()
    private val path = Path()
    private val clip = Path()
    private val hits = ArrayList<Hit>()
    private val cHits = ArrayList<Pair<RectF, IslandData>>()
    private val collapseRun = Runnable { collapse() }

    private fun pillLeft() = (width - curW) / 2f

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            for (cc in cHits) {
                if (cc.first.contains(e.x, e.y)) {
                    haptic()
                    cc.second.onOpen?.invoke()
                    return true
                }
            }
            val lx = e.x - pillLeft()
            for (h in hits) {
                if (h.r.contains(lx, e.y)) {
                    haptic()
                    h.run()
                    if (cur?.kind == Kind.CALL) collapse()
                    return true
                }
            }
            val dat = cur ?: return true
            if (!expanded) expand(7000) else {
                dat.onOpen?.invoke()
                collapse()
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            for (cc in cHits) {
                if (cc.first.contains(e.x, e.y)) {
                    IslandBus.promote(cc.second.key)
                    post { expand(7000) }
                    return
                }
            }
            if (!expanded && cur != null) expand(7000)
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (vy < -700f && expanded) { collapse(); return true }
            if (vy > 700f && !expanded && cur != null) { expand(7000); return true }
            return false
        }
    })

    // ---------- public API ----------
    fun applySettings(idleWpx: Float, show: Boolean) {
        idleW = idleWpx
        showIdle = show
        retarget()
    }

    fun setActs(l: List<IslandData>) {
        acts = l
        val r = l.getOrNull(1)
        val lf = l.getOrNull(2)
        if (r != null) rData = r
        if (lf != null) lData = lf
        spR.animateToFinalPosition(if (r != null) 1f else 0f)
        spL.animateToFinalPosition(if (lf != null) 1f else 0f)
        if (cur == null) expanded = false
        retarget()
        invalidate()
    }

    fun showTransient(t: IslandData, hold: Long) {
        trans = t
        glowStart = SystemClock.uptimeMillis()
        expand(hold)
    }

    fun clearTransient(key: String) {
        if (trans?.key == key) collapse()
    }

    // ---------- state ----------
    private fun haptic() { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }

    private fun expand(hold: Long) {
        val was = expanded
        expanded = true
        holdMs = hold
        scheduleCollapse()
        retarget()
        if (!was) haptic()
    }

    private fun collapse() {
        removeCallbacks(collapseRun)
        expanded = false
        trans = null
        if (cur == null) expanded = false
        retarget()
    }

    private fun scheduleCollapse() {
        removeCallbacks(collapseRun)
        if (expanded && holdMs > 0) postDelayed(collapseRun, holdMs)
    }

    private fun expH(k: Kind) = when (k) {
        Kind.NOTIF -> dp(84f)
        Kind.MEDIA -> dp(176f)
        Kind.CHARGE -> dp(72f)
        Kind.CALL -> dp(100f)
        Kind.ACTIVITY -> dp(84f)
    }

    private fun retarget() {
        val dat = cur
        val tw: Float
        val th: Float
        when {
            dat == null -> { tw = idleW; th = ch }
            expanded -> { tw = ew; th = expH(dat.kind) }
            else -> {
                tw = idleW + dp(30f) + (if (dat.kind == Kind.ACTIVITY && dat.chronoBase > 0) dp(32f) else 0f)
                th = ch
            }
        }
        spW.animateToFinalPosition(tw)
        spH.animateToFinalPosition(th)
        spE.animateToFinalPosition(if (dat != null && expanded) 1f else 0f)
        spV.animateToFinalPosition(if (dat != null || showIdle) 1f else 0f)
        requestLayout()
        invalidate()
    }

    // ---------- layout / touch ----------
    override fun onMeasure(wm: Int, hm: Int) {
        val rs = (circGap + circD) * max(rT, 0f)
        val ls = (circGap + circD) * max(lT, 0f)
        val slot = max(rs, ls)
        val hidden = vis < 0.01f && cur == null && !showIdle && rT < 0.01f && lT < 0.01f
        if (hidden) setMeasuredDimension(1, 1)
        else setMeasuredDimension(
            (max(curW, 1f) + 2f * slot).toInt(),
            max(max(curH, 1f), circD).toInt()
        )
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pivotX = w / 2f
        pivotY = 0f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            touching = false
            if (cur == null && acts.isEmpty()) return false
            val pl = pillLeft()
            var on = e.x >= pl && e.x <= pl + curW && e.y <= max(curH, circD)
            for (cc in cHits) if (cc.first.contains(e.x, e.y)) on = true
            if (!on) return false
            touching = true
        }
        if (!touching) return false
        gd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                removeCallbacks(collapseRun)
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(110).setInterpolator(null).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animate().scaleX(1f).scaleY(1f).setDuration(380)
                    .setInterpolator(OvershootInterpolator(3f)).start()
                scheduleCollapse()
                touching = false
            }
        }
        return true
    }

    // ---------- drawing helpers ----------
    private fun a(base: Int, al: Float) = (base * al).toInt().coerceIn(0, 255)

    private fun text(c: Canvas, s: String, p: TextPaint, x: Float, y: Float, maxW: Float, base: Int, al: Float) {
        p.alpha = a(base, al)
        c.drawText(TextUtils.ellipsize(s, p, max(maxW, 0f), TextUtils.TruncateAt.END).toString(), x, y, p)
    }

    private fun bmp(c: Canvas, b: Bitmap?, l: Float, t: Float, size: Float, rad: Float, al: Float, fallback: Int) {
        if (b == null) {
            fill.color = fallback
            fill.alpha = a(255, al)
            c.drawRoundRect(l, t, l + size, t + size, rad, rad, fill)
            return
        }
        val sc = size / min(b.width, b.height).toFloat()
        val m = Matrix()
        m.setScale(sc, sc)
        m.postTranslate(l - (b.width * sc - size) / 2f, t - (b.height * sc - size) / 2f)
        val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        sh.setLocalMatrix(m)
        bmpP.shader = sh
        bmpP.alpha = a(255, al)
        c.drawRoundRect(l, t, l + size, t + size, rad, rad, bmpP)
        bmpP.shader = null
    }

    private fun glyph(c: Canvas, dd: IslandData, cx: Float, cy: Float, size: Float, al: Float) {
        when (dd.glyph) {
            Glyph.REC -> {
                fill.color = 0xFFFF3B30.toInt()
                fill.alpha = a(255, al)
                c.drawCircle(cx, cy, size * 0.2f, fill)
            }
            Glyph.TIMER -> {
                val rr = size * 0.27f
                val oy = cy + size * 0.03f
                stroke.color = 0xFFFF9F0A.toInt()
                stroke.alpha = a(255, al)
                stroke.strokeWidth = max(size * 0.07f, dp(1.2f))
                c.drawCircle(cx, oy, rr, stroke)
                c.drawLine(cx, oy, cx + rr * 0.4f, oy - rr * 0.7f, stroke)
                c.drawLine(cx - size * 0.06f, oy - rr - size * 0.04f, cx + size * 0.06f, oy - rr - size * 0.04f, stroke)
            }
            Glyph.ICON -> {
                val box = size * 0.6f
                bmp(c, dd.icon, cx - box / 2f, cy - box / 2f, box, box * 0.27f, al, dd.accent)
            }
        }
    }

    private fun eq(c: Canvas, right: Float, cy: Float, color: Int, al: Float, playing: Boolean, maxH: Float) {
        val t = SystemClock.uptimeMillis() / 1000f
        val bw = dp(3f)
        val gap = dp(2.5f)
        fill.color = color
        fill.alpha = a(255, al)
        for (i in 0 until 4) {
            val f = if (playing) 0.3f + 0.7f * (0.5f + 0.5f * sin(t * (5.5f + i * 1.9f) + i * 1.7f)) else 0.22f
            val h = maxH * f
            val x = right - 4 * bw - 3 * gap + i * (bw + gap)
            c.drawRoundRect(x, cy - h / 2f, x + bw, cy + h / 2f, bw / 2f, bw / 2f, fill)
        }
    }

    private fun tri(c: Canvas, x: Float, cy: Float, w: Float, h: Float) {
        path.reset()
        path.moveTo(x, cy - h / 2f)
        path.lineTo(x, cy + h / 2f)
        path.lineTo(x + w, cy)
        path.close()
        c.drawPath(path, fill)
    }

    private fun skip(c: Canvas, cx: Float, cy: Float, s: Float, dir: Int) {
        c.save()
        if (dir < 0) c.scale(-1f, 1f, cx, cy)
        tri(c, cx - s * 0.55f, cy, s * 0.55f, s * 0.8f)
        tri(c, cx, cy, s * 0.55f, s * 0.8f)
        c.restore()
    }

    private fun playPause(c: Canvas, cx: Float, cy: Float, s: Float, playing: Boolean) {
        if (playing) {
            val bw = s * 0.28f
            val h = s * 0.95f
            c.drawRoundRect(cx - s * 0.4f, cy - h / 2f, cx - s * 0.4f + bw, cy + h / 2f, dp(2f), dp(2f), fill)
            c.drawRoundRect(cx + s * 0.12f, cy - h / 2f, cx + s * 0.12f + bw, cy + h / 2f, dp(2f), dp(2f), fill)
        } else {
            tri(c, cx - s * 0.3f, cy, s * 0.85f, s * 1.0f)
        }
    }

    private fun addHit(cx: Float, cy: Float, act: Act, half: Float) {
        hits.add(Hit(RectF(cx - half, cy - half, cx + half, cy + half), act.run))
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun chrono(dd: IslandData): String {
        val now = System.currentTimeMillis()
        val ms = if (dd.countDown) dd.chronoBase - now else now - dd.chronoBase
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        return if (h > 0) "%d:%02d:%02d".format(h, (s % 3600) / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }

    private fun drawCircle(c: Canvas, dd: IslandData?, t: Float, right: Boolean, al: Float, pl: Float, pw: Float) {
        if (dd == null || t < 0.01f) return
        val x0 = if (right) pl + pw - circD / 2f else pl + circD / 2f
        val x1 = if (right) pl + pw + circGap + circD / 2f else pl - circGap - circD / 2f
        val x = x0 + (x1 - x0) * t
        val sc = (0.4f + 0.6f * t).coerceAtLeast(0.1f)
        val a0 = t.coerceIn(0f, 1f) * al
        val cy = circD / 2f
        bg.alpha = a(255, al)
        c.drawCircle(x, cy, circD / 2f * sc, bg)
        glyph(c, dd, x, cy, circD * sc, a0)
        cHits.add(Pair(RectF(x - circD / 2f, 0f, x + circD / 2f, circD), dd))
    }

    private fun drawGlow(c: Canvas, w: Float, h: Float, r: Float, g: Float) {
        val sh = SweepGradient(w / 2f, h / 2f, glowColors, null)
        val m = Matrix()
        m.setRotate((SystemClock.uptimeMillis() % 2000L) / 2000f * 360f, w / 2f, h / 2f)
        sh.setLocalMatrix(m)
        glowP.shader = sh
        val e = g * g
        rect.set(dp(1f), dp(1f), w - dp(1f), h - dp(1f))
        glowP.strokeWidth = dp(6f)
        glowP.alpha = a(70, e)
        c.drawRoundRect(rect, r, r, glowP)
        glowP.strokeWidth = dp(2f)
        glowP.alpha = a(255, e)
        c.drawRoundRect(rect, r, r, glowP)
        glowP.shader = null
    }

    // ---------- drawing ----------
    override fun onDraw(c: Canvas) {
        if (width < 4) return
        val al = vis.coerceIn(0f, 1f)
        val pw = max(curW, 1f)
        val ph = max(curH, 1f)
        val pl = pillLeft()
        hits.clear()
        cHits.clear()

        drawCircle(c, rData, rT, true, al, pl, pw)
        drawCircle(c, lData, lT, false, al, pl, pw)

        val dat = cur
        c.save()
        c.translate(pl, 0f)
        rect.set(0f, 0f, pw, ph)
        val r = min(ph / 2f, dp(40f))
        bg.alpha = a(255, al)
        c.drawRoundRect(rect, r, r, bg)

        if (dat != null) {
            val e = ex.coerceIn(0f, 1f)
            val ca = (1f - e * 2.2f).coerceIn(0f, 1f) * al
            val ea = ((e - 0.45f) / 0.55f).coerceIn(0f, 1f) * al
            clip.reset()
            clip.addRoundRect(rect, r, r, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            if (ca > 0f) drawCompact(c, dat, pw, ph, ca)
            if (ea > 0f) drawExpanded(c, dat, pw, ea)
            c.restore()

            val g = 1f - (SystemClock.uptimeMillis() - glowStart) / 1400f
            if (g > 0f) {
                drawGlow(c, pw, ph, r, g)
                postInvalidateOnAnimation()
            }
        }
        c.restore()

        if (dat?.playing == true) postInvalidateOnAnimation()
        else if ((dat?.chronoBase ?: 0L) > 0L) postInvalidateDelayed(250)
    }

    private fun drawCompact(c: Canvas, dat: IslandData, w: Float, h: Float, al: Float) {
        glyph(c, dat, dp(8f) + dp(11f), h / 2f, dp(36.7f), al)
        when {
            dat.kind == Kind.MEDIA -> eq(c, w - dp(14f), h / 2f, dat.accent, al, dat.playing, dp(14f))
            dat.kind == Kind.ACTIVITY && dat.chronoBase > 0 -> {
                val s = chrono(dat)
                tTime.color = dat.accent
                tTime.alpha = a(255, al)
                c.drawText(s, w - dp(14f) - tTime.measureText(s), h / 2f + dp(4.5f), tTime)
            }
        }
    }

    private fun drawExpanded(c: Canvas, dat: IslandData, w: Float, al: Float) {
        val pad = dp(20f)
        val eh = expH(dat.kind)
        val cy = eh / 2f
        val white = Color.WHITE
        when (dat.kind) {
            Kind.NOTIF -> {
                val sz = dp(44f)
                bmp(c, dat.icon, pad, cy - sz / 2f, sz, dp(11f), al, 0xFF3A3A3C.toInt())
                val x = pad + sz + dp(12f)
                val mw = ew - x - pad
                text(c, dat.title, tTitle, x, cy - dp(2f), mw, 255, al)
                text(c, dat.sub, tSub, x, cy + dp(17f), mw, 165, al)
            }

            Kind.ACTIVITY -> {
                val sz = dp(44f)
                glyph(c, dat, pad + sz / 2f, cy, sz / 0.6f, al)
                val x = pad + sz + dp(12f)
                var tw = 0f
                if (dat.chronoBase > 0) {
                    val s = chrono(dat)
                    tBig.color = dat.accent
                    tBig.alpha = a(255, al)
                    tw = tBig.measureText(s)
                    c.drawText(s, w - pad - tw, cy + dp(8f), tBig)
                }
                val mw = ew - x - pad - tw - dp(10f)
                text(c, dat.title, tTitle, x, cy - dp(2f), mw, 255, al)
                text(c, dat.sub, tSub, x, cy + dp(17f), mw, 165, al)
            }

            Kind.MEDIA -> {
                val top = dp(18f)
                val art = dp(58f)
                bmp(c, dat.icon, pad, top, art, dp(12f), al, dat.accent)
                val x = pad + art + dp(14f)
                val mw = ew - x - pad - dp(34f)
                text(c, dat.title, tTitle, x, top + dp(24f), mw, 255, al)
                text(c, dat.sub, tSub, x, top + dp(44f), mw, 165, al)
                eq(c, w - pad, top + dp(12f), dat.accent, al, dat.playing, dp(16f))

                val py = top + art + dp(24f)
                var pos = dat.pos
                if (pos >= 0 && dat.playing) pos += ((SystemClock.elapsedRealtime() - dat.posTime) * dat.speed).toLong()
                val known = dat.dur > 0 && pos >= 0
                val frac = if (known) (pos.toFloat() / dat.dur).coerceIn(0f, 1f) else 0f
                val x0 = pad + dp(34f)
                val x1 = w - pad - dp(40f)
                val bh = dp(6f)
                fill.color = white
                fill.alpha = a(50, al)
                c.drawRoundRect(x0, py - bh / 2f, x1, py + bh / 2f, bh / 2f, bh / 2f, fill)
                fill.color = 0xFFD1D1D6.toInt()
                fill.alpha = a(255, al)
                c.drawRoundRect(x0, py - bh / 2f, x0 + (x1 - x0) * frac, py + bh / 2f, bh / 2f, bh / 2f, fill)
                if (known) {
                    text(c, fmt(pos), tSmall, pad, py + dp(4.5f), dp(40f), 170, al)
                    val rs = "-" + fmt(dat.dur - pos)
                    text(c, rs, tSmall, w - pad - tSmall.measureText(rs), py + dp(4.5f), dp(48f), 170, al)
                }

                val cy2 = py + dp(48f)
                val cx = w / 2f
                val gap = dp(86f)
                fill.color = white
                fill.alpha = a(255, al)
                val s = dp(27f)
                skip(c, cx - gap, cy2, s, -1)
                playPause(c, cx, cy2, s * 1.25f, dat.playing)
                skip(c, cx + gap, cy2, s, 1)
                if (al > 0.6f && dat.acts.size >= 3) {
                    addHit(cx - gap, cy2, dat.acts[0], dp(32f))
                    addHit(cx, cy2, dat.acts[1], dp(32f))
                    addHit(cx + gap, cy2, dat.acts[2], dp(32f))
                }
            }

            Kind.CHARGE -> {
                val g = 0xFF30D158.toInt()
                text(c, dat.title, tTitle, pad, cy - dp(2f), dp(140f), 255, al)
                text(c, dat.sub, tSub, pad, cy + dp(17f), dp(140f), 165, al)
                val pct = "${dat.level}%"
                tBig.color = g
                tBig.alpha = a(255, al)
                val tw = tBig.measureText(pct)
                c.drawText(pct, w - pad - tw, cy + dp(8f), tBig)
                val bx = w - pad - tw - dp(14f) - dp(42f)
                val by = cy - dp(10f)
                stroke.color = white
                stroke.alpha = a(120, al)
                stroke.strokeWidth = dp(1.6f)
                c.drawRoundRect(bx, by, bx + dp(38f), by + dp(20f), dp(6f), dp(6f), stroke)
                val iw = dp(32f) * dat.level.coerceIn(0, 100) / 100f
                fill.color = g
                fill.alpha = a(255, al)
                c.drawRoundRect(bx + dp(3f), by + dp(3f), bx + dp(3f) + iw, by + dp(17f), dp(3.5f), dp(3.5f), fill)
                fill.color = white
                fill.alpha = a(120, al)
                c.drawRoundRect(bx + dp(39.5f), cy - dp(3.5f), bx + dp(42f), cy + dp(3.5f), dp(1.2f), dp(1.2f), fill)
            }

            Kind.CALL -> {
                val sz = dp(48f)
                bmp(c, dat.icon, pad, cy - sz / 2f, sz, sz / 2f, al, 0xFF636366.toInt())
                val bs = dp(46f)
                val xAccept = w - pad - bs
                val xDecl = xAccept - dp(14f) - bs
                val x = pad + sz + dp(12f)
                val mw = xDecl - x - dp(8f)
                text(c, dat.title, tTitle, x, cy - dp(2f), mw, 255, al)
                text(c, dat.sub, tSub, x, cy + dp(17f), mw, 165, al)
                if (dat.acts.size >= 2) {
                    val dcx = xDecl + bs / 2f
                    val acx = xAccept + bs / 2f
                    fill.color = 0xFFFF3B30.toInt()
                    fill.alpha = a(255, al)
                    c.drawCircle(dcx, cy, bs / 2f, fill)
                    fill.color = 0xFF30D158.toInt()
                    fill.alpha = a(255, al)
                    c.drawCircle(acx, cy, bs / 2f, fill)
                    stroke.color = white
                    stroke.alpha = a(255, al)
                    stroke.strokeWidth = dp(2.4f)
                    val q = dp(7f)
                    c.drawLine(dcx - q, cy - q, dcx + q, cy + q, stroke)
                    c.drawLine(dcx - q, cy + q, dcx + q, cy - q, stroke)
                    path.reset()
                    path.moveTo(acx - dp(8f), cy + dp(1f))
                    path.lineTo(acx - dp(2f), cy + dp(7f))
                    path.lineTo(acx + dp(9f), cy - dp(6f))
                    c.drawPath(path, stroke)
                    if (al > 0.6f) {
                        addHit(dcx, cy, dat.acts[0], bs / 2f + dp(6f))
                        addHit(acx, cy, dat.acts[1], bs / 2f + dp(6f))
                    }
                }
            }
        }
    }
}
