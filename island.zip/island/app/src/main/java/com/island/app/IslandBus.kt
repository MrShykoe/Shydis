package com.island.app

object IslandBus {
    @Volatile var listener: ((String, String) -> Unit)? = null
    fun post(title: String, text: String) { listener?.invoke(title, text) }
}
