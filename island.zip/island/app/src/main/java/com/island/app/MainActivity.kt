package com.island.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 96)
            setBackgroundColor(Color.BLACK)
        }
        fun label(t: String) = l.addView(TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 20f; setPadding(0, 32, 0, 8)
        })
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply {
            text = t; setOnClickListener { f() }
        })
        fun seek(name: String, key: String, lo: Int, hi: Int, def: Int) {
            val tv = TextView(this).apply {
                setTextColor(Color.LTGRAY); text = "$name: ${prefs.getInt(key, def)}"
            }
            val sb = SeekBar(this).apply {
                this.max = hi - lo
                progress = prefs.getInt(key, def) - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                        prefs.edit().putInt(key, v + lo).apply()
                        tv.text = "$name: ${v + lo}"
                        IslandBus.onSettings?.invoke()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            l.addView(tv)
            l.addView(sb)
        }

        label("Настройка")
        btn("1. Разрешить поверх окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Доступ к уведомлениям") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        btn("3. Запустить остров") {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            if (Settings.canDrawOverlays(this))
                startForegroundService(Intent(this, IslandService::class.java))
        }
        btn("Остановить") { stopService(Intent(this, IslandService::class.java)) }

        label("Позиция под камеру")
        seek("Отступ сверху (dp)", "y", 0, 80, 10)
        seek("Ширина пустого острова (dp)", "w", 60, 200, 126)
        l.addView(Switch(this).apply {
            text = "Показывать пустой остров"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("idle", false)
            setOnCheckedChangeListener { _, v ->
                prefs.edit().putBoolean("idle", v).apply()
                IslandBus.onSettings?.invoke()
            }
        })

        label("Тест")
        btn("Уведомление") {
            IslandBus.pulse(IslandData("t1", Kind.NOTIF, "Алина", "Привет! Ты уже дома?"), 4500)
        }
        btn("Музыка вкл") {
            val noop = Act("x") {}
            IslandBus.setMedia(
                IslandData(
                    "media", Kind.MEDIA, "Blinding Lights", "The Weeknd",
                    accent = 0xFFFF6B6B.toInt(), playing = true, pos = 42000, dur = 200000,
                    posTime = SystemClock.elapsedRealtime(), acts = listOf(noop, noop, noop)
                )
            )
        }
        btn("Музыка выкл") { IslandBus.setMedia(null) }
        btn("Таймер (круг)") {
            IslandBus.set(
                IslandData(
                    "act:timer", Kind.ACTIVITY, "Таймер", "Осталось",
                    accent = 0xFFFF9F0A.toInt(), glyph = Glyph.TIMER,
                    chronoBase = System.currentTimeMillis() + 300000, countDown = true
                )
            )
        }
        btn("Запись экрана (круг)") {
            IslandBus.set(
                IslandData(
                    "act:rec", Kind.ACTIVITY, "Запись экрана", "Идёт запись",
                    accent = 0xFFFF3B30.toInt(), glyph = Glyph.REC,
                    chronoBase = System.currentTimeMillis() - 12000
                )
            )
        }
        btn("Убрать всё") { IslandBus.removeAll() }
        btn("Зарядка") {
            IslandBus.pulse(IslandData("c1", Kind.CHARGE, "Зарядка", "Подключено", level = 78), 3200)
        }
        btn("Звонок") {
            val noop = Act("x") {}
            IslandBus.pulse(IslandData("call", Kind.CALL, "Мама", "Входящий звонок", acts = listOf(noop, noop)), 0)
        }

        setContentView(ScrollView(this).apply { addView(l) })
    }
}
