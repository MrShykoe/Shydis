package com.island.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply {
            text = t; setOnClickListener { f() }
        })
        btn("1. Разрешить поверх окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        btn("2. Доступ к уведомлениям") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        btn("3. Запустить остров") {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            if (Settings.canDrawOverlays(this))
                startForegroundService(Intent(this, IslandService::class.java))
        }
        btn("Остановить") { stopService(Intent(this, IslandService::class.java)) }
        btn("Тест") { IslandBus.post("Dynamic Island", "Работает!") }
        setContentView(l)
    }
}
