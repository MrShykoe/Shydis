package com.iosnotify.app

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/** Показывает баннер поверх всех окон. Одновременно виден только один — новый вытесняет старый. */
object BannerController {
    private val main = Handler(Looper.getMainLooper())
    private var current: BannerView? = null

    fun show(context: Context, data: BannerData) {
        val app = context.applicationContext
        main.post { showNow(app, data) }
    }

    private fun showNow(app: Context, data: BannerData) {
        if (!Settings.canDrawOverlays(app)) return
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // старый баннер быстро улетает вверх, пока новый въезжает
        current?.dismissUp(-1200f)

        val view = BannerView(
            context = app,
            data = data,
            autoDismissMs = Prefs.duration(app) * 1000L,
            haptics = Prefs.haptics(app),
            onGone = { v -> removeView(wm, v) },
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            title = "iOSNotifyBanner"
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            wm.addView(view, lp)
            current = view
        } catch (_: Exception) {
            // нет разрешения или окно нельзя добавить — молча пропускаем
        }
    }

    private fun removeView(wm: WindowManager, v: BannerView) {
        if (v.isAttachedToWindow) {
            try {
                wm.removeViewImmediate(v)
            } catch (_: Exception) {
            }
        }
        if (current === v) current = null
    }
}
