package com.iosnotify.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // если доступ уже выдан — подталкиваем систему перезапустить слушатель
        if (hasListenerAccess(this)) {
            NotificationListenerService.requestRebind(
                ComponentName(this, IosNotificationListener::class.java),
            )
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { HomeScreen() }
        }
    }
}

fun hasListenerAccess(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

private val Blue = Color(0xFF0A84FF)
private val Indigo = Color(0xFF5E5CE6)
private val Green = Color(0xFF30D158)
private val Orange = Color(0xFFFF9F0A)

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    var listenerOk by remember { mutableStateOf(hasListenerAccess(ctx)) }
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                listenerOk = hasListenerAccess(ctx)
                overlayOk = Settings.canDrawOverlays(ctx)
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    var enabled by remember { mutableStateOf(Prefs.enabled(ctx)) }
    var hide by remember { mutableStateOf(Prefs.hideOriginal(ctx)) }
    var haptics by remember { mutableStateOf(Prefs.haptics(ctx)) }
    var seconds by remember { mutableFloatStateOf(Prefs.duration(ctx).toFloat()) }
    var replay by remember { mutableIntStateOf(0) }

    val drift by rememberInfiniteTransition(label = "blob").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "drift",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0B1026), Color(0xFF1B1140), Color(0xFF0B0B14)),
                ),
            ),
    ) {
        // мягкие светящиеся пятна на фоне
        Box(
            Modifier
                .offset(x = (-90 + 110 * drift).dp, y = (-50 + 70 * drift).dp)
                .size(320.dp)
                .background(Brush.radialGradient(listOf(Blue.copy(alpha = 0.38f), Color.Transparent)), CircleShape),
        )
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .offset(x = (80 - 100 * drift).dp, y = (60 - 60 * drift).dp)
                .size(340.dp)
                .background(Brush.radialGradient(listOf(Indigo.copy(alpha = 0.40f), Color.Transparent)), CircleShape),
        )

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Reveal(0) {
                Column {
                    Text("iOS Notify", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Уведомления Android в стиле iOS",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 15.sp,
                    )
                }
            }

            Reveal(1) { PreviewBanner(replay) }

            Reveal(2) {
                GlassCard {
                    PermissionRow(
                        title = "Доступ к уведомлениям",
                        desc = "Чтобы приложение видело входящие уведомления",
                        granted = listenerOk,
                    ) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                    Divider()
                    PermissionRow(
                        title = "Поверх других окон",
                        desc = "Чтобы рисовать баннер над любым приложением",
                        granted = overlayOk,
                    ) {
                        ctx.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${ctx.packageName}"),
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                }
            }

            Reveal(3) {
                GlassCard {
                    SwitchRow("Показывать баннеры", "Главный выключатель", enabled) {
                        enabled = it; Prefs.setEnabled(ctx, it)
                    }
                    Divider()
                    SwitchRow("Скрывать оригинал", "Убирать обычное уведомление из шторки", hide) {
                        hide = it; Prefs.setHideOriginal(ctx, it)
                    }
                    Divider()
                    SwitchRow("Вибро-отклик", "Лёгкий тик при появлении и раскрытии", haptics) {
                        haptics = it; Prefs.setHaptics(ctx, it)
                    }
                    Divider()
                    Column(Modifier.padding(vertical = 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Время показа",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f),
                            )
                            Text("${seconds.roundToInt()} c", color = Blue, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(
                            value = seconds,
                            onValueChange = { seconds = it },
                            onValueChangeFinished = { Prefs.setDuration(ctx, seconds.roundToInt()) },
                            valueRange = 2f..10f,
                            steps = 7,
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Blue,
                                inactiveTrackColor = Color.White.copy(alpha = 0.18f),
                            ),
                        )
                    }
                }
            }

            Reveal(4) {
                BounceButton("Показать тестовое уведомление", Modifier.fillMaxWidth()) {
                    if (!Settings.canDrawOverlays(ctx)) {
                        Toast.makeText(ctx, "Сначала разреши показ поверх других окон", Toast.LENGTH_SHORT).show()
                        return@BounceButton
                    }
                    replay++
                    BannerController.show(
                        ctx,
                        BannerData(
                            appName = "iOS Notify",
                            title = "Анна",
                            text = "Привет! Это тест нового баннера ✨",
                            bigText = "Привет! Это тест нового баннера ✨ Потяни вниз — раскроется полный текст, " +
                                "смахни вверх — уберётся, тапни — откроется уведомление.",
                            icon = ctx.packageManager.getApplicationIcon(ctx.packageName),
                        ),
                    )
                }
            }

            Spacer(Modifier.size(8.dp))
        }
    }
}

/** Плавное появление блоков друг за другом. */
@Composable
private fun Reveal(index: Int, content: @Composable () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 90L)
        show = true
    }
    val a by animateFloatAsState(
        targetValue = if (show) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "reveal",
    )
    Box(
        Modifier.graphicsLayer {
            alpha = a
            translationY = (1f - a) * 70f
        },
    ) { content() }
}

@Composable
private fun GlassCard(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .border(0.6.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(24.dp))
            .padding(horizontal = 18.dp, vertical = 6.dp),
    ) { content() }
}

@Composable
private fun Divider() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(0.6.dp)
            .background(Color.White.copy(alpha = 0.10f)),
    )
}

@Composable
private fun PermissionRow(title: String, desc: String, granted: Boolean, onClick: () -> Unit) {
    val dot by animateColorAsState(if (granted) Green else Orange, label = "dot")
    Row(Modifier.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(dot.copy(alpha = 0.22f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(if (granted) "✓" else "!", color = dot, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Color.White.copy(alpha = 0.55f), fontSize = 12.5.sp, lineHeight = 16.sp)
        }
        AnimatedVisibility(visible = !granted) {
            Text(
                "Включить",
                color = Blue,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onClick)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Color.White.copy(alpha = 0.55f), fontSize = 12.5.sp, lineHeight = 16.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Green,
                checkedThumbColor = Color.White,
                checkedBorderColor = Color.Transparent,
                uncheckedTrackColor = Color.White.copy(alpha = 0.18f),
                uncheckedThumbColor = Color.White,
                uncheckedBorderColor = Color.Transparent,
            ),
        )
    }
}

@Composable
private fun BounceButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "press",
    )
    Box(
        modifier
            .scale(s)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(Blue, Indigo)))
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(vertical = 17.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

/** Живой превью баннера внутри приложения: пружинит при каждом нажатии на «Тест». */
@Composable
private fun PreviewBanner(trigger: Int) {
    val offset = remember { Animatable(-260f) }
    val sc = remember { Animatable(0.86f) }
    LaunchedEffect(trigger) {
        offset.snapTo(-260f)
        sc.snapTo(0.86f)
        launch { offset.animateTo(0f, spring(dampingRatio = 0.62f, stiffness = 340f)) }
        sc.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 360f))
    }
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationY = offset.value
                scaleX = sc.value
                scaleY = sc.value
                alpha = (1f + offset.value / 260f).coerceIn(0f, 1f)
            }
            .clip(RoundedCornerShape(26.dp))
            .background(Color(0xE62A2A2D))
            .border(0.6.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(26.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.linearGradient(listOf(Blue, Indigo))),
            contentAlignment = Alignment.Center,
        ) { Text("🔔", fontSize = 20.sp) }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Row {
                Text(
                    "Анна",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.width(8.dp))
                Text("сейчас", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
            Text("Привет! Так будут выглядеть твои уведомления ✨", color = Color.White, fontSize = 15.sp, maxLines = 2)
        }
    }
}
