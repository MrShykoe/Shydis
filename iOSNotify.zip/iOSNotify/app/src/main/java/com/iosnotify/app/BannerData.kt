package com.iosnotify.app

import android.graphics.drawable.Drawable

data class BannerData(
    val appName: String,
    val title: String,
    val text: String,
    val bigText: String? = null,
    val icon: Drawable? = null,
    val onClick: (() -> Unit)? = null,
)
