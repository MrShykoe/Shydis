package com.iosnotify.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.doOnLayout
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Баннер уведомления в стиле iOS.
 *  - вылетает сверху на пружинах (spring) с лёгким «отскоком»
 *  - палец вниз — резиновое растяжение, дальше раскрывается полный текст
 *  - свайп вверх (или быстрый флик) — улетает с сохранением скорости пальца
 *  - тап — открывает оригинальное уведомление
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class BannerView(
    context: Context,
    private val data: BannerData,
    private val autoDismissMs: Long,
    private val haptics: Boolean,
    private val onGone: (BannerView) -> Unit,
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun dpi(v: Int) = (v * density).roundToInt()

    private val dark =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val primary = if (dark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
    private val secondary = if (dark) 0xA6FFFFFF.toInt() else 0x8C000000.toInt()

    private val cornerRadius = dp(26f)
    private val card = LinearLayout(context)
    private val bodyView = TextView(context)
    private val handle = View(context)

    private val handler = Handler(Looper.getMainLooper())
    private val dismissRunnable = Runnable { dismissUp(0f) }
    private val springs = mutableListOf<SpringAnimation>()
    private var expanded = false
    private var gone = false

    init {
        clipChildren = false
        clipToPadding = false
        setPadding(dpi(8), statusBarHeight() + dpi(4), dpi(8), dpi(16))

        // ---- карточка ("стекло") ----
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dpi(14), dpi(12), dpi(14), dpi(9))
        card.background = glass()
        card.elevation = dp(10f)
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerRadius)
                outline.alpha = 0.55f
            }
        }
        card.alpha = 0f

        // ---- верхняя строка: иконка + текст ----
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }

        val iconView = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageDrawable(data.icon)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(9.5f))
                }
            }
            clipToOutline = true
        }
        row.addView(iconView, LinearLayout.LayoutParams(dpi(40), dpi(40)))

        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleView = TextView(context).apply {
            text = data.title.ifBlank { data.appName }
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(primary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val timeView = TextView(context).apply {
            text = if (Locale.getDefault().language == "ru") "сейчас" else "now"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(secondary)
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        header.addView(
            timeView,
            LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
                .apply { marginStart = dpi(8) },
        )

        bodyView.apply {
            text = data.text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(primary)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setLineSpacing(0f, 1.05f)
        }

        column.addView(header)
        column.addView(
            bodyView,
            LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dpi(1) },
        )
        row.addView(
            column,
            LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dpi(12) },
        )
        card.addView(row)

        // ---- «ручка» снизу, как у iOS ----
        handle.background = GradientDrawable().apply {
            cornerRadius = dp(2f)
            setColor(if (dark) 0x55FFFFFF else 0x44000000)
        }
        card.addView(
            handle,
            LinearLayout.LayoutParams(dpi(36), dpi(4)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dpi(9)
            },
        )

        addView(card, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        card.setOnTouchListener(touchListener())
        card.doOnLayout { if (!gone) enter() }
    }

    // ------------------------------------------------------------------ вид

    private fun glass(): LayerDrawable {
        val base = GradientDrawable().apply {
            cornerRadius = this@BannerView.cornerRadius
            setColor(if (dark) 0xE62A2A2D.toInt() else 0xEBF7F7FA.toInt())
            setStroke(max(1, (0.6f * density).roundToInt()), if (dark) 0x33FFFFFF else 0x22FFFFFF)
        }
        val sheen = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(if (dark) 0x1EFFFFFF else 0x55FFFFFF, 0x00FFFFFF),
        ).apply { cornerRadius = this@BannerView.cornerRadius }
        return LayerDrawable(arrayOf(base, sheen))
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dpi(24)
    }

    // ------------------------------------------------------------ анимации

    private fun spring(
        prop: DynamicAnimation.ViewProperty,
        to: Float,
        damping: Float,
        stiffness: Float,
        velocity: Float = 0f,
        onEnd: (() -> Unit)? = null,
    ): SpringAnimation {
        val anim = SpringAnimation(card as View, prop)
        anim.spring = SpringForce(to).setDampingRatio(damping).setStiffness(stiffness)
        if (velocity != 0f) anim.setStartVelocity(velocity)
        if (onEnd != null) {
            anim.addEndListener { _, canceled, _, _ -> if (!canceled) onEnd() }
        }
        springs.add(anim)
        anim.start()
        return anim
    }

    private fun cancelSprings() {
        springs.forEach { if (it.isRunning) it.cancel() }
        springs.clear()
    }

    private fun enter() {
        card.pivotX = card.width / 2f
        card.pivotY = 0f
        card.translationY = -(card.bottom + dp(24f))
        card.scaleX = 0.88f
        card.scaleY = 0.88f
        card.alpha = 0f

        spring(DynamicAnimation.TRANSLATION_Y, 0f, 0.66f, 320f)
        spring(DynamicAnimation.SCALE_X, 1f, 0.72f, 360f)
        spring(DynamicAnimation.SCALE_Y, 1f, 0.72f, 360f)
        spring(DynamicAnimation.ALPHA, 1f, SpringForce.DAMPING_RATIO_NO_BOUNCY, 700f)

        tick()
        scheduleDismiss(autoDismissMs)
    }

    /** Улетает вверх. [velocity] — скорость пальца (px/s, отрицательная = вверх). */
    fun dismissUp(velocity: Float = 0f) {
        if (gone) return
        gone = true
        handler.removeCallbacks(dismissRunnable)
        cancelSprings()
        val target = -(card.bottom + dp(48f))
        spring(DynamicAnimation.TRANSLATION_Y, target, 1f, 420f, velocity) { onGone(this) }
        spring(DynamicAnimation.ALPHA, 0f, 1f, 520f)
        spring(DynamicAnimation.SCALE_X, 0.94f, 1f, 420f)
        spring(DynamicAnimation.SCALE_Y, 0.94f, 1f, 420f)
        // страховка, если пружина не «досчиталась»
        handler.postDelayed({ onGone(this) }, 900)
    }

    private fun scheduleDismiss(ms: Long) {
        handler.removeCallbacks(dismissRunnable)
        handler.postDelayed(dismissRunnable, ms)
    }

    private fun expand() {
        if (expanded) return
        expanded = true
        TransitionManager.beginDelayedTransition(
            this,
            AutoTransition().apply {
                duration = 340
                interpolator = OvershootInterpolator(0.9f)
            },
        )
        bodyView.maxLines = 10
        bodyView.text = data.bigText?.takeIf { it.isNotBlank() } ?: data.text
        handle.alpha = 0f
        tick()
    }

    private fun tick() {
        if (haptics) card.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    // --------------------------------------------------------------- жесты

    private fun touchListener() = object : OnTouchListener {
        private var downY = 0f
        private var dragging = false
        private var tracker: VelocityTracker? = null
        private val slop = ViewConfiguration.get(context).scaledTouchSlop

        override fun onTouch(v: View, ev: MotionEvent): Boolean {
            if (gone) return true
            tracker?.addMovement(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = ev.rawY
                    dragging = false
                    tracker?.recycle()
                    tracker = VelocityTracker.obtain().also { it.addMovement(ev) }
                    handler.removeCallbacks(dismissRunnable)
                    cancelSprings()
                    card.alpha = 1f
                    spring(DynamicAnimation.SCALE_X, 0.975f, 0.8f, 700f)
                    spring(DynamicAnimation.SCALE_Y, 0.975f, 0.8f, 700f)
                }

                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.rawY - downY
                    if (!dragging && abs(dy) > slop) dragging = true
                    if (dragging) {
                        card.translationY = if (dy < 0f) dy else rubber(dy)
                        if (dy > dp(38f)) expand()
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    tracker?.computeCurrentVelocity(1000)
                    val vy = tracker?.yVelocity ?: 0f
                    tracker?.recycle()
                    tracker = null

                    val isUp = ev.actionMasked == MotionEvent.ACTION_UP
                    if (isUp && !dragging) {
                        // обычный тап
                        spring(DynamicAnimation.SCALE_X, 1f, 0.7f, 500f)
                        spring(DynamicAnimation.SCALE_Y, 1f, 0.7f, 500f)
                        data.onClick?.invoke()
                        dismissUp(-300f)
                    } else if (card.translationY < -dp(28f) || vy < -900f) {
                        dismissUp(vy)
                    } else {
                        spring(DynamicAnimation.TRANSLATION_Y, 0f, 0.62f, 420f, vy.coerceAtLeast(0f) / 4f)
                        spring(DynamicAnimation.SCALE_X, 1f, 0.6f, 500f)
                        spring(DynamicAnimation.SCALE_Y, 1f, 0.6f, 500f)
                        scheduleDismiss(if (expanded) autoDismissMs * 2 else autoDismissMs)
                    }
                }
            }
            return true
        }
    }

    /** «Резиновое» сопротивление при оттягивании вниз. */
    private fun rubber(dy: Float): Float {
        val limit = dp(64f)
        return limit * (1f - exp(-dy / (limit * 1.6f)))
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null)
        cancelSprings()
        super.onDetachedFromWindow()
    }
}
