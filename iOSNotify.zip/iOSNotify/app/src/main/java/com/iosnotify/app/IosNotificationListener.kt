package com.iosnotify.app

import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.os.BundleCompat

/** Ловит все уведомления системы и отдаёт их в [BannerController]. */
class IosNotificationListener : NotificationListenerService() {

    private val lastShown = HashMap<String, Int>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.enabled(this)) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (!shouldShow(n)) return

        // тихие уведомления (low / min) баннером не показываем
        val ranking = Ranking()
        if (currentRanking.getRanking(sbn.key, ranking) &&
            ranking.importance < NotificationManager.IMPORTANCE_DEFAULT
        ) return

        // экран выключен / заблокирован — баннер не нужен
        val power = getSystemService(POWER_SERVICE) as PowerManager
        if (!power.isInteractive) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        if (title.isBlank() && text.isBlank()) return

        // апдейты одного и того же уведомления не дублируем
        val signature = (title + "\u0000" + text).hashCode()
        if (lastShown[sbn.key] == signature) return
        if (lastShown.size > 200) lastShown.clear()
        lastShown[sbn.key] = signature

        val info: ApplicationInfo? =
            BundleCompat.getParcelable(extras, "android.appInfo", ApplicationInfo::class.java)
                ?: runCatching { packageManager.getApplicationInfo(sbn.packageName, 0) }.getOrNull()
        val label = info?.let { runCatching { packageManager.getApplicationLabel(it).toString() }.getOrNull() }
            ?: sbn.packageName
        val icon = info?.let { runCatching { packageManager.getApplicationIcon(it) }.getOrNull() }

        val pi = n.contentIntent
        val autoCancel = n.flags and Notification.FLAG_AUTO_CANCEL != 0
        val key = sbn.key
        val action: () -> Unit = {
            if (pi != null) fire(pi)
            if (autoCancel) runCatching { cancelNotification(key) }
        }

        BannerController.show(
            this,
            BannerData(
                appName = label,
                title = title,
                text = text,
                bigText = big,
                icon = icon,
                onClick = if (pi != null) action else null,
            ),
        )

        if (Prefs.hideOriginal(this)) {
            runCatching { cancelNotification(sbn.key) }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        lastShown.remove(sbn.key)
    }

    private fun shouldShow(n: Notification): Boolean {
        val f = n.flags
        if (f and Notification.FLAG_ONGOING_EVENT != 0) return false
        if (f and Notification.FLAG_FOREGROUND_SERVICE != 0) return false
        if (f and Notification.FLAG_GROUP_SUMMARY != 0) return false
        return when (n.category) {
            Notification.CATEGORY_CALL,
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_NAVIGATION,
            Notification.CATEGORY_ALARM -> false

            else -> true
        }
    }

    private fun fire(pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val opts = ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED,
                    )
                pi.send(opts.toBundle())
            } else {
                pi.send()
            }
        } catch (_: PendingIntent.CanceledException) {
        }
    }
}
