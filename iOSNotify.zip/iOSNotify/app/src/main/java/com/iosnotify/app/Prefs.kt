package com.iosnotify.app

import android.content.Context

/** Простые настройки приложения. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("ios_notify", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    /** Убирать оригинальное уведомление из шторки после показа баннера. */
    fun hideOriginal(c: Context) = sp(c).getBoolean("hide_original", false)
    fun setHideOriginal(c: Context, v: Boolean) = sp(c).edit().putBoolean("hide_original", v).apply()

    fun haptics(c: Context) = sp(c).getBoolean("haptics", true)
    fun setHaptics(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptics", v).apply()

    /** Сколько секунд висит баннер. */
    fun duration(c: Context) = sp(c).getInt("duration", 5)
    fun setDuration(c: Context, v: Int) = sp(c).edit().putInt("duration", v).apply()
}
